'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

require('react');
require('./_commonjsHelpers-72d386ba.js');
require('./index-c8446775.js');
var index$1 = require('./index-766bccf9.js');



exports.Inside = index$1.i;
exports.useInside = index$1.o;
//# sourceMappingURL=vendor.js.map
