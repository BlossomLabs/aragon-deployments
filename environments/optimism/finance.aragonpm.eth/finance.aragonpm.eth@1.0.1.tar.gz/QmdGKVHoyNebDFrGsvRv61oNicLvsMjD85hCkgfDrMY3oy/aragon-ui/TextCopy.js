'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

function _interopDefault (ex) { return (ex && (typeof ex === 'object') && 'default' in ex) ? ex['default'] : ex; }

var React = require('react');
var React__default = _interopDefault(React);
require('./_commonjsHelpers-72d386ba.js');
var index = require('./index-c8446775.js');
var _styled = require('styled-components');
var _styled__default = _interopDefault(_styled);
require('./color.js');
require('./components.js');
require('./contains-component.js');
require('./css.js');
require('./dayjs.min-966150e3.js');
require('./date.js');
var miscellaneous = require('./miscellaneous.js');
var environment = require('./environment.js');
require('./font.js');
require('./math-4eaf20a0.js');
require('./characters.js');
require('./format.js');
require('./keycodes.js');
require('./url.js');
require('./web3.js');
var constants = require('./constants.js');
require('./breakpoints.js');
require('./springs.js');
var textStyles = require('./text-styles.js');
require('./theme-dark.js');
require('./theme-light.js');
var Theme = require('./Theme.js');
var _extends = require('./extends-43472f94.js');
require('./index-766bccf9.js');
require('./defineProperty-7b1b81d8.js');
require('./isObject-b8c5dfc0.js');
require('./Viewport-0f56d694.js');
require('./Layout.js');
require('./FocusVisible.js');
require('./ButtonBase.js');
require('./IconPropTypes-68080ae8.js');
require('./IconAddUser.js');
require('./IconAlert.js');
require('./IconAlignCenter.js');
require('./IconAlignJustify.js');
require('./IconAlignLeft.js');
require('./IconAlignRight.js');
require('./IconAragon.js');
require('./IconArrowDown.js');
require('./IconArrowLeft.js');
require('./IconArrowRight.js');
require('./IconArrowUp.js');
require('./IconAtSign.js');
require('./IconBlock.js');
require('./IconBookmark.js');
require('./IconCalendar.js');
require('./IconCanvas.js');
require('./IconCaution.js');
require('./IconCenter.js');
require('./IconChart.js');
require('./IconChat.js');
require('./IconCheck.js');
require('./IconChip.js');
require('./IconCircleCheck.js');
require('./IconCircleMinus.js');
require('./IconCirclePlus.js');
require('./IconClock.js');
require('./IconCloudDownload.js');
require('./IconCloudUpload.js');
require('./IconCoin.js');
require('./IconConfiguration.js');
require('./IconConnect.js');
require('./IconConnection.js');
require('./IconConsole.js');
var IconCopy = require('./IconCopy.js');
require('./IconCross.js');
require('./IconDashedSquare.js');
require('./IconDown.js');
require('./IconDownload.js');
require('./IconEdit.js');
require('./IconEllipsis.js');
require('./IconEnter.js');
require('./IconEthereum.js');
require('./IconExternal.js');
require('./IconFile.js');
require('./IconFilter.js');
require('./IconFlag.js');
require('./IconFolder.js');
require('./IconGraph2.js');
require('./IconGraph.js');
require('./IconGrid.js');
require('./IconGroup.js');
require('./IconHash.js');
require('./IconHeart.js');
require('./IconHide.js');
require('./IconHome.js');
require('./IconImage.js');
require('./IconInfo.js');
require('./IconLabel.js');
require('./IconLayers.js');
require('./IconLeft.js');
require('./IconLink.js');
require('./IconLocation.js');
require('./IconLock.js');
require('./IconMail.js');
require('./IconMaximize.js');
require('./IconMenu.js');
require('./IconMinimize.js');
require('./IconMinus.js');
require('./IconMove.js');
require('./IconNoPicture.js');
require('./IconPicture.js');
require('./IconPlus.js');
require('./IconPower.js');
require('./IconPrint.js');
require('./IconProhibited.js');
require('./IconQuestion.js');
require('./IconRefresh.js');
require('./IconRemoveUser.js');
require('./IconRight.js');
require('./IconRotateLeft.js');
require('./IconRotateRight.js');
require('./IconSearch.js');
require('./IconSettings.js');
require('./IconShare.js');
require('./IconSquareMinus.js');
require('./IconSquarePlus.js');
require('./IconSquare.js');
require('./IconStarFilled.js');
require('./IconStar.js');
require('./IconSwap.js');
require('./IconTarget.js');
require('./IconToken.js');
require('./IconTrash.js');
require('./IconUnlock.js');
require('./IconUp.js');
require('./IconUpload.js');
require('./IconUser.js');
require('./IconView.js');
require('./IconVote.js');
require('./IconWallet.js');
require('./IconWarning.js');
require('./IconWorld.js');
require('./IconWrite.js');
require('./IconZoomIn.js');
require('./IconZoomOut.js');
require('./objectWithoutPropertiesLoose-d28f0f6e.js');
require('react-dom');
require('./web-449fa78f.js');
require('./Button.js');
var ButtonIcon = require('./ButtonIcon.js');
var TextInput = require('./TextInput.js');
require('./index-d200e416.js');
require('./RootPortal.js');
var ToastHub = require('./ToastHub.js');

const HEIGHT = 5 * constants.GU;
const TextCopy = /*#__PURE__*/React__default.memo( /*#__PURE__*/React__default.forwardRef(function TextCopy(_ref, ref) {
  let {
    adornment,
    autofocus,
    message,
    monospace,
    onCopy,
    value,
    ...props
  } = _ref;
  const theme = Theme.useTheme();
  const toast = ToastHub.useToast();
  const inputRef = React.useRef(null);

  // Allows to focus the component from the outside
  React.useImperativeHandle(ref, () => ({
    focus: () => {
      inputRef.current.focus();
    }
  }));

  // Select the content on focus
  const handleFocus = React.useCallback(() => {
    inputRef.current && inputRef.current.select();
  }, []);

  // If onCopy is set (either to a function or null), Toast is not used.
  const onCopyOrToast = onCopy === undefined ? toast : onCopy || miscellaneous.noop;
  const handleCopy = React.useCallback(() => {
    if (inputRef.current) {
      inputRef.current.focus();
      try {
        document.execCommand('copy');
        onCopyOrToast(message);
      } catch (err) {
        environment.warn(err);
      }
    }
  }, [message, onCopyOrToast]);
  return /*#__PURE__*/React__default.createElement(_StyledDiv, _extends._extends({}, props, {
    $_css: 52.5 * constants.GU,
    $_css2: adornment ? `${HEIGHT}px` : '0'
  }), adornment && /*#__PURE__*/React__default.createElement(_StyledDiv2, {
    $_css3: theme.surface,
    $_css4: theme.border
  }, /*#__PURE__*/React__default.createElement(_StyledDiv3, {
    $_css5: HEIGHT - 2,
    $_css6: HEIGHT - 2
  }, adornment)), /*#__PURE__*/React__default.createElement(_StyledTextInput, {
    ref: inputRef,
    adornment: /*#__PURE__*/React__default.createElement(_StyledButtonIcon, {
      onClick: handleCopy,
      label: "Copy",
      $_css7: HEIGHT - 2,
      $_css8: HEIGHT - 2,
      $_css9: theme.surfaceIcon
    }, /*#__PURE__*/React__default.createElement(IconCopy.default, null)),
    adornmentPosition: "end",
    adornmentSettings: {
      // Keep the button square
      width: HEIGHT - 2,
      padding: 0
    },
    autofocus: autofocus,
    onFocus: handleFocus,
    readOnly: true,
    value: value,
    wide: true,
    $_css10: theme.border,
    $_css11: adornment ? `
                  border-top-left-radius: 0;
                  border-bottom-left-radius: 0;
                  border-left: 0;
                ` : '',
    $_css12: textStyles.textStyle(monospace ? 'address2' : 'body3'),
    $_css13: theme.surfaceContent
  }));
}));
TextCopy.propTypes = {
  adornment: index.PropTypes.node,
  autofocus: index.PropTypes.bool,
  message: index.PropTypes.string,
  monospace: index.PropTypes.bool,
  onCopy: index.PropTypes.func,
  value: index.PropTypes.string
};
TextCopy.defaultProps = {
  autofocus: false,
  message: 'Copied',
  monospace: true
};
var _StyledDiv = _styled__default("div").withConfig({
  displayName: "TextCopy___StyledDiv",
  componentId: "sc-qr4eek-0"
})(["position:relative;display:inline-flex;width:", "px;max-width:100%;height:", "px;padding-left:", ";"], p => p.$_css, HEIGHT, p => p.$_css2);
var _StyledDiv2 = _styled__default("div").withConfig({
  displayName: "TextCopy___StyledDiv2",
  componentId: "sc-qr4eek-1"
})(["position:absolute;top:0;left:0;overflow:hidden;width:", "px;height:", "px;background:", ";border:1px solid ", ";border-right:0;border-radius:", "px 0.0001px 0.0001px ", "px;"], HEIGHT, HEIGHT, p => p.$_css3, p => p.$_css4, constants.RADIUS, constants.RADIUS);
var _StyledDiv3 = _styled__default("div").withConfig({
  displayName: "TextCopy___StyledDiv3",
  componentId: "sc-qr4eek-2"
})(["display:flex;align-items:center;justify-content:center;width:", "px;height:", "px;"], p => p.$_css5, p => p.$_css6);
var _StyledButtonIcon = _styled__default(ButtonIcon.default).withConfig({
  displayName: "TextCopy___StyledButtonIcon",
  componentId: "sc-qr4eek-3"
})(["width:", "px;height:", "px;border-radius:0;color:", ";"], p => p.$_css7, p => p.$_css8, p => p.$_css9);
var _StyledTextInput = _styled__default(TextInput.default).withConfig({
  displayName: "TextCopy___StyledTextInput",
  componentId: "sc-qr4eek-4"
})(["text-overflow:ellipsis;height:", "px;max-width:100%;border:1px solid ", ";", ";", ";&:read-only{color:", ";text-shadow:none;}"], HEIGHT, p => p.$_css10, p => p.$_css11, p => p.$_css12, p => p.$_css13);

exports.default = TextCopy;
//# sourceMappingURL=TextCopy.js.map
