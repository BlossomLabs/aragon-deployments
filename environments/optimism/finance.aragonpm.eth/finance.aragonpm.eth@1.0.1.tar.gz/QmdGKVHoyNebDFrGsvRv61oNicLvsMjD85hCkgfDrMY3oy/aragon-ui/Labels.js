'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

function _interopDefault (ex) { return (ex && (typeof ex === 'object') && 'default' in ex) ? ex['default'] : ex; }

var React = require('react');
var React__default = _interopDefault(React);
require('./_commonjsHelpers-72d386ba.js');
var index = require('./index-c8446775.js');
var _styled = require('styled-components');
var _styled__default = _interopDefault(_styled);
require('./color.js');
require('./components.js');
require('./contains-component.js');
require('./css.js');
require('./dayjs.min-966150e3.js');
require('./date.js');
require('./miscellaneous.js');
require('./environment.js');
require('./font.js');
require('./math-4eaf20a0.js');
require('./characters.js');
require('./format.js');
require('./keycodes.js');
require('./url.js');
require('./web3.js');
var constants = require('./constants.js');
require('./breakpoints.js');
require('./springs.js');
var textStyles = require('./text-styles.js');
require('./theme-dark.js');
require('./theme-light.js');
var Theme = require('./Theme.js');
var _extends$1 = require('./extends-43472f94.js');
require('./index-766bccf9.js');
require('./defineProperty-7b1b81d8.js');
require('./FocusVisible.js');
var ButtonBase = require('./ButtonBase.js');
require('./IconPropTypes-68080ae8.js');
require('./IconAddUser.js');
require('./IconAlert.js');
require('./IconAlignCenter.js');
require('./IconAlignJustify.js');
require('./IconAlignLeft.js');
require('./IconAlignRight.js');
require('./IconAragon.js');
require('./IconArrowDown.js');
require('./IconArrowLeft.js');
require('./IconArrowRight.js');
require('./IconArrowUp.js');
require('./IconAtSign.js');
require('./IconBlock.js');
require('./IconBookmark.js');
var IconCalendar = require('./IconCalendar.js');
require('./IconCanvas.js');
require('./IconCaution.js');
require('./IconCenter.js');
require('./IconChart.js');
require('./IconChat.js');
require('./IconCheck.js');
require('./IconChip.js');
require('./IconCircleCheck.js');
require('./IconCircleMinus.js');
require('./IconCirclePlus.js');
require('./IconClock.js');
require('./IconCloudDownload.js');
require('./IconCloudUpload.js');
require('./IconCoin.js');
require('./IconConfiguration.js');
require('./IconConnect.js');
require('./IconConnection.js');
require('./IconConsole.js');
require('./IconCopy.js');
require('./IconCross.js');
require('./IconDashedSquare.js');
require('./IconDown.js');
require('./IconDownload.js');
require('./IconEdit.js');
require('./IconEllipsis.js');
require('./IconEnter.js');
require('./IconEthereum.js');
require('./IconExternal.js');
require('./IconFile.js');
require('./IconFilter.js');
require('./IconFlag.js');
require('./IconFolder.js');
require('./IconGraph2.js');
require('./IconGraph.js');
require('./IconGrid.js');
require('./IconGroup.js');
require('./IconHash.js');
require('./IconHeart.js');
require('./IconHide.js');
require('./IconHome.js');
require('./IconImage.js');
require('./IconInfo.js');
require('./IconLabel.js');
require('./IconLayers.js');
require('./IconLeft.js');
require('./IconLink.js');
require('./IconLocation.js');
require('./IconLock.js');
require('./IconMail.js');
require('./IconMaximize.js');
require('./IconMenu.js');
require('./IconMinimize.js');
require('./IconMinus.js');
require('./IconMove.js');
require('./IconNoPicture.js');
require('./IconPicture.js');
require('./IconPlus.js');
require('./IconPower.js');
require('./IconPrint.js');
require('./IconProhibited.js');
require('./IconQuestion.js');
require('./IconRefresh.js');
require('./IconRemoveUser.js');
require('./IconRight.js');
require('./IconRotateLeft.js');
require('./IconRotateRight.js');
require('./IconSearch.js');
require('./IconSettings.js');
require('./IconShare.js');
require('./IconSquareMinus.js');
require('./IconSquarePlus.js');
require('./IconSquare.js');
require('./IconStarFilled.js');
require('./IconStar.js');
require('./IconSwap.js');
require('./IconTarget.js');
require('./IconToken.js');
require('./IconTrash.js');
require('./IconUnlock.js');
require('./IconUp.js');
require('./IconUpload.js');
require('./IconUser.js');
require('./IconView.js');
require('./IconVote.js');
require('./IconWallet.js');
require('./IconWarning.js');
require('./IconWorld.js');
require('./IconWrite.js');
require('./IconZoomIn.js');
require('./IconZoomOut.js');
var consts = require('./consts.js');

const Labels = /*#__PURE__*/React.forwardRef(function Labels(_ref, ref) {
  let {
    enabled,
    startText,
    endText,
    hasSetDates,
    onClick,
    ...props
  } = _ref;
  const theme = Theme.useTheme();
  const hasNoStart = startText === consts.START_DATE;
  const hasNoEnd = endText === consts.END_DATE;
  return /*#__PURE__*/React__default.createElement(ButtonBase.default, {
    focusRingRadius: constants.RADIUS,
    ref: ref,
    onClick: onClick
  }, /*#__PURE__*/React__default.createElement(_StyledDiv, _extends$1._extends({}, props, {
    $_css: 27.5 * constants.GU,
    $_css2: hasSetDates ? theme.accent : theme.border,
    $_css3: theme.surface,
    $_css4: theme.controlBorderPressed
  }), /*#__PURE__*/React__default.createElement(_StyledDiv2, null, /*#__PURE__*/React__default.createElement(_StyledDiv3, {
    $_css5: hasNoStart ? theme.hint : 'inherit',
    $_css6: textStyles.textStyle(hasNoStart ? 'body2' : 'body3')
  }, startText), /*#__PURE__*/React__default.createElement(_StyledDiv4, {
    $_css7: theme.hint.alpha(0.3)
  }, "|"), /*#__PURE__*/React__default.createElement(_StyledDiv5, {
    $_css8: hasNoEnd ? theme.hint : 'inherit',
    $_css9: textStyles.textStyle(hasNoEnd ? 'body2' : 'body3')
  }, endText)), /*#__PURE__*/React__default.createElement(_StyledDiv6, null, /*#__PURE__*/React__default.createElement(_StyledIconCalendar, {
    $_css10: enabled ? theme.accent : theme.surfaceIcon
  }))));
});
Labels.propTypes = {
  enabled: index.PropTypes.bool,
  hasSetDates: index.PropTypes.bool,
  onClick: index.PropTypes.func,
  startText: index.PropTypes.string.isRequired,
  endText: index.PropTypes.string.isRequired
};
var _StyledDiv = _styled__default("div").withConfig({
  displayName: "Labels___StyledDiv",
  componentId: "sc-16q4rrc-0"
})(["position:relative;width:", "px;display:flex;justify-content:space-between;align-items:center;padding:7px 6px;border:", "px solid ", ";border-radius:", "px;background:", ";overflow:hidden;cursor:pointer;&:active{border-color:", ";}&:focus{outline:none;}"], p => p.$_css, consts.INPUT_BORDER, p => p.$_css2, constants.RADIUS, p => p.$_css3, p => p.$_css4);
var _StyledDiv2 = _styled__default("div").withConfig({
  displayName: "Labels___StyledDiv2",
  componentId: "sc-16q4rrc-1"
})(["display:flex;flex:1;justify-content:space-around;align-items:center;"]);
var _StyledDiv3 = _styled__default("div").withConfig({
  displayName: "Labels___StyledDiv3",
  componentId: "sc-16q4rrc-2"
})(["color:", ";text-align:center;", ""], p => p.$_css5, p => p.$_css6);
var _StyledDiv4 = _styled__default("div").withConfig({
  displayName: "Labels___StyledDiv4",
  componentId: "sc-16q4rrc-3"
})(["color:", ";font-size:13px;"], p => p.$_css7);
var _StyledDiv5 = _styled__default("div").withConfig({
  displayName: "Labels___StyledDiv5",
  componentId: "sc-16q4rrc-4"
})(["color:", ";text-align:center;", ""], p => p.$_css8, p => p.$_css9);
var _StyledDiv6 = _styled__default("div").withConfig({
  displayName: "Labels___StyledDiv6",
  componentId: "sc-16q4rrc-5"
})(["display:flex;padding:0 4px 0 10px;"]);
var _StyledIconCalendar = _styled__default(IconCalendar.default).withConfig({
  displayName: "Labels___StyledIconCalendar",
  componentId: "sc-16q4rrc-6"
})(["color:", ";"], p => p.$_css10);

exports.default = Labels;
//# sourceMappingURL=Labels.js.map
