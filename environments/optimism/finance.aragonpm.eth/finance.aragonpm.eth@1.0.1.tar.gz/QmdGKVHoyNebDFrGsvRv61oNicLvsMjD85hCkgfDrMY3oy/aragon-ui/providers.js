'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

function _interopDefault (ex) { return (ex && (typeof ex === 'object') && 'default' in ex) ? ex['default'] : ex; }

var React = require('react');
var React__default = _interopDefault(React);
require('./_commonjsHelpers-72d386ba.js');
var index = require('./index-c8446775.js');
require('styled-components');
require('./color.js');
require('./components.js');
require('./contains-component.js');
require('./css.js');
var dayjs_min = require('./dayjs.min-966150e3.js');
var date = require('./date.js');
require('./miscellaneous.js');
require('./environment.js');
require('./font.js');
require('./math-4eaf20a0.js');
require('./characters.js');
require('./format.js');
require('./keycodes.js');
require('./url.js');
require('./web3.js');
require('./constants.js');
require('./breakpoints.js');
require('./springs.js');
require('./text-styles.js');
require('./extends-43472f94.js');
var defineProperty$1 = require('./defineProperty-7b1b81d8.js');
require('./isObject-b8c5dfc0.js');
var Viewport = require('./Viewport-0f56d694.js');
var getDisplayName = require('./getDisplayName-7ab6d318.js');
var index$2 = require('./index-70be9e8d.js');
var index$1$1 = require('./index-d200e416.js');
var observe = require('./observe.js');
var index$1 = require('./index-aa9c1462.js');

// Render prop component for re-rendering based on a given date. Automatically
// adjusts the re-render timer to be one second, minute, or hour based on the
// fromDate prop.
// For a discussion on pitfalls, see
// https://gist.github.com/staltz/08bf613199092eeb41ac8137d51eb5e6

const EVERY_SECOND = 1000;
const EVERY_MINUTE = EVERY_SECOND * 60;
const EVERY_HOUR = EVERY_MINUTE * 60;
const getRedrawTime = fromDate => {
  const {
    days,
    hours,
    minutes
  } = date.difference(new Date(), fromDate);
  return hours || days ? EVERY_HOUR : minutes > 1 ? EVERY_MINUTE : EVERY_SECOND;
};
class RedrawFromDate extends React__default.Component {
  constructor() {
    super(...arguments);
    defineProperty$1._defineProperty(this, "state", {
      redrawTime: EVERY_HOUR,
      lastDraw: -1
    });
    defineProperty$1._defineProperty(this, "clearInterval", () => {
      this.interval && clearInterval(this.interval);
    });
    defineProperty$1._defineProperty(this, "restartDrawInterval", redrawTime => {
      this.clearInterval();
      this.interval = setInterval(() => {
        this.setState({
          lastDraw: Date.now()
        });
        const newRedrawTime = getRedrawTime(this.props.fromDate);
        if (newRedrawTime !== redrawTime) {
          this.restartDrawInterval(newRedrawTime);
        }
      }, redrawTime);
    });
  }
  componentDidMount() {
    const {
      fromDate
    } = this.props;
    if (fromDate) {
      this.restartDrawInterval(getRedrawTime(fromDate));
    }
  }
  componentWillReceiveProps(_ref) {
    let {
      fromDate
    } = _ref;
    if (!fromDate && this.props.fromDate) {
      this.clearInterval();
    } else if (!dayjs_min.dayjs(fromDate).isSame(this.props.fromDate)) {
      this.restartDrawInterval(getRedrawTime(this.props.fromDate));
    }
  }
  componentWillUnmount() {
    this.clearInterval();
  }
  render() {
    return this.props.children();
  }
}
defineProperty$1._defineProperty(RedrawFromDate, "propTypes", {
  children: index.PropTypes.func.isRequired,
  fromDate: index.PropTypes.oneOfType([index.PropTypes.string, index.PropTypes.number, index.PropTypes.instanceOf(Date)]).isRequired
});
const hocWrap = Component => {
  const HOC = props => /*#__PURE__*/React__default.createElement(RedrawFromDate, {
    fromDate: props.fromDate
  }, () => /*#__PURE__*/React__default.createElement(Component, props));
  HOC.propTypes = {
    fromDate: RedrawFromDate.propTypes.fromDate
  };
  HOC.displayName = `RedrawFromDate(${getDisplayName.getDisplayName(Component)})`;
  return HOC;
};
RedrawFromDate.hocWrap = hocWrap;

exports.Viewport = Viewport.Viewport;
exports.useViewport = Viewport.useViewport;
exports.PublicUrl = index$2.PublicUrl;
exports.Root = index$1$1.Root;
exports.useRoot = index$1$1.useRoot;
exports.observe = observe.observe;
exports.Redraw = index$1.Redraw;
exports.RedrawFromDate = RedrawFromDate;
//# sourceMappingURL=providers.js.map
