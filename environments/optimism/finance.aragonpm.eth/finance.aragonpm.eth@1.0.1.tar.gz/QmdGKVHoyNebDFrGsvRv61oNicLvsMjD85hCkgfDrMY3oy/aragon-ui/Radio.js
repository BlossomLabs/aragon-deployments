'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

function _interopDefault (ex) { return (ex && (typeof ex === 'object') && 'default' in ex) ? ex['default'] : ex; }

var React = require('react');
var React__default = _interopDefault(React);
require('./_commonjsHelpers-72d386ba.js');
var index = require('./index-c8446775.js');
require('styled-components');
require('./color.js');
require('./components.js');
require('./contains-component.js');
require('./css.js');
require('./dayjs.min-966150e3.js');
require('./date.js');
var miscellaneous = require('./miscellaneous.js');
require('./environment.js');
require('./font.js');
require('./math-4eaf20a0.js');
require('./characters.js');
require('./format.js');
require('./keycodes.js');
require('./url.js');
require('./web3.js');
require('./constants.js');
require('./breakpoints.js');
require('./springs.js');
require('./text-styles.js');
require('./theme-dark.js');
require('./theme-light.js');
require('./Theme.js');
var _extends$1 = require('./extends-43472f94.js');
var defineProperty$1 = require('./defineProperty-7b1b81d8.js');
require('./FocusVisible.js');
require('./objectWithoutPropertiesLoose-d28f0f6e.js');
require('react-dom');
require('./web-449fa78f.js');
var Checkbox = require('./Checkbox.js');
var RadioGroup = require('./RadioGroup.js');

const KEYS_PREV = ['ArrowUp', 'ArrowLeft',
// IE / Edge support
'Up', 'Left'];
const KEYS_NEXT = ['ArrowDown', 'ArrowRight',
// IE / Edge support
'Down', 'Right'];
class RadioButton extends React__default.PureComponent {
  constructor() {
    super(...arguments);
    defineProperty$1._defineProperty(this, "_element", /*#__PURE__*/React__default.createRef());
    defineProperty$1._defineProperty(this, "handleKeyDown", event => {
      const {
        selectPrev,
        selectNext
      } = this.props;
      if (KEYS_PREV.includes(event.key)) {
        selectPrev();
        event.preventDefault();
      }
      if (KEYS_NEXT.includes(event.key)) {
        selectNext();
        event.preventDefault();
      }
    });
    defineProperty$1._defineProperty(this, "handleChange", () => {
      const {
        onChange,
        id
      } = this.props;
      if (onChange) {
        onChange(id);
      }
    });
  }
  componentDidMount() {
    const {
      addRadio,
      id
    } = this.props;
    if (addRadio && id !== null) {
      addRadio(id);
    }
  }
  componentWillUnmount() {
    const {
      removeRadio,
      id
    } = this.props;
    if (removeRadio && id !== null) {
      removeRadio(id);
    }
  }
  componentDidUpdate(prevProps) {
    const {
      checked
    } = this.props;
    if (checked && !prevProps.checked) {
      this._element.current.focus();
    }
  }
  render() {
    const {
      checked,
      disabled,
      id,
      onChange,
      tabIndex,
      ...props
    } = this.props;
    return /*#__PURE__*/React__default.createElement(Checkbox.default, _extends$1._extends({
      ref: this._element,
      checked: checked,
      disabled: disabled,
      onChange: this.handleChange,
      onKeyDown: this.handleKeyDown,
      tabIndex: tabIndex,
      variant: "radio"
    }, props));
  }
}
defineProperty$1._defineProperty(RadioButton, "propTypes", {
  addRadio: index.PropTypes.func,
  checked: index.PropTypes.bool,
  disabled: index.PropTypes.bool,
  id: index.PropTypes.oneOfType([index.PropTypes.string, index.PropTypes.number]),
  onChange: index.PropTypes.func,
  removeRadio: index.PropTypes.func,
  selectNext: index.PropTypes.func,
  selectPrev: index.PropTypes.func,
  tabIndex: index.PropTypes.string
});
defineProperty$1._defineProperty(RadioButton, "defaultProps", {
  addRadio: miscellaneous.noop,
  checked: false,
  disabled: false,
  id: null,
  onChange: undefined,
  // <Button /> need to detect if onChange has been set
  removeRadio: miscellaneous.noop,
  selectNext: miscellaneous.noop,
  selectPrev: miscellaneous.noop
});
class Radio extends React__default.PureComponent {
  render() {
    const {
      props
    } = this;
    return /*#__PURE__*/React__default.createElement(RadioGroup.RadioGroupConsumer, null, _ref => {
      let {
        onChange,
        selected,
        focusableId,
        addRadio,
        removeRadio,
        selectNext,
        selectPrev
      } = _ref;
      return /*#__PURE__*/React__default.createElement(RadioButton, _extends$1._extends({}, props, {
        onChange: props.onChange || onChange,
        checked: props.checked || props.id === selected && selected !== null,
        tabIndex: props.tabIndex || (focusableId === undefined || props.id === focusableId ? '0' : '-1'),
        addRadio: addRadio,
        removeRadio: removeRadio,
        selectPrev: selectPrev,
        selectNext: selectNext
      }));
    });
  }
}
defineProperty$1._defineProperty(Radio, "propTypes", RadioButton.propTypes);
defineProperty$1._defineProperty(Radio, "defaultProps", RadioButton.defaultProps);

exports.default = Radio;
//# sourceMappingURL=Radio.js.map
