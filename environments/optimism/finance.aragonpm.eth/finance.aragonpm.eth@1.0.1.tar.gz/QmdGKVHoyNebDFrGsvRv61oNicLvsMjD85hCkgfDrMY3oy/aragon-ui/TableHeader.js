'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

function _interopDefault (ex) { return (ex && (typeof ex === 'object') && 'default' in ex) ? ex['default'] : ex; }

var React = require('react');
var React__default = _interopDefault(React);
require('./_commonjsHelpers-72d386ba.js');
var index = require('./index-c8446775.js');
var _styled = require('styled-components');
var _styled__default = _interopDefault(_styled);
require('./color.js');
require('./components.js');
require('./contains-component.js');
require('./css.js');
require('./dayjs.min-966150e3.js');
require('./date.js');
require('./miscellaneous.js');
require('./environment.js');
require('./font.js');
require('./math-4eaf20a0.js');
require('./characters.js');
require('./format.js');
require('./keycodes.js');
require('./url.js');
require('./web3.js');
var constants = require('./constants.js');
require('./breakpoints.js');
require('./springs.js');
var textStyles = require('./text-styles.js');
require('./theme-dark.js');
require('./theme-light.js');
var Theme = require('./Theme.js');
var _extends$1 = require('./extends-43472f94.js');

function TableHeader(_ref) {
  let {
    title,
    align,
    ...props
  } = _ref;
  const theme = Theme.useTheme();
  return /*#__PURE__*/React__default.createElement(_StyledTh, _extends$1._extends({}, props, {
    $_css: align === 'left' ? 2.5 * constants.GU + 1 : 0,
    $_css2: align === 'right' ? 2.5 * constants.GU + 1 : 0,
    $_css3: align,
    $_css4: theme.contentSecondary,
    $_css5: textStyles.textStyle('label2'),
    $_css6: 4 * constants.GU
  }), title);
}
TableHeader.propTypes = {
  title: index.PropTypes.string,
  align: index.PropTypes.string
};
TableHeader.defaultProps = {
  align: 'left'
};
var _StyledTh = _styled__default("th").withConfig({
  displayName: "TableHeader___StyledTh",
  componentId: "sc-wggtte-0"
})(["padding:0;padding-left:", "px;padding-right:", "px;text-align:", ";white-space:nowrap;color:", ";", ";line-height:", "px;"], p => p.$_css, p => p.$_css2, p => p.$_css3, p => p.$_css4, p => p.$_css5, p => p.$_css6);

exports.default = TableHeader;
//# sourceMappingURL=TableHeader.js.map
