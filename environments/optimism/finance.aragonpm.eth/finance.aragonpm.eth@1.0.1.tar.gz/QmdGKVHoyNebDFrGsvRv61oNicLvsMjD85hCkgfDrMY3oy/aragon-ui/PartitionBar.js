'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

function _interopDefault (ex) { return (ex && (typeof ex === 'object') && 'default' in ex) ? ex['default'] : ex; }

var React = require('react');
var React__default = _interopDefault(React);
require('./_commonjsHelpers-72d386ba.js');
var index = require('./index-c8446775.js');
require('styled-components');
require('./color.js');
require('./components.js');
require('./contains-component.js');
require('./css.js');
require('./dayjs.min-966150e3.js');
require('./date.js');
require('./miscellaneous.js');
var environment = require('./environment.js');
require('./font.js');
require('./math-4eaf20a0.js');
require('./characters.js');
require('./format.js');
require('./keycodes.js');
require('./url.js');
require('./web3.js');
require('./constants.js');
require('./breakpoints.js');
require('./springs.js');
require('./text-styles.js');
require('./theme-dark.js');
require('./theme-light.js');
require('./Theme.js');
var Distribution = require('./Distribution.js');

function PartitionBar(_ref) {
  let {
    data,
    caption,
    colors
  } = _ref;
  environment.warnOnce('PartitionBar', 'PartitionBar is deprecated. Please use the Distribution component instead.');

  // name => item (renderFullLegendItem)
  const renderFullLegendItem = caption ? _ref2 => {
    let {
      item,
      ...props
    } = _ref2;
    return caption({
      name: item,
      ...props
    });
  } : undefined;

  // name => item (items)
  const items = data.map(_ref3 => {
    let {
      name,
      percentage
    } = _ref3;
    return {
      item: name,
      percentage
    };
  });
  return /*#__PURE__*/React__default.createElement(Distribution.default, {
    items: items,
    renderFullLegendItem: renderFullLegendItem,
    colors: colors
  });
}
PartitionBar.propTypes = {
  data: index.PropTypes.arrayOf(index.PropTypes.shape({
    name: index.PropTypes.string.isRequired,
    percentage: index.PropTypes.number.isRequired
  })).isRequired,
  colors: index.PropTypes.arrayOf(index.PropTypes.string),
  caption: index.PropTypes.func
};

exports.default = PartitionBar;
//# sourceMappingURL=PartitionBar.js.map
