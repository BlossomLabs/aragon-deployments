'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

function _interopDefault (ex) { return (ex && (typeof ex === 'object') && 'default' in ex) ? ex['default'] : ex; }

var React = require('react');
var React__default = _interopDefault(React);
require('./_commonjsHelpers-72d386ba.js');
var index = require('./index-c8446775.js');
var _styled = require('styled-components');
var _styled__default = _interopDefault(_styled);
require('./color.js');
require('./components.js');
require('./contains-component.js');
var css = require('./css.js');
require('./dayjs.min-966150e3.js');
require('./date.js');
require('./miscellaneous.js');
require('./environment.js');
require('./font.js');
require('./math-4eaf20a0.js');
require('./characters.js');
require('./format.js');
require('./keycodes.js');
require('./url.js');
require('./web3.js');
var constants = require('./constants.js');
require('./breakpoints.js');
require('./springs.js');
require('./text-styles.js');
require('./theme-dark.js');
require('./theme-light.js');
var Theme = require('./Theme.js');
require('./extends-43472f94.js');
require('./defineProperty-7b1b81d8.js');
require('./FocusVisible.js');
require('./objectWithoutPropertiesLoose-d28f0f6e.js');
require('react-dom');
require('./web-449fa78f.js');
require('./Checkbox.js');
require('./RadioGroup.js');
var Radio = require('./Radio.js');

const RadioListItem = /*#__PURE__*/React__default.memo(function RadioListItem(_ref) {
  let {
    description,
    index,
    title
  } = _ref;
  const theme = Theme.useTheme();
  return /*#__PURE__*/React__default.createElement(_StyledLabel, {
    $_css: css.unselectable(),
    $_css2: 1 * constants.GU
  }, /*#__PURE__*/React__default.createElement(_StyledRadio, {
    id: index
  }), /*#__PURE__*/React__default.createElement(_StyledDiv, {
    $_css3: theme.border,
    $_css4: theme.accent.alpha(0.35)
  }, /*#__PURE__*/React__default.createElement("strong", null, title), /*#__PURE__*/React__default.createElement(_StyledDiv2, {
    $_css5: 0.5 * constants.GU
  }, description)));
});
RadioListItem.propTypes = {
  description: index.PropTypes.node.isRequired,
  index: index.PropTypes.number.isRequired,
  title: index.PropTypes.node.isRequired
};
var _StyledLabel = _styled__default("label").withConfig({
  displayName: "RadioListItem___StyledLabel",
  componentId: "sc-1yahyua-0"
})(["display:flex;", ";& + &{margin-top:", "px;}"], p => p.$_css, p => p.$_css2);
var _StyledRadio = _styled__default(Radio.default).withConfig({
  displayName: "RadioListItem___StyledRadio",
  componentId: "sc-1yahyua-1"
})(["flex-shrink:0;"]);
var _StyledDiv = _styled__default("div").withConfig({
  displayName: "RadioListItem___StyledDiv",
  componentId: "sc-1yahyua-2"
})(["flex-grow:1;margin-left:12px;padding:12px 12px;border-radius:3px;transition:border 100ms ease-in-out;cursor:pointer;border:1px ", " solid;&:hover{border-color:", ";}"], p => p.$_css3, p => p.$_css4);
var _StyledDiv2 = _styled__default("div").withConfig({
  displayName: "RadioListItem___StyledDiv2",
  componentId: "sc-1yahyua-3"
})(["margin-top:", "px;"], p => p.$_css5);

exports.default = RadioListItem;
//# sourceMappingURL=RadioListItem.js.map
