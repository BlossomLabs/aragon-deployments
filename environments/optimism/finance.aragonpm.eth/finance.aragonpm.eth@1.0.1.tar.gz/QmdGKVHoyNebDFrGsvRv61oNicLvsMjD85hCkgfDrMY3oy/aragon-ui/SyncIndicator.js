'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

function _interopDefault (ex) { return (ex && (typeof ex === 'object') && 'default' in ex) ? ex['default'] : ex; }

var React = require('react');
var React__default = _interopDefault(React);
require('./_commonjsHelpers-72d386ba.js');
var index = require('./index-c8446775.js');
var _styled = require('styled-components');
var _styled__default = _interopDefault(_styled);
require('./color.js');
require('./components.js');
require('./contains-component.js');
require('./css.js');
require('./dayjs.min-966150e3.js');
require('./date.js');
require('./miscellaneous.js');
require('./environment.js');
require('./font.js');
require('./math-4eaf20a0.js');
require('./characters.js');
require('./format.js');
require('./keycodes.js');
require('./url.js');
require('./web3.js');
var constants = require('./constants.js');
require('./breakpoints.js');
require('./springs.js');
require('./text-styles.js');
require('./theme-dark.js');
require('./theme-light.js');
require('./Theme.js');
var _extends$1 = require('./extends-43472f94.js');
require('./index-766bccf9.js');
require('./defineProperty-7b1b81d8.js');
require('./isObject-b8c5dfc0.js');
require('./Viewport-0f56d694.js');
require('./objectWithoutPropertiesLoose-d28f0f6e.js');
require('react-dom');
require('./web-449fa78f.js');
var LoadingRing = require('./LoadingRing.js');
require('./index-d200e416.js');
require('./RootPortal.js');
require('./ToastHub.js');
var FloatIndicator = require('./FloatIndicator.js');

function SyncIndicator(_ref) {
  let {
    children,
    label,
    shift,
    visible,
    ...props
  } = _ref;
  return /*#__PURE__*/React__default.createElement(FloatIndicator.default, _extends$1._extends({
    visible: visible,
    shift: shift
  }, props), /*#__PURE__*/React__default.createElement(LoadingRing.default, null), /*#__PURE__*/React__default.createElement(_StyledDiv, {
    $_css: 1.5 * constants.GU
  }, children || /*#__PURE__*/React__default.createElement(_StyledSpan, null, label, " \uD83D\uDE4F")));
}
SyncIndicator.propTypes = {
  children: index.PropTypes.node,
  label: index.PropTypes.node,
  shift: index.PropTypes.number,
  visible: index.PropTypes.bool
};
SyncIndicator.defaultProps = {
  label: 'Syncing data…'
};
var _StyledDiv = _styled__default("div").withConfig({
  displayName: "SyncIndicator___StyledDiv",
  componentId: "sc-ky4kud-0"
})(["margin-left:", "px;"], p => p.$_css);
var _StyledSpan = _styled__default("span").withConfig({
  displayName: "SyncIndicator___StyledSpan",
  componentId: "sc-ky4kud-1"
})(["white-space:nowrap"]);

exports.default = SyncIndicator;
//# sourceMappingURL=SyncIndicator.js.map
