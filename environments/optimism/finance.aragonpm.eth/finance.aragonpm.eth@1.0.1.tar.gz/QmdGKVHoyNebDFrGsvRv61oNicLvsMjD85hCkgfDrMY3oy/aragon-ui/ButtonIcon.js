'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

function _interopDefault (ex) { return (ex && (typeof ex === 'object') && 'default' in ex) ? ex['default'] : ex; }

var React = require('react');
var React__default = _interopDefault(React);
require('./_commonjsHelpers-72d386ba.js');
var index = require('./index-c8446775.js');
var _styled = require('styled-components');
var _styled__default = _interopDefault(_styled);
require('./color.js');
require('./components.js');
require('./contains-component.js');
require('./css.js');
require('./dayjs.min-966150e3.js');
require('./date.js');
require('./miscellaneous.js');
var environment = require('./environment.js');
require('./font.js');
require('./math-4eaf20a0.js');
require('./characters.js');
require('./format.js');
require('./keycodes.js');
require('./url.js');
require('./web3.js');
var constants = require('./constants.js');
require('./breakpoints.js');
require('./springs.js');
require('./text-styles.js');
require('./theme-dark.js');
require('./theme-light.js');
require('./Theme.js');
var _extends = require('./extends-43472f94.js');
require('./index-766bccf9.js');
require('./defineProperty-7b1b81d8.js');
require('./isObject-b8c5dfc0.js');
require('./Viewport-0f56d694.js');
require('./Layout.js');
require('./FocusVisible.js');
var ButtonBase = require('./ButtonBase.js');
var Button = require('./Button.js');

function ButtonIcon(_ref) {
  let {
    label,
    children,
    mode,
    ...props
  } = _ref;
  if (mode !== undefined) {
    environment.warnOnce('ButtonIcon:mode', 'ButtonIcon: the mode prop is deprecated. Please use Button with the icon prop instead.');
  }
  if (mode === 'button') {
    return /*#__PURE__*/React__default.createElement(Button.default, _extends._extends({
      label: label,
      icon: children,
      display: "icon"
    }, props));
  }
  return /*#__PURE__*/React__default.createElement(_StyledButtonBase, _extends._extends({
    title: label
  }, props, {
    $_css: 4 * constants.GU,
    $_css2: 4 * constants.GU
  }), children);
}
ButtonIcon.propTypes = {
  label: index.PropTypes.string.isRequired,
  children: index.PropTypes.node.isRequired,
  // deprecated
  mode: index.PropTypes.oneOf(['button'])
};
var _StyledButtonBase = _styled__default(ButtonBase.default).withConfig({
  displayName: "ButtonIcon___StyledButtonBase",
  componentId: "sc-1t27bd9-0"
})(["display:inline-flex;justify-content:center;align-items:center;width:", "px;height:", "px;&:active{background:rgba(220,234,239,0.3);}"], p => p.$_css, p => p.$_css2);

exports.default = ButtonIcon;
//# sourceMappingURL=ButtonIcon.js.map
