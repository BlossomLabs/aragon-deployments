'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

function _interopDefault (ex) { return (ex && (typeof ex === 'object') && 'default' in ex) ? ex['default'] : ex; }

var React = require('react');
var React__default = _interopDefault(React);
require('./_commonjsHelpers-72d386ba.js');
var index = require('./index-c8446775.js');
require('./color.js');
require('./components.js');
require('./contains-component.js');
require('./css.js');
require('./dayjs.min-966150e3.js');
require('./date.js');
var miscellaneous = require('./miscellaneous.js');
require('./environment.js');
require('./font.js');
require('./math-4eaf20a0.js');
require('./characters.js');
require('./format.js');
var keycodes = require('./keycodes.js');
require('./url.js');
require('./web3.js');
var _extends$1 = require('./extends-43472f94.js');
var defineProperty$1 = require('./defineProperty-7b1b81d8.js');

class EscapeOutside extends React__default.Component {
  constructor() {
    super(...arguments);
    defineProperty$1._defineProperty(this, "_element", /*#__PURE__*/React__default.createRef());
    defineProperty$1._defineProperty(this, "_document", null);
    defineProperty$1._defineProperty(this, "handleClick", e => {
      const {
        onEscapeOutside
      } = this.props;
      if (!this._element.contains(e.target)) {
        onEscapeOutside();
      }
    });
    defineProperty$1._defineProperty(this, "handleEscape", e => {
      const {
        onEscapeOutside
      } = this.props;
      if (e.keyCode === keycodes.KEY_ESC) {
        onEscapeOutside();
      }
    });
  }
  componentDidMount() {
    this._document = this._element.ownerDocument;
    this._document.addEventListener('keydown', this.handleEscape);
    this._document.addEventListener('click', this.handleClick);
    this._document.addEventListener('touchend', this.handleClick);
  }
  componentWillUnmount() {
    this._document.removeEventListener('keydown', this.handleEscape);
    this._document.removeEventListener('click', this.handleClick);
    this._document.removeEventListener('touchend', this.handleClick);
  }
  render() {
    const {
      children,
      onEscapeOutside,
      ...rest
    } = this.props;
    return /*#__PURE__*/React__default.createElement("div", _extends$1._extends({}, rest, {
      ref: n => this._element = n
    }), children);
  }
}
defineProperty$1._defineProperty(EscapeOutside, "propTypes", {
  children: index.PropTypes.node.isRequired,
  onEscapeOutside: index.PropTypes.func.isRequired
});
defineProperty$1._defineProperty(EscapeOutside, "defaultProps", {
  onEscapeOutside: miscellaneous.noop
});

exports.default = EscapeOutside;
//# sourceMappingURL=EscapeOutside.js.map
