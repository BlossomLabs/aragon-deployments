'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

require('react');
require('./_commonjsHelpers-72d386ba.js');
require('./color.js');
require('./components.js');
require('./contains-component.js');
require('./css.js');
require('./dayjs.min-966150e3.js');
require('./date.js');
require('./miscellaneous.js');
require('./environment.js');
require('./font.js');
require('./math-4eaf20a0.js');
require('./characters.js');
require('./format.js');
require('./keycodes.js');
require('./url.js');
require('./web3.js');
require('./aragon.js');
var palettes = require('./palettes.js');



exports.brand = palettes.brand;
exports.colors = palettes.colors;
exports.theme = palettes.theme;
exports.themeDark = palettes.themeDark;
//# sourceMappingURL=theme-legacy.js.map
