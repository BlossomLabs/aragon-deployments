'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

function _interopDefault (ex) { return (ex && (typeof ex === 'object') && 'default' in ex) ? ex['default'] : ex; }

var React = require('react');
var React__default = _interopDefault(React);
require('./_commonjsHelpers-72d386ba.js');
var index = require('./index-c8446775.js');
var _styled = require('styled-components');
var _styled__default = _interopDefault(_styled);
require('./color.js');
require('./components.js');
require('./contains-component.js');
require('./css.js');
require('./dayjs.min-966150e3.js');
require('./date.js');
require('./miscellaneous.js');
require('./environment.js');
require('./font.js');
require('./math-4eaf20a0.js');
require('./characters.js');
require('./format.js');
require('./keycodes.js');
require('./url.js');
require('./web3.js');
var constants = require('./constants.js');
require('./breakpoints.js');
require('./springs.js');
var textStyles = require('./text-styles.js');
require('./theme-dark.js');
require('./theme-light.js');
var Theme = require('./Theme.js');
require('./extends-43472f94.js');
require('./index-766bccf9.js');
require('./defineProperty-7b1b81d8.js');
require('./FocusVisible.js');
require('./ButtonBase.js');
require('./getDisplayName-7ab6d318.js');
var index$2 = require('./index-70be9e8d.js');
var LoadingRing = require('./LoadingRing.js');
var Link = require('./Link.js');

var illustrationRedImage = "5140b2d928ee3408.png";

var illustrationBlueImage = "665de3412d16a795.png";

function useEmptyStateParts(status, configurator, functionMode) {
  const publicUrl = index$2.usePublicUrl();
  const defaultConfigurator = React.useMemo(() => {
    // eslint-disable-next-line react/prop-types
    const Illustration = _ref => {
      let {
        path
      } = _ref;
      return /*#__PURE__*/React__default.createElement("img", {
        src: publicUrl + path,
        alt: "",
        height: 20 * constants.GU
      });
    };
    return {
      default: {
        displayLoader: false,
        title: 'No data available.',
        subtitle: null,
        illustration: /*#__PURE__*/React__default.createElement(Illustration, {
          path: illustrationBlueImage
        }),
        clearLabel: null
      },
      loading: {
        displayLoader: true,
        title: 'Loading data…',
        subtitle: null,
        illustration: /*#__PURE__*/React__default.createElement(Illustration, {
          path: illustrationBlueImage
        }),
        clearLabel: null
      },
      'empty-filters': {
        displayLoader: false,
        title: 'No results found.',
        subtitle: 'We can’t find any item matching your filter selection.',
        illustration: /*#__PURE__*/React__default.createElement(Illustration, {
          path: illustrationRedImage
        }),
        clearLabel: 'Clear filters'
      },
      'empty-search': {
        displayLoader: false,
        title: 'No results found.',
        subtitle: 'We can’t find any item matching your search query.',
        illustration: /*#__PURE__*/React__default.createElement(Illustration, {
          path: illustrationRedImage
        }),
        clearLabel: 'Clear filters'
      }
    };
  }, [publicUrl]);
  const parts = functionMode ? {} : configurator[status];
  return {
    ...defaultConfigurator[status],
    ...parts
  };
}
function EmptyState(_ref2) {
  let {
    status,
    configurator,
    onStatusEmptyClear
  } = _ref2;
  const theme = Theme.useTheme();
  const functionMode = typeof configurator === 'function';
  const emptyState = useEmptyStateParts(status, configurator, functionMode);
  const emptyStateOverride = functionMode ? configurator(status) : null;

  // Returning an element from the function mode overrides everything.
  // If `null` or a non-element is returned, the default state is used instead.
  if ( /*#__PURE__*/React__default.isValidElement(emptyStateOverride)) {
    return emptyStateOverride;
  }
  return /*#__PURE__*/React__default.createElement(_StyledSection, null, /*#__PURE__*/React__default.createElement(_StyledDiv, {
    $_css: 31 * constants.GU,
    $_css2: 8 * constants.GU
  }, emptyState.illustration && /*#__PURE__*/React__default.createElement(_StyledDiv2, {
    $_css3: 2 * constants.GU
  }, emptyState.illustration), emptyState.title && /*#__PURE__*/React__default.createElement(_StyledH, {
    $_css4: textStyles.textStyle('title2')
  }, emptyState.displayLoader && /*#__PURE__*/React__default.createElement(_StyledLoadingRing, {
    $_css5: 1 * constants.GU
  }), emptyState.title), emptyState.subtitle && /*#__PURE__*/React__default.createElement(_StyledDiv3, {
    $_css6: theme.surfaceContentSecondary
  }, emptyState.subtitle, ' ', emptyState.clearLabel && /*#__PURE__*/React__default.createElement(Link.default, {
    onClick: onStatusEmptyClear
  }, emptyState.clearLabel))));
}
EmptyState.propTypes = {
  status: index.PropTypes.oneOf(['default', 'empty-filters', 'empty-search', 'loading']),
  configurator: index.PropTypes.object,
  onStatusEmptyClear: index.PropTypes.func
};
var _StyledSection = _styled__default("section").withConfig({
  displayName: "EmptyState___StyledSection",
  componentId: "sc-zivr5a-0"
})(["display:flex;justify-content:center;align-items:center;"]);
var _StyledDiv = _styled__default("div").withConfig({
  displayName: "EmptyState___StyledDiv",
  componentId: "sc-zivr5a-1"
})(["width:", "px;padding:", "px 0;text-align:center;"], p => p.$_css, p => p.$_css2);
var _StyledDiv2 = _styled__default("div").withConfig({
  displayName: "EmptyState___StyledDiv2",
  componentId: "sc-zivr5a-2"
})(["padding-bottom:", "px;"], p => p.$_css3);
var _StyledH = _styled__default("h1").withConfig({
  displayName: "EmptyState___StyledH",
  componentId: "sc-zivr5a-3"
})(["", ";display:flex;align-items:center;justify-content:center;"], p => p.$_css4);
var _StyledLoadingRing = _styled__default(LoadingRing.default).withConfig({
  displayName: "EmptyState___StyledLoadingRing",
  componentId: "sc-zivr5a-4"
})(["margin-right:", "px;"], p => p.$_css5);
var _StyledDiv3 = _styled__default("div").withConfig({
  displayName: "EmptyState___StyledDiv3",
  componentId: "sc-zivr5a-5"
})(["color:", ";"], p => p.$_css6);

exports.default = EmptyState;
//# sourceMappingURL=EmptyState.js.map
