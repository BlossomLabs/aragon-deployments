'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

function _interopDefault (ex) { return (ex && (typeof ex === 'object') && 'default' in ex) ? ex['default'] : ex; }

var React = require('react');
var React__default = _interopDefault(React);
require('./_commonjsHelpers-72d386ba.js');
var index = require('./index-c8446775.js');
var _styled = require('styled-components');
var _styled__default = _interopDefault(_styled);
require('./color.js');
require('./components.js');
require('./contains-component.js');
require('./css.js');
require('./dayjs.min-966150e3.js');
require('./date.js');
var miscellaneous = require('./miscellaneous.js');
var environment = require('./environment.js');
require('./font.js');
require('./math-4eaf20a0.js');
require('./characters.js');
require('./format.js');
require('./keycodes.js');
require('./url.js');
require('./web3.js');
var constants = require('./constants.js');
require('./breakpoints.js');
require('./springs.js');
var textStyles = require('./text-styles.js');
require('./theme-dark.js');
require('./theme-light.js');
var Theme = require('./Theme.js');
require('./extends-43472f94.js');
require('./index-766bccf9.js');
require('./defineProperty-7b1b81d8.js');
require('./isObject-b8c5dfc0.js');
require('./Viewport-0f56d694.js');
var Layout = require('./Layout.js');
var Box = require('./Box.js');
require('./FocusVisible.js');
require('./ButtonBase.js');
require('./PaginationItem.js');
require('./IconPropTypes-68080ae8.js');
require('./IconAddUser.js');
require('./IconAlert.js');
require('./IconAlignCenter.js');
require('./IconAlignJustify.js');
require('./IconAlignLeft.js');
require('./IconAlignRight.js');
require('./IconAragon.js');
require('./IconArrowDown.js');
require('./IconArrowLeft.js');
require('./IconArrowRight.js');
require('./IconArrowUp.js');
require('./IconAtSign.js');
require('./IconBlock.js');
require('./IconBookmark.js');
require('./IconCalendar.js');
require('./IconCanvas.js');
require('./IconCaution.js');
require('./IconCenter.js');
require('./IconChart.js');
require('./IconChat.js');
require('./IconCheck.js');
require('./IconChip.js');
require('./IconCircleCheck.js');
require('./IconCircleMinus.js');
require('./IconCirclePlus.js');
require('./IconClock.js');
require('./IconCloudDownload.js');
require('./IconCloudUpload.js');
require('./IconCoin.js');
require('./IconConfiguration.js');
require('./IconConnect.js');
require('./IconConnection.js');
require('./IconConsole.js');
require('./IconCopy.js');
require('./IconCross.js');
require('./IconDashedSquare.js');
require('./IconDown.js');
require('./IconDownload.js');
require('./IconEdit.js');
require('./IconEllipsis.js');
require('./IconEnter.js');
require('./IconEthereum.js');
require('./IconExternal.js');
require('./IconFile.js');
require('./IconFilter.js');
require('./IconFlag.js');
require('./IconFolder.js');
require('./IconGraph2.js');
require('./IconGraph.js');
require('./IconGrid.js');
require('./IconGroup.js');
require('./IconHash.js');
require('./IconHeart.js');
require('./IconHide.js');
require('./IconHome.js');
require('./IconImage.js');
require('./IconInfo.js');
require('./IconLabel.js');
require('./IconLayers.js');
require('./IconLeft.js');
require('./IconLink.js');
require('./IconLocation.js');
require('./IconLock.js');
require('./IconMail.js');
require('./IconMaximize.js');
require('./IconMenu.js');
require('./IconMinimize.js');
require('./IconMinus.js');
require('./IconMove.js');
require('./IconNoPicture.js');
require('./IconPicture.js');
require('./IconPlus.js');
require('./IconPower.js');
require('./IconPrint.js');
require('./IconProhibited.js');
require('./IconQuestion.js');
require('./IconRefresh.js');
require('./IconRemoveUser.js');
require('./IconRight.js');
require('./IconRotateLeft.js');
require('./IconRotateRight.js');
require('./IconSearch.js');
require('./IconSettings.js');
require('./IconShare.js');
require('./IconSquareMinus.js');
require('./IconSquarePlus.js');
require('./IconSquare.js');
require('./IconStarFilled.js');
require('./IconStar.js');
require('./IconSwap.js');
require('./IconTarget.js');
require('./IconToken.js');
require('./IconTrash.js');
require('./IconUnlock.js');
require('./IconUp.js');
require('./IconUpload.js');
require('./IconUser.js');
require('./IconView.js');
require('./IconVote.js');
require('./IconWallet.js');
require('./IconWarning.js');
require('./IconWorld.js');
require('./IconWrite.js');
require('./IconZoomIn.js');
require('./IconZoomOut.js');
require('./PaginationSeparator.js');
var Pagination = require('./Pagination.js');
require('./objectWithoutPropertiesLoose-d28f0f6e.js');
require('react-dom');
require('./web-449fa78f.js');
require('./Checkbox.js');
require('./Button.js');
require('./ButtonIcon.js');
require('./ToggleButton.js');
require('./OpenedSurfaceBorder.js');
var TableView = require('./TableView.js');
var ListView = require('./ListView.js');
require('./getDisplayName-7ab6d318.js');
require('./index-70be9e8d.js');
require('./LoadingRing.js');
require('./Link.js');
var EmptyState = require('./EmptyState.js');

function prepareEntries(entries, from, to, selectedIndexes) {
  return entries.slice(from, to).map((entry, index) => {
    const entryIndex = from + index;
    const selected = selectedIndexes.includes(entryIndex);
    return {
      value: entry || null,
      index: entryIndex,
      selected
    };
  });
}
function prepareFields(fields) {
  return fields.map((fieldFromProps, index, fields) => {
    // Convert non-object fields (e.g. a simple string) into objects
    const field = fieldFromProps && fieldFromProps.label ? fieldFromProps : {
      label: fieldFromProps
    };

    // Auto align the last column to the end (right)
    if (!field.align) {
      field.align = index === fields.length - 1 && fields.length > 1 ? 'end' : 'start';
    }
    return field;
  });
}
function entryExpansion(content) {
  // Rows
  if (Array.isArray(content) && content.length > 0) {
    return {
      content,
      freeLayout: false
    };
  }
  // Free layout
  if (content && !Array.isArray(content)) {
    return {
      content: [content],
      freeLayout: true
    };
  }
  // No expansion
  return {
    content: [],
    freeLayout: false
  };
}
function renderEntries(entries, _ref) {
  let {
    fields,
    renderEntry,
    renderEntryActions,
    renderEntryExpansion,
    mode
  } = _ref;
  return entries.map(entry => {
    const {
      value,
      index,
      selected
    } = entry;
    let entryNodes = renderEntry(value, index, {
      selected,
      mode
    });
    if (!Array.isArray(entryNodes)) {
      entryNodes = [];
    }

    // Create undefined cells too
    while (entryNodes.length < fields.length) {
      entryNodes.push(null);
    }
    const expansion = entryExpansion(renderEntryExpansion ? renderEntryExpansion(value, index, {
      selected,
      mode
    }) : null);
    const actions = renderEntryActions ? renderEntryActions(value, index, {
      selected,
      mode
    }) : null;
    return {
      actions,
      entryNodes,
      expansion,
      index,
      selected
    };
  });
}
function useSelection(entries, selection, onSelectEntries) {
  // Only used if `selection` is not passed via props. The selection supports
  // both a managed and a controlled mode, to provide a better developer
  // experience out of the box.
  const [selectionManaged, setSelectionManaged] = React.useState([]);
  const currentSelection = selection === undefined ? selectionManaged : selection;
  const updateSelection = React.useCallback(newSelection => {
    // Managed state
    if (selection === undefined) {
      setSelectionManaged(newSelection);
    }

    // Useful to notify, even in managed mode
    onSelectEntries([...newSelection].sort().map(index => entries[index]), newSelection);
  }, [selection, onSelectEntries, entries]);
  const allSelected = React.useMemo(() => {
    // none selected
    if (currentSelection.length === 0) {
      return -1;
    }
    // all selected
    if (currentSelection.length === entries.length) {
      return 1;
    }
    // some selected
    return 0;
  }, [entries, currentSelection]);
  const toggleEntrySelect = React.useCallback(entryIndex => {
    updateSelection(currentSelection.includes(entryIndex) ? currentSelection.filter(index => index !== entryIndex) : [...currentSelection, entryIndex]);
  }, [updateSelection, currentSelection]);
  const selectAll = React.useCallback(() => {
    updateSelection(currentSelection.length === 0 ? entries.map((_, index) => index) : []);
  }, [entries, currentSelection, updateSelection]);
  return {
    allSelected,
    selectAll,
    toggleEntrySelect,
    selectedIndexes: currentSelection
  };
}
function deprecatedEmptyStatePropsCompat(_ref2) {
  let {
    emptyState,
    statusEmpty,
    statusLoading,
    statusEmptyFilters,
    statusEmptySearch
  } = _ref2;
  for (const [propName, propValue, emptyStateName, partName] of [['statusEmpty', statusEmpty, 'default', 'title'], ['statusEmptyFilters', statusEmptyFilters, 'empty-filters', 'subtitle'], ['statusEmptySearch', statusEmptySearch, 'empty-search', 'subtitle'], ['statusLoading', statusLoading, 'loading', 'title']]) {
    if (!propValue) {
      continue;
    }
    environment.warnOnce(`DataView:${propName}`, `DataView: the ${propName} prop is now deprecated, please use emptyState instead.`);

    // Only set the default state title if not set already
    if (!emptyState[emptyStateName] || !emptyState[emptyStateName][partName]) {
      emptyState[emptyStateName] = {
        ...emptyState[emptyStateName],
        [partName]: propValue
      };
    }
  }
  return emptyState;
}
const DataView = /*#__PURE__*/React__default.memo(function DataView(_ref3) {
  let {
    emptyState,
    entries,
    entriesPerPage,
    fields,
    heading,
    mode,
    onPageChange,
    onSelectEntries,
    onStatusEmptyClear,
    page,
    renderEntry,
    renderEntryActions,
    renderEntryExpansion,
    renderSelectionCount,
    selection,
    status,
    tableRowHeight,
    // deprecated
    renderEntryChild,
    statusEmpty,
    statusEmptyFilters,
    statusEmptySearch,
    statusLoading
  } = _ref3;
  if (renderEntryChild && !renderEntryExpansion) {
    environment.warnOnce('DataView:renderEntryChild', 'DataView: the renderEntryChild prop has been renamed ' + 'renderEntryExpansion and will be removed in a future version. ' + 'Please use the new name.');
    renderEntryExpansion = renderEntryChild;
  }
  if (renderEntryExpansion && onSelectEntries) {
    environment.warnOnce('DataView: renderEntryExpansion + onSelectEntries', 'A DataView cannot be made selectable with some of its entries ' + 'expandable. Please use only one of renderEntryExpansion or ' + 'onSelectEntries at a time. Ignoring renderEntryExpansion.');
    renderEntryExpansion = undefined;
  }
  emptyState = deprecatedEmptyStatePropsCompat({
    emptyState,
    statusEmpty,
    statusEmptyFilters,
    statusEmptySearch,
    statusLoading
  });

  // Only used if `page` is not passed. The pagination supports both a
  // managed and a controlled mode, to provide a better developer experience
  // out of the box.
  const [pageManaged, setPageManaged] = React.useState(0);
  const handlePageChange = React.useCallback(newPage => {
    // Managed state
    if (page === undefined) {
      setPageManaged(newPage);
    }

    // Useful to notify, even in managed mode
    onPageChange(newPage);
  }, [onPageChange, page]);

  // Reset managed pagination if the entries or the pagination changes.
  React.useEffect(() => {
    setPageManaged(0);
  }, [entries]);
  const selectedPage = page === undefined ? pageManaged : page;
  const theme = Theme.useTheme();
  const {
    layoutName
  } = Layout.useLayout();
  const listMode = mode === 'list' || mode !== 'table' && layoutName === 'small';
  const {
    allSelected,
    selectAll,
    toggleEntrySelect,
    selectedIndexes
  } = useSelection(entries, selection, onSelectEntries);
  const hasAnyActions = Boolean(renderEntryActions);
  const hasAnyExpansion = Boolean(renderEntryExpansion);
  const canSelect = Boolean(onSelectEntries);

  // If entriesPerPage is -1 (or 0): no pagination
  if (entriesPerPage < 1) {
    entriesPerPage = entries.length;
  }
  const pages = Math.ceil(entries.length / entriesPerPage);
  const displayFrom = entriesPerPage * selectedPage;
  const displayTo = displayFrom + entriesPerPage;
  const displayedEntries = prepareEntries(entries, displayFrom, displayTo, selectedIndexes);
  const preparedFields = prepareFields(fields);
  const renderedEntries = renderEntries(displayedEntries, {
    fields,
    renderEntry,
    renderEntryActions,
    renderEntryExpansion,
    mode: listMode ? 'list' : 'table'
  });
  const alignChildOnField = fields.findIndex(field => field && field.childStart);
  const emptyEntries = renderedEntries.length === 0;
  return /*#__PURE__*/React__default.createElement(Box.default, {
    padding: 0
  }, heading && /*#__PURE__*/React__default.createElement(_StyledDiv, {
    $_css: 2 * constants.GU,
    $_css2: layoutName === 'small' ? 2 * constants.GU : 3 * constants.GU
  }, typeof heading === 'string' ? /*#__PURE__*/React__default.createElement(_StyledH, {
    $_css3: 2 * constants.GU,
    $_css4: textStyles.textStyle('body2')
  }, heading) : heading), !emptyEntries && (listMode ? /*#__PURE__*/React__default.createElement(ListView.ListView, {
    allSelected: allSelected,
    entries: renderedEntries,
    fields: preparedFields,
    hasAnyExpansion: hasAnyExpansion,
    onSelect: toggleEntrySelect,
    onSelectAll: selectAll,
    renderSelectionCount: renderSelectionCount,
    rowHeight: tableRowHeight,
    selectable: canSelect
  }) : /*#__PURE__*/React__default.createElement(TableView.TableView, {
    alignChildOnField: Math.min(Math.max(-1, alignChildOnField), fields.length - 1),
    allSelected: allSelected,
    entries: renderedEntries,
    fields: preparedFields,
    hasAnyActions: hasAnyActions,
    hasAnyExpansion: hasAnyExpansion,
    onSelect: toggleEntrySelect,
    onSelectAll: selectAll,
    renderSelectionCount: renderSelectionCount,
    rowHeight: tableRowHeight,
    selectable: canSelect,
    selectedCount: selectedIndexes.length
  })), emptyEntries && /*#__PURE__*/React__default.createElement(EmptyState.default, {
    status: status,
    configurator: emptyState,
    onStatusEmptyClear: onStatusEmptyClear
  }), pages > 1 && /*#__PURE__*/React__default.createElement(_StyledDiv2, {
    $_css5: theme.border
  }, /*#__PURE__*/React__default.createElement(Pagination.default, {
    pages: pages,
    selected: selectedPage,
    onChange: handlePageChange,
    touchMode: layoutName === 'small'
  })));
});
DataView.propTypes = {
  page: index.PropTypes.number,
  entries: index.PropTypes.array.isRequired,
  entriesPerPage: index.PropTypes.number,
  fields: index.PropTypes.array.isRequired,
  heading: index.PropTypes.node,
  mode: index.PropTypes.oneOf(['adaptive', 'table', 'list']),
  onPageChange: index.PropTypes.func,
  onSelectEntries: index.PropTypes.func,
  renderEntry: index.PropTypes.func.isRequired,
  renderEntryActions: index.PropTypes.func,
  renderEntryExpansion: index.PropTypes.func,
  renderSelectionCount: index.PropTypes.func,
  selection: index.PropTypes.array,
  tableRowHeight: index.PropTypes.number,
  status: index.PropTypes.oneOf(['default', 'empty-filters', 'empty-search', 'loading']),
  onStatusEmptyClear: index.PropTypes.func,
  emptyState: index.PropTypes.oneOfType([index.PropTypes.func, index.PropTypes.object]),
  // deprecated
  renderEntryChild: index.PropTypes.func,
  statusEmpty: index.PropTypes.node,
  statusLoading: index.PropTypes.node,
  statusEmptyFilters: index.PropTypes.node,
  statusEmptySearch: index.PropTypes.node
};
DataView.defaultProps = {
  emptyState: {},
  entriesPerPage: 10,
  mode: 'adaptive',
  onPageChange: miscellaneous.noop,
  renderSelectionCount: count => `${count} items selected`,
  status: 'default',
  tableRowHeight: 8 * constants.GU
};
var _StyledDiv = _styled__default("div").withConfig({
  displayName: "DataView___StyledDiv",
  componentId: "sc-188ziu1-0"
})(["padding:", "px ", "px;"], p => p.$_css, p => p.$_css2);
var _StyledH = _styled__default("h1").withConfig({
  displayName: "DataView___StyledH",
  componentId: "sc-188ziu1-1"
})(["margin-bottom:", "px;", ";"], p => p.$_css3, p => p.$_css4);
var _StyledDiv2 = _styled__default("div").withConfig({
  displayName: "DataView___StyledDiv2",
  componentId: "sc-188ziu1-2"
})(["border-top:1px solid ", ";"], p => p.$_css5);

exports.default = DataView;
//# sourceMappingURL=DataView.js.map
