'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

function _interopDefault (ex) { return (ex && (typeof ex === 'object') && 'default' in ex) ? ex['default'] : ex; }

var React = require('react');
var React__default = _interopDefault(React);
require('./_commonjsHelpers-72d386ba.js');
var index = require('./index-c8446775.js');
var _styled = require('styled-components');
var _styled__default = _interopDefault(_styled);
require('./color.js');
require('./components.js');
require('./contains-component.js');
require('./css.js');
require('./dayjs.min-966150e3.js');
require('./date.js');
require('./miscellaneous.js');
var environment = require('./environment.js');
require('./font.js');
require('./math-4eaf20a0.js');
require('./characters.js');
require('./format.js');
require('./keycodes.js');
require('./url.js');
var web3 = require('./web3.js');
var constants = require('./constants.js');
require('./breakpoints.js');
require('./springs.js');
require('./text-styles.js');
require('./theme-dark.js');
require('./theme-light.js');
require('./Theme.js');
var _extends$1 = require('./extends-43472f94.js');
require('./index-766bccf9.js');
require('./defineProperty-7b1b81d8.js');
require('./isObject-b8c5dfc0.js');
require('./Viewport-0f56d694.js');
require('./Layout.js');
require('./FocusVisible.js');
require('./ButtonBase.js');
require('./IconPropTypes-68080ae8.js');
require('./IconAddUser.js');
require('./IconAlert.js');
require('./IconAlignCenter.js');
require('./IconAlignJustify.js');
require('./IconAlignLeft.js');
require('./IconAlignRight.js');
require('./IconAragon.js');
require('./IconArrowDown.js');
require('./IconArrowLeft.js');
require('./IconArrowRight.js');
require('./IconArrowUp.js');
require('./IconAtSign.js');
require('./IconBlock.js');
require('./IconBookmark.js');
require('./IconCalendar.js');
require('./IconCanvas.js');
require('./IconCaution.js');
require('./IconCenter.js');
require('./IconChart.js');
require('./IconChat.js');
require('./IconCheck.js');
require('./IconChip.js');
require('./IconCircleCheck.js');
require('./IconCircleMinus.js');
require('./IconCirclePlus.js');
require('./IconClock.js');
require('./IconCloudDownload.js');
require('./IconCloudUpload.js');
require('./IconCoin.js');
require('./IconConfiguration.js');
require('./IconConnect.js');
require('./IconConnection.js');
require('./IconConsole.js');
require('./IconCopy.js');
require('./IconCross.js');
require('./IconDashedSquare.js');
require('./IconDown.js');
require('./IconDownload.js');
require('./IconEdit.js');
require('./IconEllipsis.js');
require('./IconEnter.js');
require('./IconEthereum.js');
require('./IconExternal.js');
require('./IconFile.js');
require('./IconFilter.js');
require('./IconFlag.js');
require('./IconFolder.js');
require('./IconGraph2.js');
require('./IconGraph.js');
require('./IconGrid.js');
require('./IconGroup.js');
require('./IconHash.js');
require('./IconHeart.js');
require('./IconHide.js');
require('./IconHome.js');
require('./IconImage.js');
require('./IconInfo.js');
require('./IconLabel.js');
require('./IconLayers.js');
require('./IconLeft.js');
require('./IconLink.js');
require('./IconLocation.js');
require('./IconLock.js');
require('./IconMail.js');
require('./IconMaximize.js');
require('./IconMenu.js');
require('./IconMinimize.js');
require('./IconMinus.js');
require('./IconMove.js');
require('./IconNoPicture.js');
require('./IconPicture.js');
require('./IconPlus.js');
require('./IconPower.js');
require('./IconPrint.js');
require('./IconProhibited.js');
require('./IconQuestion.js');
require('./IconRefresh.js');
require('./IconRemoveUser.js');
require('./IconRight.js');
require('./IconRotateLeft.js');
require('./IconRotateRight.js');
require('./IconSearch.js');
require('./IconSettings.js');
require('./IconShare.js');
require('./IconSquareMinus.js');
require('./IconSquarePlus.js');
require('./IconSquare.js');
require('./IconStarFilled.js');
require('./IconStar.js');
require('./IconSwap.js');
require('./IconTarget.js');
require('./IconToken.js');
require('./IconTrash.js');
require('./IconUnlock.js');
require('./IconUp.js');
require('./IconUpload.js');
require('./IconUser.js');
require('./IconView.js');
require('./IconVote.js');
require('./IconWallet.js');
require('./IconWarning.js');
require('./IconWorld.js');
require('./IconWrite.js');
require('./IconZoomIn.js');
require('./IconZoomOut.js');
require('./objectWithoutPropertiesLoose-d28f0f6e.js');
require('react-dom');
require('./web-449fa78f.js');
require('./Button.js');
require('./ButtonIcon.js');
require('./getDisplayName-7ab6d318.js');
require('./index-70be9e8d.js');
require('./Link.js');
require('./TextInput.js');
require('./index-d200e416.js');
require('./RootPortal.js');
require('./ToastHub.js');
require('./TextCopy.js');
require('./_react_commonjs-external-bf8fc71c.js');
require('./EthIdenticon.js');
require('./AddressField.js');
require('./useArrowKeysFocus.js');
require('./useClickOutside.js');
require('./useFocusEnter.js');
require('./useFocusLeave.js');
var useImageExists = require('./useImageExists.js');
require('./useKeyDown.js');
require('./useOnBlur.js');
var BadgeBase = require('./BadgeBase.js');
require('./BadgePopoverActionType.js');
require('./proptypes-70c08808.js');
require('./Popover.js');
require('./observe.js');
require('./index-aa9c1462.js');
require('./providers.js');
require('./BadgePopoverBase.js');
var TokenBadgePopover = require('./TokenBadgePopover.js');

const TokenBadge = /*#__PURE__*/React__default.memo(function TokenBadge(_ref) {
  let {
    address,
    badgeOnly,
    className,
    compact,
    name,
    networkType,
    style,
    symbol
  } = _ref;
  const badgeRef = React.useRef(null);
  const [opened, setOpened] = React.useState(false);
  const handleClose = React.useCallback(() => setOpened(false), []);
  const handleOpen = React.useCallback(() => setOpened(true), []);
  const isValidAddress = web3.isAddress(address);
  const iconSrc = isValidAddress && networkType === 'main' ? web3.tokenIconUrl(address) : null;
  const title = name && symbol ? `${name} (${symbol})` : symbol;
  if (!isValidAddress) {
    environment.warn(`TokenBadge: provided invalid address (${address})`);
  }
  return /*#__PURE__*/React__default.createElement(BadgeBase.default, {
    badgeRef: badgeRef,
    className: className,
    compact: compact,
    disabled: badgeOnly,
    icon: /*#__PURE__*/React__default.createElement(useImageExists.ImageExists, {
      src: iconSrc
    }, _ref2 => {
      let {
        exists
      } = _ref2;
      return exists && /*#__PURE__*/React__default.createElement(Icon, {
        compact: compact,
        src: iconSrc
      });
    }),
    label: /*#__PURE__*/React__default.createElement(_StyledSpan, {
      $_css: compact ? 0 : `${1 * constants.GU}px`
    }, name && /*#__PURE__*/React__default.createElement(Name, null, name), /*#__PURE__*/React__default.createElement(Symbol, null, name ? `(${symbol})` : symbol)),
    onClick: isValidAddress ? handleOpen : undefined,
    style: style,
    title: `${title} − ${address || 'No address'}`
  }, popoverDisabled => !popoverDisabled && address && /*#__PURE__*/React__default.createElement(TokenBadgePopover.default, {
    address: address,
    iconSrc: iconSrc,
    networkType: networkType,
    onClose: handleClose,
    opener: badgeRef.current,
    title: title,
    visible: opened
  }));
});
TokenBadge.propTypes = {
  address: index.PropTypes.string,
  badgeOnly: index.PropTypes.bool,
  className: index.PropTypes.string,
  compact: index.PropTypes.bool,
  name: index.PropTypes.string,
  networkType: index.PropTypes.string,
  style: index.PropTypes.object,
  symbol: index.PropTypes.string.isRequired
};
TokenBadge.defaultProps = {
  address: '',
  name: '',
  networkType: 'main'
};
function Icon(_ref3) {
  let {
    compact,
    src,
    ...props
  } = _ref3;
  const margin = 1 * constants.GU;
  return /*#__PURE__*/React__default.createElement(_StyledSpan2, _extends$1._extends({}, props, {
    $_css2: compact ? margin : 0,
    $_css3: compact ? 0 : margin,
    $_css4: src
  }));
}
Icon.propTypes = {
  compact: index.PropTypes.bool,
  src: index.PropTypes.string.isRequired
};
const Name = _styled__default.span.withConfig({
  displayName: "TokenBadge__Name",
  componentId: "sc-gdrzzo-0"
})(["flex-shrink:1;overflow:hidden;text-overflow:ellipsis;min-width:20%;margin-right:", "px;"], 0.5 * constants.GU);
const Symbol = _styled__default.span.withConfig({
  displayName: "TokenBadge__Symbol",
  componentId: "sc-gdrzzo-1"
})(["flex-shrink:0;"]);
var _StyledSpan = _styled__default("span").withConfig({
  displayName: "TokenBadge___StyledSpan",
  componentId: "sc-gdrzzo-2"
})(["position:relative;top:1px;display:flex;flex-shrink:1;min-width:0;margin-left:", ";"], p => p.$_css);
var _StyledSpan2 = _styled__default("span").withConfig({
  displayName: "TokenBadge___StyledSpan2",
  componentId: "sc-gdrzzo-3"
})(["flex-shrink:0;display:block;width:18px;height:18px;margin:0 ", "px 0 ", "px;background-size:contain;background-position:50% 50%;background-repeat:no-repeat;background-image:url(", ");"], p => p.$_css2, p => p.$_css3, p => p.$_css4);

exports.default = TokenBadge;
//# sourceMappingURL=TokenBadge.js.map
