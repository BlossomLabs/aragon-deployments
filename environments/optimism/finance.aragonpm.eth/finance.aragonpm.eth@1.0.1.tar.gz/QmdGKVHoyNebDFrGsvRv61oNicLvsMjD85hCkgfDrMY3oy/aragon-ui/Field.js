'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

function _interopDefault (ex) { return (ex && (typeof ex === 'object') && 'default' in ex) ? ex['default'] : ex; }

var React = require('react');
var React__default = _interopDefault(React);
require('./_commonjsHelpers-72d386ba.js');
var index = require('./index-c8446775.js');
var _styled = require('styled-components');
var _styled__default = _interopDefault(_styled);
require('./color.js');
require('./components.js');
require('./contains-component.js');
var css = require('./css.js');
require('./dayjs.min-966150e3.js');
require('./date.js');
require('./miscellaneous.js');
require('./environment.js');
require('./font.js');
require('./math-4eaf20a0.js');
require('./characters.js');
require('./format.js');
require('./keycodes.js');
require('./url.js');
require('./web3.js');
var constants = require('./constants.js');
require('./breakpoints.js');
require('./springs.js');
var textStyles = require('./text-styles.js');
require('./theme-dark.js');
require('./theme-light.js');
var Theme = require('./Theme.js');
var _extends$1 = require('./extends-43472f94.js');
var index$1 = require('./index-766bccf9.js');

// This variable is used as a simple mechanism to generate unique IDs, that can
// be used to link the <label> to a specific form element by using a render
// prop. See `children` in the Field documentation for more details.
let fieldId = 1;
function Field(_ref) {
  let {
    children,
    label,
    required,
    ...props
  } = _ref;
  const theme = Theme.useTheme();
  const isRequired = required || React__default.Children.toArray(children).some(_ref2 => {
    let {
      props
    } = _ref2;
    return props && props.required;
  });
  const id = React.useMemo(() => typeof children === 'function' ? `Field_${fieldId++}` : null, [children]);
  const labelProps = id === null ? {} : {
    htmlFor: id
  };
  return /*#__PURE__*/React__default.createElement(index$1.i, {
    name: "Field"
  }, /*#__PURE__*/React__default.createElement(_StyledDiv, _extends$1._extends({}, props, {
    $_css: 3 * constants.GU
  }), /*#__PURE__*/React__default.createElement("label", labelProps, /*#__PURE__*/React__default.createElement(_StyledDiv2, {
    $_css2: 2 * constants.GU,
    $_css3: 0.5 * constants.GU,
    $_css4: theme.surfaceContentSecondary,
    $_css5: textStyles.textStyle('label2')
  }, /*#__PURE__*/React__default.createElement(index$1.i, {
    name: "Field:label"
  }, label, isRequired && /*#__PURE__*/React__default.createElement(_StyledSpan, {
    title: "Required",
    $_css6: theme.accent
  }, '\u00a0*'))), /*#__PURE__*/React__default.createElement(index$1.i, {
    name: "Field:content"
  }, typeof children === 'function' ? children({
    id
  }) : children))));
}
Field.propTypes = {
  children: index.PropTypes.oneOfType([index.PropTypes.node, index.PropTypes.func]),
  label: index.PropTypes.node,
  required: index.PropTypes.bool
};
var _StyledDiv = _styled__default("div").withConfig({
  displayName: "Field___StyledDiv",
  componentId: "sc-6b7idx-0"
})(["margin-bottom:", "px;"], p => p.$_css);
var _StyledDiv2 = _styled__default("div").withConfig({
  displayName: "Field___StyledDiv2",
  componentId: "sc-6b7idx-1"
})(["display:flex;align-items:center;height:", "px;margin-bottom:", "px;color:", ";white-space:nowrap;", ";", ";"], p => p.$_css2, p => p.$_css3, p => p.$_css4, p => p.$_css5, css.unselectable);
var _StyledSpan = _styled__default("span").withConfig({
  displayName: "Field___StyledSpan",
  componentId: "sc-6b7idx-2"
})(["color:", ";"], p => p.$_css6);

exports.default = Field;
//# sourceMappingURL=Field.js.map
