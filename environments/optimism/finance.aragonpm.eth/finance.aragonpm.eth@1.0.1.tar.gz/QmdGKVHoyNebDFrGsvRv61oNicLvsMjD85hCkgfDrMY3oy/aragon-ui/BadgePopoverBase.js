'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

function _interopDefault (ex) { return (ex && (typeof ex === 'object') && 'default' in ex) ? ex['default'] : ex; }

var React = require('react');
var React__default = _interopDefault(React);
require('./_commonjsHelpers-72d386ba.js');
require('./index-c8446775.js');
var _styled = require('styled-components');
var _styled__default = _interopDefault(_styled);
require('./color.js');
require('./components.js');
require('./contains-component.js');
require('./css.js');
require('./dayjs.min-966150e3.js');
require('./date.js');
var miscellaneous = require('./miscellaneous.js');
require('./environment.js');
require('./font.js');
require('./math-4eaf20a0.js');
require('./characters.js');
require('./format.js');
require('./keycodes.js');
require('./url.js');
require('./web3.js');
var constants = require('./constants.js');
require('./breakpoints.js');
require('./springs.js');
var textStyles = require('./text-styles.js');
require('./theme-dark.js');
require('./theme-light.js');
var Theme = require('./Theme.js');
require('./extends-43472f94.js');
require('./index-766bccf9.js');
require('./defineProperty-7b1b81d8.js');
require('./isObject-b8c5dfc0.js');
require('./Viewport-0f56d694.js');
require('./Layout.js');
require('./FocusVisible.js');
require('./ButtonBase.js');
require('./IconPropTypes-68080ae8.js');
require('./IconAddUser.js');
require('./IconAlert.js');
require('./IconAlignCenter.js');
require('./IconAlignJustify.js');
require('./IconAlignLeft.js');
require('./IconAlignRight.js');
require('./IconAragon.js');
require('./IconArrowDown.js');
require('./IconArrowLeft.js');
require('./IconArrowRight.js');
require('./IconArrowUp.js');
require('./IconAtSign.js');
require('./IconBlock.js');
require('./IconBookmark.js');
require('./IconCalendar.js');
require('./IconCanvas.js');
require('./IconCaution.js');
require('./IconCenter.js');
require('./IconChart.js');
require('./IconChat.js');
require('./IconCheck.js');
require('./IconChip.js');
require('./IconCircleCheck.js');
require('./IconCircleMinus.js');
require('./IconCirclePlus.js');
require('./IconClock.js');
require('./IconCloudDownload.js');
require('./IconCloudUpload.js');
require('./IconCoin.js');
require('./IconConfiguration.js');
require('./IconConnect.js');
require('./IconConnection.js');
require('./IconConsole.js');
require('./IconCopy.js');
var IconCross = require('./IconCross.js');
require('./IconDashedSquare.js');
require('./IconDown.js');
require('./IconDownload.js');
require('./IconEdit.js');
require('./IconEllipsis.js');
require('./IconEnter.js');
require('./IconEthereum.js');
require('./IconExternal.js');
require('./IconFile.js');
require('./IconFilter.js');
require('./IconFlag.js');
require('./IconFolder.js');
require('./IconGraph2.js');
require('./IconGraph.js');
require('./IconGrid.js');
require('./IconGroup.js');
require('./IconHash.js');
require('./IconHeart.js');
require('./IconHide.js');
require('./IconHome.js');
require('./IconImage.js');
require('./IconInfo.js');
require('./IconLabel.js');
require('./IconLayers.js');
require('./IconLeft.js');
require('./IconLink.js');
require('./IconLocation.js');
require('./IconLock.js');
require('./IconMail.js');
require('./IconMaximize.js');
require('./IconMenu.js');
require('./IconMinimize.js');
require('./IconMinus.js');
require('./IconMove.js');
require('./IconNoPicture.js');
require('./IconPicture.js');
require('./IconPlus.js');
require('./IconPower.js');
require('./IconPrint.js');
require('./IconProhibited.js');
require('./IconQuestion.js');
require('./IconRefresh.js');
require('./IconRemoveUser.js');
require('./IconRight.js');
require('./IconRotateLeft.js');
require('./IconRotateRight.js');
require('./IconSearch.js');
require('./IconSettings.js');
require('./IconShare.js');
require('./IconSquareMinus.js');
require('./IconSquarePlus.js');
require('./IconSquare.js');
require('./IconStarFilled.js');
require('./IconStar.js');
require('./IconSwap.js');
require('./IconTarget.js');
require('./IconToken.js');
require('./IconTrash.js');
require('./IconUnlock.js');
require('./IconUp.js');
require('./IconUpload.js');
require('./IconUser.js');
require('./IconView.js');
require('./IconVote.js');
require('./IconWallet.js');
require('./IconWarning.js');
require('./IconWorld.js');
require('./IconWrite.js');
require('./IconZoomIn.js');
require('./IconZoomOut.js');
require('./objectWithoutPropertiesLoose-d28f0f6e.js');
require('react-dom');
require('./web-449fa78f.js');
var Button = require('./Button.js');
var ButtonIcon = require('./ButtonIcon.js');
require('./getDisplayName-7ab6d318.js');
require('./index-70be9e8d.js');
require('./index-d200e416.js');
require('./RootPortal.js');
var BadgePopoverActionType = require('./BadgePopoverActionType.js');
var proptypes = require('./proptypes-70c08808.js');
var Popover = require('./Popover.js');
require('./observe.js');
require('./index-aa9c1462.js');
require('./providers.js');

const BadgePopoverBase = /*#__PURE__*/React__default.memo(function BadgePopoverBase(_ref) {
  let {
    addressField,
    link,
    onClose,
    opener,
    popoverAction,
    title,
    titleTag,
    visible
  } = _ref;
  const theme = Theme.useTheme();
  const handlePopoverActionClick = React.useCallback(() => {
    onClose();
    if (popoverAction && popoverAction.onClick) {
      popoverAction.onClick();
    }
  }, [onClose, popoverAction]);
  return /*#__PURE__*/React__default.createElement(Popover.default, {
    visible: visible,
    opener: opener,
    onClose: onClose
  }, /*#__PURE__*/React__default.createElement(_StyledSection, null, /*#__PURE__*/React__default.createElement(_StyledButtonIcon, {
    label: "Close",
    onClick: onClose,
    $_css: theme.surfaceIcon
  }, /*#__PURE__*/React__default.createElement(IconCross.default, {
    size: "small"
  })), /*#__PURE__*/React__default.createElement(_StyledHeader, {
    $_css2: 4 * constants.GU,
    $_css3: 2 * constants.GU,
    $_css4: theme.border
  }, /*#__PURE__*/React__default.createElement(_StyledH, {
    $_css5: textStyles.textStyle('label2'),
    $_css6: theme.surfaceContentSecondary
  }, title), titleTag), /*#__PURE__*/React__default.createElement(_StyledDiv, {
    $_css7: 2 * constants.GU
  }, addressField, /*#__PURE__*/React__default.createElement(_StyledDiv2, {
    $_css8: 2 * constants.GU,
    $_css9: link ? `
                  flex-direction: row-reverse;
                  justify-content: space-between;
                ` : ''
  }, link && /*#__PURE__*/React__default.createElement(_StyledP, {
    $_css10: textStyles.textStyle('body3')
  }, link), popoverAction && /*#__PURE__*/React__default.createElement(_StyledButton, {
    size: "medium",
    onClick: handlePopoverActionClick,
    $_css11: 2 * constants.GU,
    $_css12: theme.surfaceContentSecondary
  }, popoverAction.label)))));
});
BadgePopoverBase.propTypes = {
  addressField: proptypes.PropTypes.node.isRequired,
  link: proptypes.PropTypes.node,
  onClose: proptypes.PropTypes.func,
  opener: proptypes.PropTypes._element,
  popoverAction: BadgePopoverActionType.default,
  title: proptypes.PropTypes.node.isRequired,
  titleTag: proptypes.PropTypes.node,
  visible: proptypes.PropTypes.bool
};
BadgePopoverBase.defaultProps = {
  onClose: miscellaneous.noop
};
var _StyledSection = _styled__default("section").withConfig({
  displayName: "BadgePopoverBase___StyledSection",
  componentId: "sc-ixm5fk-0"
})(["position:relative;max-width:calc(100vw - 20px);min-width:300px;"]);
var _StyledButtonIcon = _styled__default(ButtonIcon.default).withConfig({
  displayName: "BadgePopoverBase___StyledButtonIcon",
  componentId: "sc-ixm5fk-1"
})(["position:absolute;top:0;right:0;border-radius:0;color:", ";"], p => p.$_css);
var _StyledHeader = _styled__default("header").withConfig({
  displayName: "BadgePopoverBase___StyledHeader",
  componentId: "sc-ixm5fk-2"
})(["display:flex;align-items:center;height:", "px;padding-left:", "px;border-bottom:1px solid ", ";"], p => p.$_css2, p => p.$_css3, p => p.$_css4);
var _StyledH = _styled__default("h1").withConfig({
  displayName: "BadgePopoverBase___StyledH",
  componentId: "sc-ixm5fk-3"
})(["", " font-weight:400;color:", ";"], p => p.$_css5, p => p.$_css6);
var _StyledDiv = _styled__default("div").withConfig({
  displayName: "BadgePopoverBase___StyledDiv",
  componentId: "sc-ixm5fk-4"
})(["padding:", "px;"], p => p.$_css7);
var _StyledDiv2 = _styled__default("div").withConfig({
  displayName: "BadgePopoverBase___StyledDiv2",
  componentId: "sc-ixm5fk-5"
})(["display:flex;margin-top:", "px;", ""], p => p.$_css8, p => p.$_css9);
var _StyledP = _styled__default("p").withConfig({
  displayName: "BadgePopoverBase___StyledP",
  componentId: "sc-ixm5fk-6"
})(["", ";"], p => p.$_css10);
var _StyledButton = _styled__default(Button.default).withConfig({
  displayName: "BadgePopoverBase___StyledButton",
  componentId: "sc-ixm5fk-7"
})(["padding:0 ", "px;color:", ";"], p => p.$_css11, p => p.$_css12);

exports.default = BadgePopoverBase;
//# sourceMappingURL=BadgePopoverBase.js.map
