'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

function _interopDefault (ex) { return (ex && (typeof ex === 'object') && 'default' in ex) ? ex['default'] : ex; }

var React = require('react');
var React__default = _interopDefault(React);
require('./_commonjsHelpers-72d386ba.js');
var index = require('./index-c8446775.js');
var _styled = require('styled-components');
var _styled__default = _interopDefault(_styled);
require('./color.js');
require('./components.js');
require('./contains-component.js');
require('./css.js');
require('./dayjs.min-966150e3.js');
require('./date.js');
var miscellaneous = require('./miscellaneous.js');
require('./environment.js');
require('./font.js');
require('./math-4eaf20a0.js');
require('./characters.js');
require('./format.js');
require('./keycodes.js');
require('./url.js');
require('./web3.js');
var constants = require('./constants.js');
require('./breakpoints.js');
var springs = require('./springs.js');
require('./text-styles.js');
require('./theme-dark.js');
require('./theme-light.js');
var Theme = require('./Theme.js');
require('./defineProperty-7b1b81d8.js');
var FocusVisible = require('./FocusVisible.js');
require('./objectWithoutPropertiesLoose-d28f0f6e.js');
require('react-dom');
var web = require('./web-449fa78f.js');

const BORDER = 1;
const WRAPPER_WIDTH = 5 * constants.GU;
const WRAPPER_HEIGHT = 2.25 * constants.GU;
function Switch(_ref) {
  let {
    checked,
    disabled,
    onChange
  } = _ref;
  const theme = Theme.useTheme();
  const [isFocused, setIsFocused] = React.useState(false);
  const handleChange = disabled ? miscellaneous.noop : () => onChange(!checked);
  return /*#__PURE__*/React__default.createElement(FocusVisible.default, null, _ref2 => {
    let {
      focusVisible,
      onFocus
    } = _ref2;
    return /*#__PURE__*/React__default.createElement(_StyledSpan, {
      onClick: e => {
        e.preventDefault();
        handleChange();
      },
      $_css: theme.border,
      $_css2: disabled ? theme.controlBorder : checked ? theme.selected : theme.control,
      $_css3: disabled ? 'default' : 'pointer',
      $_css4: disabled ? '' : `
                  &:active {
                    border-color: ${theme.controlBorderPressed};
                  }
                `,
      $_css5: isFocused && focusVisible ? `
                  &:after {
                    content: '';
                    position: absolute;
                    left: ${-BORDER * 2}px;
                    top: ${-BORDER * 2}px;
                    width: ${WRAPPER_WIDTH + BORDER * 2}px;
                    height: ${WRAPPER_HEIGHT + BORDER * 2}px;
                    border-radius: ${WRAPPER_HEIGHT}px;
                    border: 2px solid ${theme.focus};
                  }
                ` : ''
    }, /*#__PURE__*/React__default.createElement(_StyledInput, {
      type: "checkbox",
      onFocus: () => {
        setIsFocused(true);
        onFocus();
      },
      onBlur: () => setIsFocused(false),
      checked: checked,
      disabled: disabled,
      onChange: handleChange
    }), /*#__PURE__*/React__default.createElement(web.Spring, {
      to: {
        progress: checked ? WRAPPER_WIDTH - WRAPPER_HEIGHT + BORDER : BORDER
      },
      config: springs.springs.smooth,
      native: true
    }, _ref3 => {
      let {
        progress
      } = _ref3;
      return /*#__PURE__*/React__default.createElement(_StyledAnimatedSpan, {
        style: {
          transform: progress.interpolate(v => `translate3d(${v}px, 0, 0)`)
        },
        $_css6: WRAPPER_HEIGHT - BORDER * 4,
        $_css7: WRAPPER_HEIGHT - BORDER * 4,
        $_css8: WRAPPER_HEIGHT - BORDER * 4,
        $_css9: theme.controlSurface,
        $_css10: disabled ? 'none' : '0px 1px 3px rgba(0, 0, 0, 0.15)'
      });
    }));
  });
}
Switch.propTypes = {
  checked: index.PropTypes.bool,
  disabled: index.PropTypes.bool,
  onChange: index.PropTypes.func
};
Switch.defaultProps = {
  checked: false,
  disabled: false,
  onChange: miscellaneous.noop
};
var _StyledSpan = _styled__default("span").withConfig({
  displayName: "Switch___StyledSpan",
  componentId: "sc-17eybil-0"
})(["position:relative;display:inline-block;width:", "px;height:", "px;border:", "px solid ", ";border-radius:", "px;background-color:", ";cursor:", ";", " ", ";"], WRAPPER_WIDTH, WRAPPER_HEIGHT, BORDER, p => p.$_css, WRAPPER_HEIGHT, p => p.$_css2, p => p.$_css3, p => p.$_css4, p => p.$_css5);
var _StyledInput = _styled__default("input").withConfig({
  displayName: "Switch___StyledInput",
  componentId: "sc-17eybil-1"
})(["opacity:0;pointer-events:none;"]);
var _StyledAnimatedSpan = _styled__default(web.extendedAnimated.span).withConfig({
  displayName: "Switch___StyledAnimatedSpan",
  componentId: "sc-17eybil-2"
})(["position:absolute;left:0;z-index:1;top:", "px;width:", "px;height:", "px;border-radius:", "px;background-color:", ";box-shadow:", ";"], BORDER, p => p.$_css6, p => p.$_css7, p => p.$_css8, p => p.$_css9, p => p.$_css10);

exports.default = Switch;
//# sourceMappingURL=Switch.js.map
