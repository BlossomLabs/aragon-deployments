'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

function _interopDefault (ex) { return (ex && (typeof ex === 'object') && 'default' in ex) ? ex['default'] : ex; }

var React = require('react');
var React__default = _interopDefault(React);
require('./_commonjsHelpers-72d386ba.js');
var index = require('./index-c8446775.js');
var _styled = require('styled-components');
var _styled__default = _interopDefault(_styled);
require('./color.js');
require('./components.js');
require('./contains-component.js');
require('./css.js');
require('./dayjs.min-966150e3.js');
require('./date.js');
require('./miscellaneous.js');
var environment = require('./environment.js');
var font = require('./font.js');
require('./math-4eaf20a0.js');
require('./characters.js');
require('./format.js');
require('./keycodes.js');
require('./url.js');
require('./web3.js');
var _extends$1 = require('./extends-43472f94.js');

function Text(_ref) {
  let {
    children,
    color,
    deprecationNotice,
    monospace,
    size,
    smallcaps,
    weight,
    ...props
  } = _ref;
  if (deprecationNotice) {
    environment.warnOnce('Text', 'Text, Text.Block and Text.Paragraph are deprecated. ' + 'Please use the textStyle() utility function instead.');
  }
  return /*#__PURE__*/React__default.createElement(_StyledSpan, _extends$1._extends({}, props, {
    $_css: font.font({
      deprecationNotice: false,
      monospace,
      size,
      smallcaps,
      weight
    }),
    $_css2: color ? `color: ${color}` : ''
  }), children);
}
const Block = props => /*#__PURE__*/React__default.createElement(Text, _extends$1._extends({
  as: "div"
}, props));
const Paragraph = props => /*#__PURE__*/React__default.createElement(Text, _extends$1._extends({
  as: "p"
}, props));
Text.propTypes = Block.propTypes = Paragraph.propTypes = {
  children: index.PropTypes.node,
  color: index.PropTypes.string,
  deprecationNotice: index.PropTypes.bool,
  monospace: index.PropTypes.bool,
  size: index.PropTypes.string,
  smallcaps: index.PropTypes.bool,
  weight: index.PropTypes.string
};
Text.defaultProps = {
  deprecationNotice: true
};
Text.Block = Block;
Text.Paragraph = Paragraph;
var _StyledSpan = _styled__default("span").withConfig({
  displayName: "Text___StyledSpan",
  componentId: "sc-s07nzj-0"
})(["", ";", ";"], p => p.$_css, p => p.$_css2);

exports.default = Text;
//# sourceMappingURL=Text.js.map
