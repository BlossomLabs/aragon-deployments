'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

function _interopDefault (ex) { return (ex && (typeof ex === 'object') && 'default' in ex) ? ex['default'] : ex; }

var React = require('react');
var React__default = _interopDefault(React);
require('./_commonjsHelpers-72d386ba.js');
var index = require('./index-c8446775.js');
var _styled = require('styled-components');
var _styled__default = _interopDefault(_styled);
require('./color.js');
require('./components.js');
var containsComponent = require('./contains-component.js');
require('./css.js');
require('./dayjs.min-966150e3.js');
require('./date.js');
require('./miscellaneous.js');
require('./environment.js');
require('./font.js');
require('./math-4eaf20a0.js');
require('./characters.js');
require('./format.js');
require('./keycodes.js');
var url = require('./url.js');
require('./web3.js');
require('./constants.js');
require('./breakpoints.js');
require('./springs.js');
require('./text-styles.js');
require('./theme-dark.js');
require('./theme-light.js');
var Theme = require('./Theme.js');
require('./extends-43472f94.js');
require('./defineProperty-7b1b81d8.js');
require('./isObject-b8c5dfc0.js');
var Viewport = require('./Viewport-0f56d694.js');
var Layout = require('./Layout.js');
require('./objectWithoutPropertiesLoose-d28f0f6e.js');
require('react-dom');
require('./web-449fa78f.js');
require('./getDisplayName-7ab6d318.js');
var index$2 = require('./index-70be9e8d.js');
var index$1$1 = require('./index-d200e416.js');
require('./RootPortal.js');
var ToastHub = require('./ToastHub.js');
var BaseStyles = require('./BaseStyles.js');
var ScrollView = require('./ScrollView.js');

const {
  Provider: ContainsAppViewProvider,
  useContains: useContainsAppView,
  useRegister: useRegisterAppView
} = containsComponent.initContainsComponent();
function Main(_ref) {
  let {
    assetsUrl,
    children,
    layout,
    scrollView,
    theme
  } = _ref;
  const containsAppView = useContainsAppView();
  if (layout === undefined) {
    layout = !containsAppView;
  }
  if (scrollView === undefined) {
    scrollView = !containsAppView;
  }

  // Optionally wrap `children` with Layout and/or ScrollView
  let content = layout ? /*#__PURE__*/React__default.createElement(Layout.default, null, children) : children;
  content = scrollView ?
  /*#__PURE__*/
  // The main ScrollView is set to 100vh by default (best for Aragon apps)
  // Disable `scrollView` and insert your own if needed.
  React__default.createElement(_StyledScrollView, null, content) : content;
  return /*#__PURE__*/React__default.createElement(index$1$1.Root.Provider, null, /*#__PURE__*/React__default.createElement(Viewport.Viewport.Provider, null, /*#__PURE__*/React__default.createElement(index$2.PublicUrl.Provider, {
    url: url.ensureTrailingSlash(assetsUrl)
  }, /*#__PURE__*/React__default.createElement(Theme.Theme, {
    theme: theme
  }, /*#__PURE__*/React__default.createElement(BaseStyles.default, null), /*#__PURE__*/React__default.createElement(ToastHub.default, null, content)))));
}
Main.propTypes = {
  assetsUrl: index.PropTypes.string,
  children: index.PropTypes.node,
  layout: index.PropTypes.bool,
  scrollView: index.PropTypes.bool,
  theme: Theme.Theme.propTypes.theme
};
Main.defaultProps = {
  assetsUrl: './aragon-ui/'
};
var Main$1 = (props => /*#__PURE__*/React__default.createElement(ContainsAppViewProvider, null, /*#__PURE__*/React__default.createElement(Main, props)));
var _StyledScrollView = _styled__default(ScrollView.default).withConfig({
  displayName: "Main___StyledScrollView",
  componentId: "sc-hl194z-0"
})(["height:100vh"]);

exports.default = Main$1;
exports.useContainsAppView = useContainsAppView;
exports.useRegisterAppView = useRegisterAppView;
//# sourceMappingURL=Main.js.map
