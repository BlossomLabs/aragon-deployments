'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

const NO_BREAK_SPACE = '\u00a0';

exports.NO_BREAK_SPACE = NO_BREAK_SPACE;
//# sourceMappingURL=characters.js.map
