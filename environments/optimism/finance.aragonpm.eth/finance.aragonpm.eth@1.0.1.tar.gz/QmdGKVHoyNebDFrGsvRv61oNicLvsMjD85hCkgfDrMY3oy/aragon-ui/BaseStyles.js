'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

function _interopDefault (ex) { return (ex && (typeof ex === 'object') && 'default' in ex) ? ex['default'] : ex; }

var React = require('react');
var React__default = _interopDefault(React);
require('./_commonjsHelpers-72d386ba.js');
var index = require('./index-c8446775.js');
var _styled = require('styled-components');
var _styled__default = _interopDefault(_styled);
require('./color.js');
require('./components.js');
require('./contains-component.js');
require('./css.js');
require('./dayjs.min-966150e3.js');
require('./date.js');
require('./miscellaneous.js');
require('./environment.js');
var font = require('./font.js');
require('./math-4eaf20a0.js');
require('./characters.js');
require('./format.js');
require('./keycodes.js');
require('./url.js');
require('./web3.js');
require('./constants.js');
require('./breakpoints.js');
require('./springs.js');
var textStyles = require('./text-styles.js');
require('./theme-dark.js');
require('./theme-light.js');
var Theme = require('./Theme.js');
var _extends$1 = require('./extends-43472f94.js');
require('./defineProperty-7b1b81d8.js');
require('./getDisplayName-7ab6d318.js');
var index$2 = require('./index-70be9e8d.js');

var overpassLightWoff2 = "cf790334a5a6d45c.woff2";

var overpassRegularWoff2 = "32a3f11e7740ce58.woff2";

var overpassSemiBoldWoff2 = "5cfe62515c2f9b42.woff2";

var overpassMonoLightWoff2 = "3dd21d4f0d28fecb.woff2";

const DEFAULT_FONTS = {
  '400': {
    url: overpassLightWoff2,
    format: 'woff2'
  },
  '600': {
    url: overpassRegularWoff2,
    format: 'woff2'
  },
  '800': {
    url: overpassSemiBoldWoff2,
    format: 'woff2'
  }
};
const MONOSPACE_FONTS = {
  '400': {
    url: overpassMonoLightWoff2,
    format: 'woff2'
  }
};
function fontSrc(publicUrl, _ref) {
  let {
    url,
    format
  } = _ref;
  return `url(${publicUrl + url}) format('${format}')`;
}
function fontFaceDeclarations(_ref2) {
  let {
    fontFamily,
    publicUrl
  } = _ref2;
  // No need to declare the font faces if the font family has changed.
  if (fontFamily !== BaseStyles.defaultProps.fontFamily) {
    return '';
  }
  return `
    @font-face {
      font-family: ${font.DEFAULT_FONT_FAMILY};
      src: ${fontSrc(publicUrl, DEFAULT_FONTS['400'])};
      font-weight: 400;
      font-style: normal;
    }
    @font-face {
      font-family: ${font.DEFAULT_FONT_FAMILY};
      src: ${fontSrc(publicUrl, DEFAULT_FONTS['600'])};
      font-weight: 600;
      font-style: normal;
    }
    @font-face {
      font-family: ${font.DEFAULT_FONT_FAMILY};
      src: ${fontSrc(publicUrl, DEFAULT_FONTS['800'])};
      font-weight: 800;
      font-style: normal;
    }
    @font-face {
      font-family: ${font.MONOSPACE_FONT_FAMILY};
      src: ${fontSrc(publicUrl, MONOSPACE_FONTS['400'])};
      font-weight: 400;
      font-style: normal;
    }
  `;
}
const BaseStyles = /*#__PURE__*/React__default.memo(function BaseStyles(props) {
  const theme = Theme.useTheme();
  return /*#__PURE__*/React__default.createElement(GlobalStyle, _extends$1._extends({}, props, {
    theme: theme,
    fontFaces: fontFaceDeclarations(props),
    textStyleCss: textStyles.textStyle('body2')
  }));
});
BaseStyles.propTypes = {
  publicUrl: index.PropTypes.string,
  fontFamily: index.PropTypes.string
};
BaseStyles.defaultProps = {
  publicUrl: '/',
  fontFamily: `${font.DEFAULT_FONT_FAMILY}, sans-serif`
};
const GlobalStyle = _styled.createGlobalStyle(["", " *,*:before,*:after{box-sizing:border-box;}html{-webkit-overflow-scrolling:touch;}body{height:0;min-height:100vh;color:", ";background:", ";font-family:", ";", ";}html,body{overflow:hidden;}body,ul,p,h1,h2,h3,h4,h5,h6{margin:0;padding:0;}button,select,input,textarea,h1,h2,h3,h4,h5,h6{font-size:inherit;font-family:inherit;font-weight:inherit;line-height:inherit;}a,button,select,input,textarea{color:inherit;}strong,b{font-weight:600;}::selection{background:", ";color:", ";}"], p => p.fontFaces ? p.fontFaces : '', p => p.theme.content, p => p.theme.background, p => p.fontFamily, p => p.textStyleCss, p => p.theme.selected, p => p.theme.selectedContent);
var BaseStyles$1 = index$2.PublicUrl.hocWrap(BaseStyles);

exports.default = BaseStyles$1;
//# sourceMappingURL=BaseStyles.js.map
