'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

function _interopDefault (ex) { return (ex && (typeof ex === 'object') && 'default' in ex) ? ex['default'] : ex; }

var React = require('react');
var React__default = _interopDefault(React);
require('./_commonjsHelpers-72d386ba.js');
var index = require('./index-c8446775.js');
var _styled = require('styled-components');
var _styled__default = _interopDefault(_styled);
require('./color.js');
require('./components.js');
require('./contains-component.js');
var css = require('./css.js');
require('./dayjs.min-966150e3.js');
require('./date.js');
var miscellaneous = require('./miscellaneous.js');
require('./environment.js');
require('./font.js');
require('./math-4eaf20a0.js');
require('./characters.js');
require('./format.js');
var keycodes = require('./keycodes.js');
require('./url.js');
require('./web3.js');
require('./constants.js');
require('./breakpoints.js');
var springs = require('./springs.js');
require('./text-styles.js');
require('./theme-dark.js');
require('./theme-light.js');
var Theme = require('./Theme.js');
var _extends$1 = require('./extends-43472f94.js');
require('./index-766bccf9.js');
require('./defineProperty-7b1b81d8.js');
require('./isObject-b8c5dfc0.js');
require('./Viewport-0f56d694.js');
require('./Layout.js');
require('./FocusVisible.js');
var ButtonBase = require('./ButtonBase.js');
require('./IconPropTypes-68080ae8.js');
require('./IconAddUser.js');
require('./IconAlert.js');
require('./IconAlignCenter.js');
require('./IconAlignJustify.js');
require('./IconAlignLeft.js');
require('./IconAlignRight.js');
require('./IconAragon.js');
require('./IconArrowDown.js');
require('./IconArrowLeft.js');
require('./IconArrowRight.js');
require('./IconArrowUp.js');
require('./IconAtSign.js');
require('./IconBlock.js');
require('./IconBookmark.js');
require('./IconCalendar.js');
require('./IconCanvas.js');
require('./IconCaution.js');
require('./IconCenter.js');
require('./IconChart.js');
require('./IconChat.js');
require('./IconCheck.js');
require('./IconChip.js');
require('./IconCircleCheck.js');
require('./IconCircleMinus.js');
require('./IconCirclePlus.js');
require('./IconClock.js');
require('./IconCloudDownload.js');
require('./IconCloudUpload.js');
require('./IconCoin.js');
require('./IconConfiguration.js');
require('./IconConnect.js');
require('./IconConnection.js');
require('./IconConsole.js');
require('./IconCopy.js');
require('./IconCross.js');
require('./IconDashedSquare.js');
require('./IconDown.js');
require('./IconDownload.js');
require('./IconEdit.js');
require('./IconEllipsis.js');
require('./IconEnter.js');
require('./IconEthereum.js');
require('./IconExternal.js');
require('./IconFile.js');
require('./IconFilter.js');
require('./IconFlag.js');
require('./IconFolder.js');
require('./IconGraph2.js');
require('./IconGraph.js');
require('./IconGrid.js');
require('./IconGroup.js');
require('./IconHash.js');
require('./IconHeart.js');
require('./IconHide.js');
require('./IconHome.js');
require('./IconImage.js');
require('./IconInfo.js');
require('./IconLabel.js');
require('./IconLayers.js');
require('./IconLeft.js');
require('./IconLink.js');
require('./IconLocation.js');
require('./IconLock.js');
require('./IconMail.js');
require('./IconMaximize.js');
require('./IconMenu.js');
require('./IconMinimize.js');
require('./IconMinus.js');
require('./IconMove.js');
require('./IconNoPicture.js');
require('./IconPicture.js');
require('./IconPlus.js');
require('./IconPower.js');
require('./IconPrint.js');
require('./IconProhibited.js');
require('./IconQuestion.js');
require('./IconRefresh.js');
require('./IconRemoveUser.js');
require('./IconRight.js');
require('./IconRotateLeft.js');
require('./IconRotateRight.js');
require('./IconSearch.js');
require('./IconSettings.js');
require('./IconShare.js');
require('./IconSquareMinus.js');
require('./IconSquarePlus.js');
require('./IconSquare.js');
require('./IconStarFilled.js');
require('./IconStar.js');
require('./IconSwap.js');
require('./IconTarget.js');
require('./IconToken.js');
require('./IconTrash.js');
require('./IconUnlock.js');
require('./IconUp.js');
require('./IconUpload.js');
require('./IconUser.js');
require('./IconView.js');
require('./IconVote.js');
require('./IconWallet.js');
require('./IconWarning.js');
require('./IconWorld.js');
require('./IconWrite.js');
require('./IconZoomIn.js');
require('./IconZoomOut.js');
require('./objectWithoutPropertiesLoose-d28f0f6e.js');
require('react-dom');
var web = require('./web-449fa78f.js');
require('./Button.js');
require('./ButtonIcon.js');
require('./TextInput.js');
var useArrowKeysFocus = require('./useArrowKeysFocus.js');
var useClickOutside = require('./useClickOutside.js');
require('./useFocusEnter.js');
var useFocusLeave = require('./useFocusLeave.js');
require('./useImageExists.js');
var useKeyDown = require('./useKeyDown.js');
require('./useOnBlur.js');
var SearchInput = require('./SearchInput.js');

function AutoComplete(_ref) {
  let {
    forwardedRef,
    itemButtonStyles = '',
    items = [],
    onSelect = miscellaneous.noop,
    onChange = miscellaneous.noop,
    placeholder,
    renderItem = miscellaneous.identity,
    required,
    value,
    wide
  } = _ref;
  const ref = forwardedRef;
  const uniqueItems = new Set(items);
  const [opened, setOpened] = React.useState(true);
  const wrapRef = React.useRef();
  const refs = React.useRef([]);
  const handleClose = React.useCallback(() => setOpened(false), []);
  const handleFocus = React.useCallback(() => setOpened(true), []);
  const handleSelect = React.useCallback(item => {
    onSelect(item);
    setOpened(false);
  }, [onSelect]);
  const handleInputChange = React.useCallback(function () {
    setOpened(true);
    onChange(...arguments);
  }, [onChange]);
  const {
    handleFocusLeave
  } = useFocusLeave.useFocusLeave(handleClose, wrapRef);
  const {
    highlightedIndex,
    setHighlightedIndex
  } = useArrowKeysFocus.useArrowKeysFocus(refs);
  useClickOutside.useClickOutside(handleClose, wrapRef);
  useKeyDown.useKeyDown(keycodes.KEY_ESC, handleClose);
  React.useEffect(() => {
    setHighlightedIndex(-1);
  }, [opened, items, value, setHighlightedIndex]);
  return /*#__PURE__*/React__default.createElement(_StyledDiv, {
    ref: wrapRef,
    onBlur: handleFocusLeave
  }, /*#__PURE__*/React__default.createElement(SearchInput.default, {
    ref: ref,
    wide: wide,
    placeholder: placeholder,
    required: required,
    onChange: handleInputChange,
    onFocus: handleFocus,
    value: value
  }), /*#__PURE__*/React__default.createElement(web.Transition, {
    config: springs.springs.swift,
    items: opened && items.length > 0,
    from: {
      scale: 0.98,
      opacity: 0
    },
    enter: {
      scale: 1,
      opacity: 1
    },
    leave: {
      scale: 1,
      opacity: 0
    },
    native: true
  }, show => show && ( /* eslint-disable react/prop-types */
  _ref2 => {
    let {
      scale,
      opacity
    } = _ref2;
    return /*#__PURE__*/React__default.createElement(Items, {
      style: {
        opacity,
        transform: scale.interpolate(t => `scale3d(${t},${t},1)`)
      }
    }, Array.from(uniqueItems).map((item, index) => /*#__PURE__*/React__default.createElement(Item, {
      key: item.key || item,
      ref: node => refs.current[index] = node,
      index: index,
      item: item,
      itemButtonStyles: itemButtonStyles,
      onHighlight: setHighlightedIndex,
      onSelect: handleSelect,
      selected: index === highlightedIndex
    }, renderItem(item, value))));
  })
  /* eslint-enable react/prop-types */));
}

AutoComplete.propTypes = {
  forwardedRef: index.PropTypes.object,
  itemButtonStyles: index.PropTypes.string,
  items: index.PropTypes.array.isRequired,
  onSelect: index.PropTypes.func.isRequired,
  onChange: index.PropTypes.func.isRequired,
  placeholder: index.PropTypes.string,
  renderItem: index.PropTypes.func,
  required: index.PropTypes.bool,
  value: index.PropTypes.string,
  wide: index.PropTypes.bool
};

/* eslint-disable react/prop-types */
const Item = /*#__PURE__*/React__default.forwardRef(function Item(_ref3, ref) {
  let {
    children,
    index,
    item,
    itemButtonStyles,
    onHighlight,
    onSelect,
    selected
  } = _ref3;
  const theme = Theme.useTheme();
  const handleClick = React.useCallback(event => {
    event.preventDefault();
    onSelect(item);
  }, [item, onSelect]);
  const handleFocusOrMouseOver = React.useCallback(() => {
    onHighlight(index);
  }, [index, onHighlight]);
  return /*#__PURE__*/React__default.createElement(_StyledLi, {
    role: "option",
    $_css: css.unselectable()
  }, /*#__PURE__*/React__default.createElement(_StyledButtonBase, {
    ref: ref,
    onClick: handleClick,
    onFocus: handleFocusOrMouseOver,
    onMouseOver: handleFocusOrMouseOver,
    $_css2: selected ? `
                outline: 2px solid ${theme.accent};
                background: ${theme.surfaceHighlight};
                border-left: 3px solid ${theme.accent};
              ` : '',
    $_css3: itemButtonStyles
  }, children));
});
/* eslint-enable react/prop-types */

/* eslint-disable react/prop-types */
const Items = function Items(props) {
  const theme = Theme.useTheme();
  return /*#__PURE__*/React__default.createElement(_StyledAnimatedUl, _extends$1._extends({
    role: "listbox"
  }, props, {
    $_css4: theme.surfaceContent,
    $_css5: theme.surface,
    $_css6: theme.border
  }));
};
/* eslint-enable react/prop-types */

const AutoCompleteMemo = /*#__PURE__*/React__default.memo(AutoComplete);
var AutoComplete$1 = /*#__PURE__*/React__default.forwardRef((props, ref) => /*#__PURE__*/React__default.createElement(AutoCompleteMemo, _extends$1._extends({}, props, {
  forwardedRef: ref
})));
var _StyledDiv = _styled__default("div").withConfig({
  displayName: "AutoComplete___StyledDiv",
  componentId: "sc-d82x2h-0"
})(["position:relative"]);
var _StyledLi = _styled__default("li").withConfig({
  displayName: "AutoComplete___StyledLi",
  componentId: "sc-d82x2h-1"
})(["overflow:hidden;cursor:pointer;", ";"], p => p.$_css);
var _StyledButtonBase = _styled__default(ButtonBase.default).withConfig({
  displayName: "AutoComplete___StyledButtonBase",
  componentId: "sc-d82x2h-2"
})(["text-align:left;padding:4px 8px;width:100%;border-radius:0;border-left:3px solid transparent;cursor:pointer;", ";", ";"], p => p.$_css2, p => p.$_css3);
var _StyledAnimatedUl = _styled__default(web.extendedAnimated.ul).withConfig({
  displayName: "AutoComplete___StyledAnimatedUl",
  componentId: "sc-d82x2h-3"
})(["position:absolute;z-index:2;top:100%;width:100%;padding:8px 0;color:", ";background:", ";border:1px solid ", ";box-shadow:0 4px 4px 0 rgba(0,0,0,0.06);border-radius:3px;padding:0;margin:0;list-style:none;& > li:first-child{border-top-left-radius:3px;border-top-right-radius:3px;}& > li:last-child{border-bottom-left-radius:3px;border-bottom-right-radius:3px;}"], p => p.$_css4, p => p.$_css5, p => p.$_css6);

exports.default = AutoComplete$1;
//# sourceMappingURL=AutoComplete.js.map
