'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

function _interopDefault (ex) { return (ex && (typeof ex === 'object') && 'default' in ex) ? ex['default'] : ex; }

var React = require('react');
var React__default = _interopDefault(React);
require('./_commonjsHelpers-72d386ba.js');
var index = require('./index-c8446775.js');
var _styled = require('styled-components');
var _styled__default = _interopDefault(_styled);
require('./color.js');
require('./components.js');
require('./contains-component.js');
require('./css.js');
require('./dayjs.min-966150e3.js');
require('./date.js');
require('./miscellaneous.js');
require('./environment.js');
require('./font.js');
require('./math-4eaf20a0.js');
require('./characters.js');
require('./format.js');
require('./keycodes.js');
require('./url.js');
require('./web3.js');
var constants = require('./constants.js');
require('./breakpoints.js');
require('./springs.js');
var textStyles = require('./text-styles.js');
require('./theme-dark.js');
require('./theme-light.js');
var Theme = require('./Theme.js');
var _extends$1 = require('./extends-43472f94.js');
var index$1 = require('./index-766bccf9.js');
require('./defineProperty-7b1b81d8.js');
require('./isObject-b8c5dfc0.js');
require('./Viewport-0f56d694.js');
var Layout = require('./Layout.js');

function Header(_ref) {
  let {
    primary,
    secondary,
    children,
    ...props
  } = _ref;
  const theme = Theme.useTheme();
  const {
    layoutName
  } = Layout.useLayout();
  const fullWidth = layoutName === 'small';
  return /*#__PURE__*/React__default.createElement(index$1.i, {
    name: "Header"
  }, /*#__PURE__*/React__default.createElement(_StyledDiv, _extends$1._extends({}, props, {
    $_css: fullWidth ? 0 : 3 * constants.GU,
    $_css2: fullWidth ? theme.surface : 'none',
    $_css3: fullWidth ? 2 * constants.GU : 0,
    $_css4: fullWidth ? '0px 2px 3px rgba(0, 0, 0, 0.05)' : 'none'
  }), /*#__PURE__*/React__default.createElement(_StyledDiv2, {
    $_css5: fullWidth ? 8 * constants.GU : 5 * constants.GU,
    $_css6: fullWidth && !children ? 2 * constants.GU : 0
  }, children || /*#__PURE__*/React__default.createElement(React__default.Fragment, null, /*#__PURE__*/React__default.createElement(index$1.i, {
    name: "Header:primary"
  }, /*#__PURE__*/React__default.createElement(_StyledDiv3, {
    $_css7: secondary ? 2 * constants.GU : 0
  }, typeof primary === 'string' && primary ? /*#__PURE__*/React__default.createElement(Header.Title, null, primary) : primary)), /*#__PURE__*/React__default.createElement(index$1.i, {
    name: "Header:secondary"
  }, /*#__PURE__*/React__default.createElement(_StyledDiv4, null, secondary))))));
}
Header.propTypes = {
  primary: index.PropTypes.node,
  secondary: index.PropTypes.node,
  children: index.PropTypes.node
};
Header.Title = function HeaderTitle(_ref2) {
  let {
    children,
    ...props
  } = _ref2;
  const theme = Theme.useTheme();
  const {
    layoutName
  } = Layout.useLayout();
  const fullWidth = layoutName === 'small';
  return /*#__PURE__*/React__default.createElement(_StyledH, _extends$1._extends({}, props, {
    $_css8: theme.content,
    $_css9: textStyles.textStyle(fullWidth ? 'title3' : 'title2')
  }), children);
};
Header.Title.propTypes = {
  children: index.PropTypes.node
};
var _StyledDiv = _styled__default("div").withConfig({
  displayName: "Header___StyledDiv",
  componentId: "sc-jk4ne9-0"
})(["padding:", "px 0;background:", ";margin-bottom:", "px;box-shadow:", ";"], p => p.$_css, p => p.$_css2, p => p.$_css3, p => p.$_css4);
var _StyledDiv2 = _styled__default("div").withConfig({
  displayName: "Header___StyledDiv2",
  componentId: "sc-jk4ne9-1"
})(["display:flex;align-items:center;justify-content:space-between;height:", "px;padding:0 ", "px;"], p => p.$_css5, p => p.$_css6);
var _StyledDiv3 = _styled__default("div").withConfig({
  displayName: "Header___StyledDiv3",
  componentId: "sc-jk4ne9-2"
})(["display:flex;min-width:0;flex-shrink:1;flex-grow:1;margin-right:", "px;"], p => p.$_css7);
var _StyledDiv4 = _styled__default("div").withConfig({
  displayName: "Header___StyledDiv4",
  componentId: "sc-jk4ne9-3"
})(["flex-shrink:0;"]);
var _StyledH = _styled__default("h1").withConfig({
  displayName: "Header___StyledH",
  componentId: "sc-jk4ne9-4"
})(["color:", ";overflow:hidden;text-overflow:ellipsis;white-space:nowrap;", ";"], p => p.$_css8, p => p.$_css9);

exports.default = Header;
//# sourceMappingURL=Header.js.map
