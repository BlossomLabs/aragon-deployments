'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

function _interopDefault (ex) { return (ex && (typeof ex === 'object') && 'default' in ex) ? ex['default'] : ex; }

var React = require('react');
var React__default = _interopDefault(React);
require('./_commonjsHelpers-72d386ba.js');
var index = require('./index-c8446775.js');
var _styled = require('styled-components');
var _styled__default = _interopDefault(_styled);
require('./color.js');
require('./components.js');
require('./contains-component.js');
require('./css.js');
require('./dayjs.min-966150e3.js');
require('./date.js');
require('./miscellaneous.js');
require('./environment.js');
require('./font.js');
require('./math-4eaf20a0.js');
require('./characters.js');
require('./format.js');
require('./keycodes.js');
require('./url.js');
require('./web3.js');
var constants = require('./constants.js');
require('./breakpoints.js');
require('./springs.js');
require('./text-styles.js');
require('./extends-43472f94.js');
var index$1 = require('./index-766bccf9.js');
require('./defineProperty-7b1b81d8.js');
require('./isObject-b8c5dfc0.js');
require('./Viewport-0f56d694.js');
var Layout = require('./Layout.js');

function Split(_ref) {
  let {
    primary,
    secondary,
    invert
  } = _ref;
  const {
    name: layout
  } = Layout.useLayout();
  const oneColumn = layout === 'small' || layout === 'medium';
  const inverted = !oneColumn && invert === 'horizontal' || oneColumn && invert === 'vertical';
  const primaryContent = /*#__PURE__*/React__default.createElement(index$1.i, {
    name: "Split:primary"
  }, /*#__PURE__*/React__default.createElement(_StyledDiv, {
    $_css: !oneColumn && inverted ? 2 * constants.GU : 0,
    $_css2: oneColumn && inverted ? 2 * constants.GU : 0
  }, primary));
  const secondaryContent = /*#__PURE__*/React__default.createElement(index$1.i, {
    name: "Split:secondary"
  }, /*#__PURE__*/React__default.createElement(_StyledDiv2, {
    $_css3: oneColumn ? '100%' : `${33 * constants.GU}px`,
    $_css4: !oneColumn && !inverted ? 2 * constants.GU : 0,
    $_css5: oneColumn && !inverted ? 2 * constants.GU : 0
  }, secondary));
  return /*#__PURE__*/React__default.createElement(index$1.i, {
    name: "Split"
  }, /*#__PURE__*/React__default.createElement(_StyledDiv3, {
    $_css6: oneColumn ? 'block' : 'flex',
    $_css7: 3 * constants.GU
  }, inverted ? secondaryContent : primaryContent, inverted ? primaryContent : secondaryContent));
}
Split.propTypes = {
  invert: index.PropTypes.oneOf(['none', 'horizontal', 'vertical']),
  primary: index.PropTypes.node,
  secondary: index.PropTypes.node
};
Split.defaultProps = {
  invert: 'none'
};
var _StyledDiv = _styled__default("div").withConfig({
  displayName: "Split___StyledDiv",
  componentId: "sc-m7g5ba-0"
})(["flex-grow:1;margin-left:", "px;padding-top:", "px;"], p => p.$_css, p => p.$_css2);
var _StyledDiv2 = _styled__default("div").withConfig({
  displayName: "Split___StyledDiv2",
  componentId: "sc-m7g5ba-1"
})(["flex-shrink:0;flex-grow:0;width:", ";margin-left:", "px;padding-top:", "px;"], p => p.$_css3, p => p.$_css4, p => p.$_css5);
var _StyledDiv3 = _styled__default("div").withConfig({
  displayName: "Split___StyledDiv3",
  componentId: "sc-m7g5ba-2"
})(["display:", ";padding-bottom:", "px;width:100%;"], p => p.$_css6, p => p.$_css7);

exports.Split = Split;
exports.default = Split;
//# sourceMappingURL=Split.js.map
