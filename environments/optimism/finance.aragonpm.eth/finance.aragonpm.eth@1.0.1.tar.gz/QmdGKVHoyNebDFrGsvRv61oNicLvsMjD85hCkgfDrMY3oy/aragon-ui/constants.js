'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

const GU = 8;
const RADIUS = 4;

exports.GU = GU;
exports.RADIUS = RADIUS;
//# sourceMappingURL=constants.js.map
