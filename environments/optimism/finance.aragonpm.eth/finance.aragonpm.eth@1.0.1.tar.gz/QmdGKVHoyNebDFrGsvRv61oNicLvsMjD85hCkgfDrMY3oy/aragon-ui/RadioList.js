'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

function _interopDefault (ex) { return (ex && (typeof ex === 'object') && 'default' in ex) ? ex['default'] : ex; }

var React = require('react');
var React__default = _interopDefault(React);
require('./_commonjsHelpers-72d386ba.js');
var index = require('./index-c8446775.js');
var _styled = require('styled-components');
var _styled__default = _interopDefault(_styled);
require('./color.js');
require('./components.js');
require('./contains-component.js');
require('./css.js');
require('./dayjs.min-966150e3.js');
require('./date.js');
var miscellaneous = require('./miscellaneous.js');
require('./environment.js');
require('./font.js');
require('./math-4eaf20a0.js');
require('./characters.js');
require('./format.js');
require('./keycodes.js');
require('./url.js');
require('./web3.js');
var constants = require('./constants.js');
require('./breakpoints.js');
require('./springs.js');
require('./text-styles.js');
require('./theme-dark.js');
require('./theme-light.js');
require('./Theme.js');
require('./extends-43472f94.js');
require('./defineProperty-7b1b81d8.js');
require('./FocusVisible.js');
require('./objectWithoutPropertiesLoose-d28f0f6e.js');
require('react-dom');
require('./web-449fa78f.js');
require('./Checkbox.js');
var RadioGroup = require('./RadioGroup.js');
require('./Radio.js');
var RadioListItem = require('./RadioListItem.js');

function RadioList(_ref) {
  let {
    description,
    items,
    onChange,
    selected,
    title,
    ...props
  } = _ref;
  return /*#__PURE__*/React__default.createElement("div", props, title && /*#__PURE__*/React__default.createElement(_StyledH, {
    $_css: 0.5 * constants.GU
  }, title), description && /*#__PURE__*/React__default.createElement(_StyledDiv, {
    $_css2: 2.5 * constants.GU
  }, description), /*#__PURE__*/React__default.createElement(_StyledRadioGroup, {
    onChange: onChange,
    selected: selected
  }, items.map((_ref2, i) => {
    let {
      description,
      title
    } = _ref2;
    return /*#__PURE__*/React__default.createElement(RadioListItem.default, {
      key: i,
      description: description,
      index: i,
      title: title
    });
  })));
}
RadioList.propTypes = {
  description: index.PropTypes.node,
  items: index.PropTypes.arrayOf(index.PropTypes.shape({
    description: index.PropTypes.node.isRequired,
    title: index.PropTypes.node.isRequired
  })),
  onChange: index.PropTypes.func,
  selected: (_ref3, _, componentName) => {
    let {
      items,
      selected
    } = _ref3;
    if (!Number.isInteger(selected) || selected >= items.length) {
      throw new Error(`Invalid prop \`selected\` supplied to \`${componentName}\`. ` + '`selected` must be an integer less than the length of `items`. ' + `Given ${selected} instead.`);
    }
  },
  title: index.PropTypes.node
};
RadioList.defaultProps = {
  items: [],
  onChange: miscellaneous.noop,
  selected: 0
};
var _StyledH = _styled__default("h2").withConfig({
  displayName: "RadioList___StyledH",
  componentId: "sc-1nc1fxn-0"
})(["margin-bottom:", "px;font-weight:600;"], p => p.$_css);
var _StyledDiv = _styled__default("div").withConfig({
  displayName: "RadioList___StyledDiv",
  componentId: "sc-1nc1fxn-1"
})(["margin-bottom:", "px;"], p => p.$_css2);
var _StyledRadioGroup = _styled__default(RadioGroup.default).withConfig({
  displayName: "RadioList___StyledRadioGroup",
  componentId: "sc-1nc1fxn-2"
})(["display:flex;flex-direction:column;"]);

exports.default = RadioList;
//# sourceMappingURL=RadioList.js.map
