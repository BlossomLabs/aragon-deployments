'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

function _interopDefault (ex) { return (ex && (typeof ex === 'object') && 'default' in ex) ? ex['default'] : ex; }

var React = require('react');
var React__default = _interopDefault(React);
require('./_commonjsHelpers-72d386ba.js');
require('./index-c8446775.js');
var _styled = require('styled-components');
var _styled__default = _interopDefault(_styled);
require('./color.js');
require('./components.js');
require('./contains-component.js');
var css = require('./css.js');
require('./dayjs.min-966150e3.js');
require('./date.js');
require('./miscellaneous.js');
require('./environment.js');
require('./font.js');
require('./math-4eaf20a0.js');
require('./characters.js');
require('./format.js');
require('./keycodes.js');
require('./url.js');
require('./web3.js');
require('./constants.js');
require('./breakpoints.js');
require('./springs.js');
var textStyles = require('./text-styles.js');
require('./theme-dark.js');
require('./theme-light.js');
var Theme = require('./Theme.js');
var _extends$1 = require('./extends-43472f94.js');
require('./defineProperty-7b1b81d8.js');
require('./FocusVisible.js');
var ButtonBase = require('./ButtonBase.js');

const ContextMenuItem = /*#__PURE__*/React__default.memo(function ContextMenuItem(props) {
  const theme = Theme.useTheme();
  return /*#__PURE__*/React__default.createElement(_StyledButtonBase, _extends$1._extends({}, props, {
    $_css: textStyles.textStyle('body2'),
    $_css2: css.unselectable(),
    $_css3: theme.surfacePressed
  }));
});
var _StyledButtonBase = _styled__default(ButtonBase.default).withConfig({
  displayName: "ContextMenuItem___StyledButtonBase",
  componentId: "sc-1a3l0qy-0"
})(["display:flex;align-items:center;padding:5px 16px 5px 10px;cursor:pointer;white-space:nowrap;width:100%;", " ", ";&:active{background:", ";}"], p => p.$_css, p => p.$_css2, p => p.$_css3);

exports.default = ContextMenuItem;
//# sourceMappingURL=ContextMenuItem.js.map
