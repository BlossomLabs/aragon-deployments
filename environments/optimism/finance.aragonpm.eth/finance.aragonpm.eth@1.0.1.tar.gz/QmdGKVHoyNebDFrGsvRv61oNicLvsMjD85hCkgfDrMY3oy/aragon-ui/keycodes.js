'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

const KEY_ESC = 27;
const KEY_UP = 38;
const KEY_DOWN = 40;
const KEY_ENTER = 13;

exports.KEY_DOWN = KEY_DOWN;
exports.KEY_ENTER = KEY_ENTER;
exports.KEY_ESC = KEY_ESC;
exports.KEY_UP = KEY_UP;
//# sourceMappingURL=keycodes.js.map
