'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

function _interopDefault (ex) { return (ex && (typeof ex === 'object') && 'default' in ex) ? ex['default'] : ex; }

var React = require('react');
var React__default = _interopDefault(React);
require('./_commonjsHelpers-72d386ba.js');
var index = require('./index-c8446775.js');
var _styled = require('styled-components');
var _styled__default = _interopDefault(_styled);
require('./color.js');
require('./components.js');
require('./contains-component.js');
require('./css.js');
require('./dayjs.min-966150e3.js');
require('./date.js');
require('./miscellaneous.js');
require('./environment.js');
require('./font.js');
require('./math-4eaf20a0.js');
require('./characters.js');
require('./format.js');
require('./keycodes.js');
require('./url.js');
require('./web3.js');
require('./constants.js');
require('./breakpoints.js');
require('./springs.js');
require('./text-styles.js');
require('./theme-dark.js');
require('./theme-light.js');
var Theme = require('./Theme.js');
var _extends$1 = require('./extends-43472f94.js');
require('./index-766bccf9.js');
require('./defineProperty-7b1b81d8.js');
require('./isObject-b8c5dfc0.js');
require('./Viewport-0f56d694.js');
require('./Layout.js');
require('./FocusVisible.js');
require('./ButtonBase.js');
require('./IconPropTypes-68080ae8.js');
require('./IconAddUser.js');
require('./IconAlert.js');
require('./IconAlignCenter.js');
require('./IconAlignJustify.js');
require('./IconAlignLeft.js');
require('./IconAlignRight.js');
require('./IconAragon.js');
require('./IconArrowDown.js');
require('./IconArrowLeft.js');
require('./IconArrowRight.js');
require('./IconArrowUp.js');
require('./IconAtSign.js');
require('./IconBlock.js');
require('./IconBookmark.js');
require('./IconCalendar.js');
require('./IconCanvas.js');
require('./IconCaution.js');
require('./IconCenter.js');
require('./IconChart.js');
require('./IconChat.js');
require('./IconCheck.js');
require('./IconChip.js');
require('./IconCircleCheck.js');
require('./IconCircleMinus.js');
require('./IconCirclePlus.js');
require('./IconClock.js');
require('./IconCloudDownload.js');
require('./IconCloudUpload.js');
require('./IconCoin.js');
require('./IconConfiguration.js');
require('./IconConnect.js');
require('./IconConnection.js');
require('./IconConsole.js');
require('./IconCopy.js');
require('./IconCross.js');
require('./IconDashedSquare.js');
require('./IconDown.js');
require('./IconDownload.js');
require('./IconEdit.js');
require('./IconEllipsis.js');
require('./IconEnter.js');
require('./IconEthereum.js');
require('./IconExternal.js');
require('./IconFile.js');
require('./IconFilter.js');
require('./IconFlag.js');
require('./IconFolder.js');
require('./IconGraph2.js');
require('./IconGraph.js');
require('./IconGrid.js');
require('./IconGroup.js');
require('./IconHash.js');
require('./IconHeart.js');
require('./IconHide.js');
require('./IconHome.js');
require('./IconImage.js');
require('./IconInfo.js');
require('./IconLabel.js');
require('./IconLayers.js');
require('./IconLeft.js');
require('./IconLink.js');
require('./IconLocation.js');
require('./IconLock.js');
require('./IconMail.js');
require('./IconMaximize.js');
require('./IconMenu.js');
require('./IconMinimize.js');
require('./IconMinus.js');
require('./IconMove.js');
require('./IconNoPicture.js');
require('./IconPicture.js');
require('./IconPlus.js');
require('./IconPower.js');
require('./IconPrint.js');
require('./IconProhibited.js');
require('./IconQuestion.js');
require('./IconRefresh.js');
require('./IconRemoveUser.js');
require('./IconRight.js');
require('./IconRotateLeft.js');
require('./IconRotateRight.js');
require('./IconSearch.js');
require('./IconSettings.js');
require('./IconShare.js');
require('./IconSquareMinus.js');
require('./IconSquarePlus.js');
require('./IconSquare.js');
require('./IconStarFilled.js');
require('./IconStar.js');
require('./IconSwap.js');
require('./IconTarget.js');
require('./IconToken.js');
require('./IconTrash.js');
require('./IconUnlock.js');
require('./IconUp.js');
require('./IconUpload.js');
require('./IconUser.js');
require('./IconView.js');
require('./IconVote.js');
require('./IconWallet.js');
require('./IconWarning.js');
require('./IconWorld.js');
require('./IconWrite.js');
require('./IconZoomIn.js');
require('./IconZoomOut.js');
require('./objectWithoutPropertiesLoose-d28f0f6e.js');
require('react-dom');
require('./web-449fa78f.js');
require('./Button.js');
require('./ButtonIcon.js');
require('./index-d200e416.js');
require('./RootPortal.js');
var SidePanel = require('./SidePanel.js');

function SidePanelSplit(_ref) {
  let {
    children,
    ...props
  } = _ref;
  const theme = Theme.useTheme();
  return /*#__PURE__*/React__default.createElement(_StyledDiv, _extends$1._extends({}, props, {
    $_css: SidePanel.default.HORIZONTAL_PADDING * 2,
    $_css2: SidePanel.default.HORIZONTAL_PADDING,
    $_css3: SidePanel.default.HORIZONTAL_PADDING
  }), /*#__PURE__*/React__default.createElement(Part, null, children[0]), /*#__PURE__*/React__default.createElement(_StyledDiv2, {
    $_css4: theme.border,
    $_css5: SidePanel.default.HORIZONTAL_PADDING,
    $_css6: SidePanel.default.HORIZONTAL_PADDING
  }), /*#__PURE__*/React__default.createElement(Part, null, children[1]));
}
SidePanelSplit.propTypes = {
  children: index.PropTypes.node
};
const Part = _styled__default.div.withConfig({
  displayName: "SidePanelSplit__Part",
  componentId: "sc-1bcrk8c-0"
})(["width:50%;"]);
var _StyledDiv = _styled__default("div").withConfig({
  displayName: "SidePanelSplit___StyledDiv",
  componentId: "sc-1bcrk8c-1"
})(["display:flex;width:calc(100% + ", "px);margin:0 -", "px;padding:", "px;"], p => p.$_css, p => p.$_css2, p => p.$_css3);
var _StyledDiv2 = _styled__default("div").withConfig({
  displayName: "SidePanelSplit___StyledDiv2",
  componentId: "sc-1bcrk8c-2"
})(["display:inline-block;border-right:1px solid ", ";margin:-", "px ", "px;"], p => p.$_css4, p => p.$_css5, p => p.$_css6);

exports.default = SidePanelSplit;
//# sourceMappingURL=SidePanelSplit.js.map
