'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

function _interopDefault (ex) { return (ex && (typeof ex === 'object') && 'default' in ex) ? ex['default'] : ex; }

var React = require('react');
var React__default = _interopDefault(React);
require('./_commonjsHelpers-72d386ba.js');
var index = require('./index-c8446775.js');
require('./extends-43472f94.js');
var ReactDOM = _interopDefault(require('react-dom'));
var index$1 = require('./index-d200e416.js');

const RootPortal = props => /*#__PURE__*/React__default.createElement(index$1.Root, null, rootElement => {
  if (!rootElement) {
    throw new Error('<RootPortal> needs to be nested in <Root.Provider>. Have you declared <Main>?');
  }
  return /*#__PURE__*/ReactDOM.createPortal(props.children, rootElement);
});
RootPortal.propTypes = {
  children: index.PropTypes.node.isRequired
};

exports.default = RootPortal;
//# sourceMappingURL=RootPortal.js.map
