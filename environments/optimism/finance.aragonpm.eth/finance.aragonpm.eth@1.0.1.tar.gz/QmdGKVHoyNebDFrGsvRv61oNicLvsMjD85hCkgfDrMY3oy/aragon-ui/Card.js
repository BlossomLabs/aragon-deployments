'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

function _interopDefault (ex) { return (ex && (typeof ex === 'object') && 'default' in ex) ? ex['default'] : ex; }

var React = require('react');
var React__default = _interopDefault(React);
require('./_commonjsHelpers-72d386ba.js');
var index = require('./index-c8446775.js');
var _styled = require('styled-components');
var _styled__default = _interopDefault(_styled);
require('./color.js');
require('./components.js');
require('./contains-component.js');
require('./css.js');
require('./dayjs.min-966150e3.js');
require('./date.js');
require('./miscellaneous.js');
require('./environment.js');
require('./font.js');
require('./math-4eaf20a0.js');
require('./characters.js');
require('./format.js');
require('./keycodes.js');
require('./url.js');
require('./web3.js');
var constants = require('./constants.js');
require('./breakpoints.js');
require('./springs.js');
require('./text-styles.js');
require('./theme-dark.js');
require('./theme-light.js');
var Theme = require('./Theme.js');
var _extends$1 = require('./extends-43472f94.js');
var index$1 = require('./index-766bccf9.js');
require('./defineProperty-7b1b81d8.js');
require('./FocusVisible.js');
var ButtonBase = require('./ButtonBase.js');

const DEFAULT_WIDTH = 35 * constants.GU;
const DEFAULT_HEIGHT = 40 * constants.GU;
function dimension(insideCardLayout, value, defaultValue) {
  if (insideCardLayout) {
    return '100%';
  }
  if (typeof value === 'number') {
    value = `${value}px`;
  }
  return value === undefined ? defaultValue : value;
}
function Card(_ref) {
  let {
    children,
    width,
    height,
    onClick,
    ...props
  } = _ref;
  const theme = Theme.useTheme();
  const [insideCardLayout] = index$1.o('CardLayout');
  const interactive = Boolean(onClick);
  const interactiveProps = interactive ? {
    as: ButtonBase.default,
    element: 'div',
    focusRingRadius: constants.RADIUS,
    onClick
  } : {};
  const cssWidth = dimension(insideCardLayout, width, `${DEFAULT_WIDTH}px`);
  const cssHeight = dimension(insideCardLayout, height, `${DEFAULT_HEIGHT}px`);
  return /*#__PURE__*/React__default.createElement(_StyledDiv, _extends$1._extends({}, interactiveProps, props, {
    $_css: cssWidth,
    $_css2: cssHeight,
    $_css3: theme.surface,
    $_css4: theme.border,
    $_css5: interactive ? 'pointer' : 'default',
    $_css6: interactive && _styled.css(["border:0;box-shadow:0px 1px 3px rgba(0,0,0,0.15);transition-property:transform,box-shadow;transition-duration:50ms;transition-timing-function:ease-in-out;text-align:left;white-space:normal;&:active{transform:translateY(1px);box-shadow:0px 1px 3px rgba(0,0,0,0.08);}"])
  }), children);
}
Card.propTypes = {
  children: index.PropTypes.node,
  height: index.PropTypes.oneOfType([index.PropTypes.string, index.PropTypes.number]),
  width: index.PropTypes.oneOfType([index.PropTypes.string, index.PropTypes.number]),
  onClick: index.PropTypes.func
};
var _StyledDiv = _styled__default("div").withConfig({
  displayName: "Card___StyledDiv",
  componentId: "sc-1s8uv3c-0"
})(["position:relative;width:", ";height:", ";background:", ";border:1px solid ", ";border-radius:", "px;cursor:", ";display:flex;flex-direction:column;align-items:center;justify-content:center;", ""], p => p.$_css, p => p.$_css2, p => p.$_css3, p => p.$_css4, constants.RADIUS, p => p.$_css5, p => p.$_css6);

exports.default = Card;
//# sourceMappingURL=Card.js.map
