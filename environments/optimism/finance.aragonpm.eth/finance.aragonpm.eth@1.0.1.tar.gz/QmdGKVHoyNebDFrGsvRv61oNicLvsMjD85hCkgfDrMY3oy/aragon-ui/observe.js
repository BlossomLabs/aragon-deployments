'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

function _interopDefault (ex) { return (ex && (typeof ex === 'object') && 'default' in ex) ? ex['default'] : ex; }

var React = require('react');
var React__default = _interopDefault(React);
require('./_commonjsHelpers-72d386ba.js');
require('./color.js');
require('./components.js');
require('./contains-component.js');
require('./css.js');
require('./dayjs.min-966150e3.js');
require('./date.js');
require('./miscellaneous.js');
var environment = require('./environment.js');
require('./font.js');
require('./math-4eaf20a0.js');
require('./characters.js');
require('./format.js');
require('./keycodes.js');
require('./url.js');
require('./web3.js');
var _extends$1 = require('./extends-43472f94.js');
var defineProperty$1 = require('./defineProperty-7b1b81d8.js');
var getDisplayName = require('./getDisplayName-7ab6d318.js');

// Higher-order component for convenient subscriptions to RxJS observables
const observe = function (observe) {
  let initialState = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
  return Component => {
    var _class;
    return _class = class extends React__default.Component {
      constructor() {
        super(...arguments);
        defineProperty$1._defineProperty(this, "state", initialState);
        defineProperty$1._defineProperty(this, "subscribe", observable => {
          if (observable) {
            this.setState({
              subscription: observe(observable).subscribe(state => {
                this.setState(state);
              })
            });
          }
        });
        defineProperty$1._defineProperty(this, "unsubscribe", () => {
          this.state.subscription && this.state.subscription.unsubscribe();
        });
      }
      componentDidMount() {
        this.subscribe(this.props.observable);
      }
      componentWillReceiveProps(_ref) {
        let {
          observable: nextObservable
        } = _ref;
        const {
          observable
        } = this.props;
        // If a new observable gets passed in, unsubscribe from the old and subscribe to the new
        if (nextObservable !== observable) {
          this.unsubscribe();
          this.subscribe(nextObservable);
        }
      }
      componentWillUnmount() {
        this.unsubscribe();
      }
      render() {
        environment.warnOnce('observe()', 'observe() is deprecated. If you are using it with @aragon/api, using @aragon/api-react is now recommended instead.');
        const {
          ...props
        } = this.props;
        // Don't pass down the given observable
        delete props.observable;
        return /*#__PURE__*/React__default.createElement(Component, _extends$1._extends({}, this.state, props));
      }
    }, defineProperty$1._defineProperty(_class, "displayName", `Observe(${getDisplayName.getDisplayName(Component)})`), defineProperty$1._defineProperty(_class, "propTypes", {
      observable: (_ref2, _, componentName) => {
        let {
          observable
        } = _ref2;
        if (observable && typeof observable.subscribe !== 'function') {
          throw new Error(`Invalid prop \`observable\` supplied to \`${componentName}\` ` + '(wrapped by `observe()`). ' + '`observable` must be an RxJS Observable-like object. ' + `Given ${observable} instead.`);
        }
      }
    }), _class;
  };
};

exports.observe = observe;
//# sourceMappingURL=observe.js.map
