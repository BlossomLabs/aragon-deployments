'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

function _interopDefault (ex) { return (ex && (typeof ex === 'object') && 'default' in ex) ? ex['default'] : ex; }

var React = require('react');
var React__default = _interopDefault(React);
require('./_commonjsHelpers-72d386ba.js');
var index = require('./index-c8446775.js');
var _styled = require('styled-components');
var _styled__default = _interopDefault(_styled);
require('./color.js');
require('./components.js');
require('./contains-component.js');
require('./css.js');
require('./dayjs.min-966150e3.js');
require('./date.js');
require('./miscellaneous.js');
require('./environment.js');
require('./font.js');
require('./math-4eaf20a0.js');
require('./characters.js');
require('./format.js');
require('./keycodes.js');
require('./url.js');
require('./web3.js');
var constants = require('./constants.js');
require('./breakpoints.js');
require('./springs.js');
require('./text-styles.js');
require('./theme-dark.js');
require('./theme-light.js');
var Theme = require('./Theme.js');
var _extends = require('./extends-43472f94.js');
require('./defineProperty-7b1b81d8.js');
require('./FocusVisible.js');
var ButtonBase = require('./ButtonBase.js');

function Link(_ref) {
  let {
    onClick,
    href,
    external,
    ...props
  } = _ref;
  const theme = Theme.useTheme();

  // `external` defaults to `true` if `href` is present, `false` otherwise.
  if (external === undefined) {
    external = Boolean(href);
  }
  return /*#__PURE__*/React__default.createElement(_StyledButtonBase, _extends._extends({
    href: href,
    onClick: onClick,
    external: external,
    focusRingSpacing: [6, 2],
    focusRingRadius: constants.RADIUS
  }, props, {
    $_css: theme.link,
    $_css2: external ? 'underline' : 'none'
  }));
}
Link.propTypes = {
  ...ButtonBase.default.propTypes,
  href: index.PropTypes.string,
  onClick: index.PropTypes.func,
  external: index.PropTypes.bool
};
var _StyledButtonBase = _styled__default(ButtonBase.default).withConfig({
  displayName: "Link___StyledButtonBase",
  componentId: "sc-u50ict-0"
})(["color:", ";text-decoration:", ";font-size:inherit;"], p => p.$_css, p => p.$_css2);

exports.default = Link;
//# sourceMappingURL=Link.js.map
