'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

function _interopDefault (ex) { return (ex && (typeof ex === 'object') && 'default' in ex) ? ex['default'] : ex; }

var React = require('react');
var React__default = _interopDefault(React);
require('./_commonjsHelpers-72d386ba.js');
var index = require('./index-c8446775.js');
var _styled = require('styled-components');
var _styled__default = _interopDefault(_styled);
require('./color.js');
require('./components.js');
require('./contains-component.js');
var css = require('./css.js');
require('./dayjs.min-966150e3.js');
require('./date.js');
require('./miscellaneous.js');
var environment = require('./environment.js');
require('./font.js');
require('./math-4eaf20a0.js');
require('./characters.js');
require('./format.js');
require('./keycodes.js');
require('./url.js');
require('./web3.js');
var constants = require('./constants.js');
require('./breakpoints.js');
require('./springs.js');
var textStyles = require('./text-styles.js');
require('./theme-dark.js');
require('./theme-light.js');
var Theme = require('./Theme.js');
var _extends$1 = require('./extends-43472f94.js');
var index$1 = require('./index-766bccf9.js');
require('./defineProperty-7b1b81d8.js');
require('./isObject-b8c5dfc0.js');
var Viewport = require('./Viewport-0f56d694.js');
require('./FocusVisible.js');
var ButtonBase = require('./ButtonBase.js');
require('./IconPropTypes-68080ae8.js');
require('./IconAddUser.js');
require('./IconAlert.js');
require('./IconAlignCenter.js');
require('./IconAlignJustify.js');
require('./IconAlignLeft.js');
require('./IconAlignRight.js');
require('./IconAragon.js');
require('./IconArrowDown.js');
require('./IconArrowLeft.js');
require('./IconArrowRight.js');
require('./IconArrowUp.js');
require('./IconAtSign.js');
require('./IconBlock.js');
require('./IconBookmark.js');
require('./IconCalendar.js');
require('./IconCanvas.js');
require('./IconCaution.js');
require('./IconCenter.js');
require('./IconChart.js');
require('./IconChat.js');
require('./IconCheck.js');
require('./IconChip.js');
require('./IconCircleCheck.js');
require('./IconCircleMinus.js');
require('./IconCirclePlus.js');
require('./IconClock.js');
require('./IconCloudDownload.js');
require('./IconCloudUpload.js');
require('./IconCoin.js');
require('./IconConfiguration.js');
require('./IconConnect.js');
require('./IconConnection.js');
require('./IconConsole.js');
require('./IconCopy.js');
require('./IconCross.js');
require('./IconDashedSquare.js');
var IconDown = require('./IconDown.js');
require('./IconDownload.js');
require('./IconEdit.js');
require('./IconEllipsis.js');
require('./IconEnter.js');
require('./IconEthereum.js');
require('./IconExternal.js');
require('./IconFile.js');
require('./IconFilter.js');
require('./IconFlag.js');
require('./IconFolder.js');
require('./IconGraph2.js');
require('./IconGraph.js');
require('./IconGrid.js');
require('./IconGroup.js');
require('./IconHash.js');
require('./IconHeart.js');
require('./IconHide.js');
require('./IconHome.js');
require('./IconImage.js');
require('./IconInfo.js');
require('./IconLabel.js');
require('./IconLayers.js');
require('./IconLeft.js');
require('./IconLink.js');
require('./IconLocation.js');
require('./IconLock.js');
require('./IconMail.js');
require('./IconMaximize.js');
require('./IconMenu.js');
require('./IconMinimize.js');
require('./IconMinus.js');
require('./IconMove.js');
require('./IconNoPicture.js');
require('./IconPicture.js');
require('./IconPlus.js');
require('./IconPower.js');
require('./IconPrint.js');
require('./IconProhibited.js');
require('./IconQuestion.js');
require('./IconRefresh.js');
require('./IconRemoveUser.js');
require('./IconRight.js');
require('./IconRotateLeft.js');
require('./IconRotateRight.js');
require('./IconSearch.js');
require('./IconSettings.js');
require('./IconShare.js');
require('./IconSquareMinus.js');
require('./IconSquarePlus.js');
require('./IconSquare.js');
require('./IconStarFilled.js');
require('./IconStar.js');
require('./IconSwap.js');
require('./IconTarget.js');
require('./IconToken.js');
require('./IconTrash.js');
require('./IconUnlock.js');
require('./IconUp.js');
require('./IconUpload.js');
require('./IconUser.js');
require('./IconView.js');
require('./IconVote.js');
require('./IconWallet.js');
require('./IconWarning.js');
require('./IconWorld.js');
require('./IconWrite.js');
require('./IconZoomIn.js');
require('./IconZoomOut.js');
require('./objectWithoutPropertiesLoose-d28f0f6e.js');
require('react-dom');
require('./web-449fa78f.js');
require('./getDisplayName-7ab6d318.js');
require('./index-70be9e8d.js');
require('./index-d200e416.js');
require('./RootPortal.js');
require('./proptypes-70c08808.js');
var Popover = require('./Popover.js');
require('./observe.js');
require('./index-aa9c1462.js');
require('./providers.js');

const MIN_WIDTH = 128;
function useDropDown(_ref) {
  let {
    buttonRef,
    items,
    displayedLabel,
    onChange,
    placeholder,
    selected
  } = _ref;
  const [selectedLabel, setSelectedLabel] = React.useState(displayedLabel);
  const [opened, setOpened] = React.useState(false);
  const close = React.useCallback(() => {
    setOpened(false);
    if (buttonRef.current) {
      buttonRef.current.focus();
    }
  }, [buttonRef]);
  const toggle = React.useCallback(() => setOpened(opened => !opened), []);
  const handleItemSelect = React.useCallback(index => {
    onChange(index);
    close();
  }, [onChange, close]);
  React.useEffect(() => {
    if (selected === -1 || !items[selected]) {
      if (displayedLabel) {
        setSelectedLabel(displayedLabel);
      }
      return;
    }
    setSelectedLabel(items[selected]);
  }, [items, selected, displayedLabel]);
  return {
    handleItemSelect,
    close,
    toggle,
    opened,
    selectedLabel
  };
}
function useButtonRef(cb) {
  const buttonRef = React.useRef(null);
  const refCallback = React.useCallback(el => {
    if (el) {
      cb(el);
    }
    buttonRef.current = el;
  }, [cb]);
  return {
    buttonRef,
    refCallback
  };
}
const DropDown = /*#__PURE__*/React__default.memo(function DropDown(_ref2) {
  let {
    disabled,
    header,
    items,
    onChange,
    placeholder,
    renderLabel,
    selected,
    wide,
    width,
    // deprecated
    active,
    label,
    // rest
    ...props
  } = _ref2;
  if (active !== undefined) {
    environment.warnOnce('DropDown:active', 'The “active” prop is deprecated. Please use “selected” to pass the selected index instead.');
  }
  if (label !== undefined) {
    environment.warnOnce('DropDown:label', 'DropDown: the “label” prop is deprecated, please use “placeholder” instead.');
  }
  const theme = Theme.useTheme();
  const {
    width: vw
  } = Viewport.useViewport();
  const [widthNoPx = MIN_WIDTH] = (width || '').split('px');
  const [buttonWidth, setButtonWidth] = React.useState(0);
  const [measureWidth, setMeasureWidth] = React.useState(true);

  // Adjust the button width if the item widths are larger than declared width
  const [placeholderMinWidth, setPlaceholderMinWidth] = React.useState(Math.min(widthNoPx, MIN_WIDTH));
  const popoverRefCallback = React.useCallback(el => {
    if (!el) {
      return;
    }
    setPlaceholderMinWidth(el.clientWidth);
    setMeasureWidth(false);
  }, []);
  React.useEffect(() => {
    setMeasureWidth(true);
  }, [vw, items]);

  // Update the button width every time the reference updates
  const {
    refCallback,
    buttonRef
  } = useButtonRef(el => {
    setButtonWidth(el.clientWidth);
  });
  // And every time the viewport resizes
  React.useEffect(() => {
    if (!buttonRef.current) {
      return;
    }
    setButtonWidth(buttonRef.current.clientWidth);
  }, [buttonRef, vw]);
  const selectedIndex = React.useMemo(() => {
    if (selected !== undefined) {
      return selected;
    }
    if (active !== undefined) {
      return active;
    }
    return -1;
  }, [active, selected]);
  const {
    handleItemSelect,
    close,
    toggle,
    opened,
    selectedLabel
  } = useDropDown({
    buttonRef,
    displayedLabel: placeholder || label,
    items,
    onChange,
    selected
  });
  const closedWithChanges = !opened && selectedIndex !== -1;
  const Label = renderLabel;
  return /*#__PURE__*/React__default.createElement(index$1.i, {
    name: "DropDown"
  }, /*#__PURE__*/React__default.createElement(_StyledButtonBase, _extends$1._extends({
    ref: refCallback,
    disabled: disabled,
    onClick: toggle,
    focusRingRadius: constants.RADIUS,
    focusRingSpacing: 1
  }, props, {
    $_css: wide ? 'flex' : 'inline-flex',
    $_css2: 5 * constants.GU,
    $_css3: 2 * constants.GU,
    $_css4: 1.5 * constants.GU,
    $_css5: width || (wide ? '100%' : 'auto'),
    $_css6: wide ? 'auto' : `${placeholderMinWidth}px`,
    $_css7: disabled ? theme.disabled : theme.surface,
    $_css8: disabled ? theme.disabledContent : theme.surfaceContent,
    $_css9: disabled ? 0 : 1,
    $_css10: closedWithChanges ? theme.selected : theme.border,
    $_css11: textStyles.textStyle('body2'),
    $_css12: disabled ? 'font-weight: 600;' : `
              &:active {
                background: ${theme.surfacePressed};
              }
            `
  }), /*#__PURE__*/React__default.createElement(_StyledDiv, null, /*#__PURE__*/React__default.createElement(Label, {
    selectedIndex: selectedIndex,
    selectedLabel: selectedLabel
  })), /*#__PURE__*/React__default.createElement(_StyledIconDown, {
    size: "tiny",
    $_css13: 1.5 * constants.GU,
    $_css14: disabled ? theme.disabledIcon : closedWithChanges ? theme.accent : theme.surfaceIcon
  })), measureWidth && /*#__PURE__*/React__default.createElement(_StyledDiv2, null, /*#__PURE__*/React__default.createElement(PopoverContent, {
    refCallback: popoverRefCallback,
    buttonWidth: buttonWidth,
    header: header,
    items: items
  })), /*#__PURE__*/React__default.createElement(Popover.default, {
    onClose: close,
    opener: buttonRef.current,
    visible: opened
  }, /*#__PURE__*/React__default.createElement(PopoverContent, {
    buttonWidth: buttonWidth,
    header: header,
    items: items,
    handleItemSelect: handleItemSelect,
    selectedIndex: selectedIndex
  })));
});
DropDown.propTypes = {
  disabled: index.PropTypes.bool,
  header: index.PropTypes.node,
  items: index.PropTypes.arrayOf(index.PropTypes.node).isRequired,
  onChange: index.PropTypes.func.isRequired,
  placeholder: index.PropTypes.node,
  renderLabel: index.PropTypes.func,
  selected: index.PropTypes.number,
  wide: index.PropTypes.bool,
  width: index.PropTypes.string,
  // deprecated
  active: index.PropTypes.number,
  label: index.PropTypes.string
};
DropDown.defaultProps = {
  placeholder: 'Select an item',
  renderLabel: _ref3 => {
    let {
      selectedLabel
    } = _ref3;
    return selectedLabel;
  },
  wide: false
};
const PopoverContent = /*#__PURE__*/React__default.memo(function PopoverContent(_ref4) {
  let {
    refCallback,
    buttonWidth,
    header,
    items,
    handleItemSelect,
    selectedIndex
  } = _ref4;
  const theme = Theme.useTheme();
  return /*#__PURE__*/React__default.createElement(_StyledDiv3, {
    $_css15: buttonWidth,
    $_css16: theme.surfaceContentSecondary
  }, header && /*#__PURE__*/React__default.createElement(_StyledDiv4, {
    $_css17: 1.5 * constants.GU,
    $_css18: 2 * constants.GU,
    $_css19: 1.25 * constants.GU,
    $_css20: textStyles.textStyle('label2')
  }, header), /*#__PURE__*/React__default.createElement(_StyledUl, {
    ref: refCallback
  }, /*#__PURE__*/React__default.createElement(index$1.i, {
    name: "DropDown:menu"
  }, items.map((item, index) => {
    return /*#__PURE__*/React__default.createElement(Item, {
      key: index,
      index: index,
      onSelect: handleItemSelect,
      theme: theme,
      item: item,
      header: header,
      length: items.length,
      selected: selectedIndex
    });
  }))));
});
PopoverContent.propTypes = {
  refCallback: index.PropTypes.func.isRequired,
  buttonWidth: index.PropTypes.number.isRequired,
  header: index.PropTypes.node,
  items: index.PropTypes.array.isRequired,
  handleItemSelect: index.PropTypes.func.isRequired,
  selectedIndex: index.PropTypes.number.isRequired
};
PopoverContent.defaultProps = {
  refCallback: () => null,
  handleItemSelect: () => null,
  selectedIndex: -1
};
const Item = /*#__PURE__*/React__default.memo(function Item(_ref5) {
  let {
    header,
    index,
    item,
    length,
    onSelect,
    selected,
    theme
  } = _ref5;
  const handleClick = React.useCallback(() => {
    onSelect(index);
  }, [index, onSelect]);
  return /*#__PURE__*/React__default.createElement("li", null, /*#__PURE__*/React__default.createElement(_StyledButtonBase2, {
    onClick: handleClick,
    $_css21: 1.25 * constants.GU,
    $_css22: 2 * constants.GU,
    $_css23: theme.content,
    $_css24: textStyles.textStyle('body2'),
    $_css25: !header && index === 0 ? `border-top-left-radius: ${constants.RADIUS}px;` : '',
    $_css26: index === length - 1 ? `border-bottom-left-radius: ${constants.RADIUS}px;` : '',
    $_css27: selected === index ? `
              border-left: 2px solid ${theme.accent};
              background: ${theme.surfaceSelected};
            ` : '',
    $_css28: theme.surfacePressed
  }, item));
});
Item.propTypes = {
  header: index.PropTypes.node,
  index: index.PropTypes.number.isRequired,
  item: index.PropTypes.node.isRequired,
  length: index.PropTypes.number.isRequired,
  onSelect: index.PropTypes.func.isRequired,
  selected: index.PropTypes.number.isRequired,
  theme: index.PropTypes.object.isRequired
};
var _StyledButtonBase = _styled__default(ButtonBase.default).withConfig({
  displayName: "DropDown___StyledButtonBase",
  componentId: "sc-13oymfr-0"
})(["display:", ";justify-content:space-between;align-items:center;height:", "px;padding-left:", "px;padding-right:", "px;width:", ";min-width:", ";background:", ";color:", ";border:", "px solid ", ";", ";", ""], p => p.$_css, p => p.$_css2, p => p.$_css3, p => p.$_css4, p => p.$_css5, p => p.$_css6, p => p.$_css7, p => p.$_css8, p => p.$_css9, p => p.$_css10, p => p.$_css11, p => p.$_css12);
var _StyledDiv = _styled__default("div").withConfig({
  displayName: "DropDown___StyledDiv",
  componentId: "sc-13oymfr-1"
})(["overflow:hidden;"]);
var _StyledIconDown = _styled__default(IconDown.default).withConfig({
  displayName: "DropDown___StyledIconDown",
  componentId: "sc-13oymfr-2"
})(["margin-left:", "px;color:", ";"], p => p.$_css13, p => p.$_css14);
var _StyledDiv2 = _styled__default("div").withConfig({
  displayName: "DropDown___StyledDiv2",
  componentId: "sc-13oymfr-3"
})(["position:absolute;top:-100vh;left:-100vw;opacity:0;visibility:hidden;"]);
var _StyledDiv3 = _styled__default("div").withConfig({
  displayName: "DropDown___StyledDiv3",
  componentId: "sc-13oymfr-4"
})(["min-width:", "px;color:", ";"], p => p.$_css15, p => p.$_css16);
var _StyledDiv4 = _styled__default("div").withConfig({
  displayName: "DropDown___StyledDiv4",
  componentId: "sc-13oymfr-5"
})(["padding:", "px ", "px ", "px;", ";", ";"], p => p.$_css17, p => p.$_css18, p => p.$_css19, p => p.$_css20, css.unselectable);
var _StyledUl = _styled__default("ul").withConfig({
  displayName: "DropDown___StyledUl",
  componentId: "sc-13oymfr-6"
})(["margin:0;padding:0;list-style:none;width:100%;"]);
var _StyledButtonBase2 = _styled__default(ButtonBase.default).withConfig({
  displayName: "DropDown___StyledButtonBase2",
  componentId: "sc-13oymfr-7"
})(["width:100%;text-align:left;padding:", "px ", "px;border-radius:0;color:", ";", ";", " ", " ", " &:active{background:", ";}"], p => p.$_css21, p => p.$_css22, p => p.$_css23, p => p.$_css24, p => p.$_css25, p => p.$_css26, p => p.$_css27, p => p.$_css28);

exports.default = DropDown;
//# sourceMappingURL=DropDown.js.map
