'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

const INPUT_BORDER = 1;
const START_DATE = 'Start day';
const END_DATE = 'End day';

exports.END_DATE = END_DATE;
exports.INPUT_BORDER = INPUT_BORDER;
exports.START_DATE = START_DATE;
//# sourceMappingURL=consts.js.map
