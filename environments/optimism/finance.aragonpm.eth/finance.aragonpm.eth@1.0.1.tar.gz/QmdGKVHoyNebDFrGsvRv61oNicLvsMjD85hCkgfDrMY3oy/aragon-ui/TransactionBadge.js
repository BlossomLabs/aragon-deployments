'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

function _interopDefault (ex) { return (ex && (typeof ex === 'object') && 'default' in ex) ? ex['default'] : ex; }

var React = require('react');
var React__default = _interopDefault(React);
require('./_commonjsHelpers-72d386ba.js');
var index = require('./index-c8446775.js');
require('styled-components');
require('./color.js');
require('./components.js');
require('./contains-component.js');
require('./css.js');
require('./dayjs.min-966150e3.js');
require('./date.js');
require('./miscellaneous.js');
var environment = require('./environment.js');
require('./font.js');
require('./math-4eaf20a0.js');
require('./characters.js');
require('./format.js');
require('./keycodes.js');
require('./url.js');
var web3 = require('./web3.js');
require('./constants.js');
require('./breakpoints.js');
require('./springs.js');
require('./text-styles.js');
require('./theme-dark.js');
require('./theme-light.js');
require('./Theme.js');
require('./extends-43472f94.js');
require('./index-766bccf9.js');
require('./defineProperty-7b1b81d8.js');
require('./FocusVisible.js');
require('./ButtonBase.js');
var BadgeBase = require('./BadgeBase.js');

const TransactionBadge = /*#__PURE__*/React__default.memo(function TransactionBadge(_ref) {
  let {
    className,
    disabled,
    labelStyle,
    networkType,
    shorten,
    style,
    transaction,
    // Deprecated
    background,
    fontSize
  } = _ref;
  if (fontSize) {
    environment.warnOnce('TransactionBadge:fontSize', 'The “fontSize” prop is deprecated. Please use “labelStyle” to style the label instead.');
  }
  if (background) {
    environment.warnOnce('TransactionBadge:background', 'The “background” prop is deprecated. Please use “className” to style the badge instead.');
  }
  const isTx = web3.isTransaction(transaction);
  const transactionUrl = isTx ? web3.blockExplorerUrl('transaction', transaction, {
    networkType
  }) : '';
  const label = !isTx ? 'Invalid transaction' : shorten ? web3.shortenTransaction(transaction) : transaction;
  return /*#__PURE__*/React__default.createElement(BadgeBase.default, {
    badgeOnly: true,
    disabled: disabled || !transactionUrl,
    href: transactionUrl,
    label: label,
    labelStyle: labelStyle,
    title: transaction
  });
});
TransactionBadge.propTypes = {
  className: index.PropTypes.string,
  disabled: index.PropTypes.bool,
  labelStyle: index.PropTypes.string,
  networkType: index.PropTypes.string,
  shorten: index.PropTypes.bool,
  style: index.PropTypes.object,
  transaction: index.PropTypes.string.isRequired,
  // Deprecated
  background: index.PropTypes.string,
  fontSize: index.PropTypes.string
};
TransactionBadge.defaultProps = {
  networkType: 'main',
  shorten: true
};

exports.default = TransactionBadge;
//# sourceMappingURL=TransactionBadge.js.map
