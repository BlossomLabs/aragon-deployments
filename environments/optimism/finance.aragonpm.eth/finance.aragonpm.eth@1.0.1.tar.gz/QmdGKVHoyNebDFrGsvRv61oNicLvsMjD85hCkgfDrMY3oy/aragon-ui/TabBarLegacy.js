'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

function _interopDefault (ex) { return (ex && (typeof ex === 'object') && 'default' in ex) ? ex['default'] : ex; }

var React = require('react');
var React__default = _interopDefault(React);
require('./_commonjsHelpers-72d386ba.js');
var index = require('./index-c8446775.js');
var _styled = require('styled-components');
var _styled__default = _interopDefault(_styled);
require('./color.js');
require('./components.js');
require('./contains-component.js');
var css = require('./css.js');
require('./dayjs.min-966150e3.js');
require('./date.js');
var miscellaneous = require('./miscellaneous.js');
require('./environment.js');
var font = require('./font.js');
require('./math-4eaf20a0.js');
require('./characters.js');
require('./format.js');
require('./keycodes.js');
require('./url.js');
require('./web3.js');
require('./theme-dark.js');
require('./theme-light.js');
var Theme = require('./Theme.js');
var defineProperty$1 = require('./defineProperty-7b1b81d8.js');

class TabBar extends React__default.Component {
  constructor() {
    super(...arguments);
    defineProperty$1._defineProperty(this, "state", {
      displayFocusRing: false
    });
    defineProperty$1._defineProperty(this, "_barRef", /*#__PURE__*/React__default.createRef());
    defineProperty$1._defineProperty(this, "handleMouseDown", () => {
      this.disableFocusRing();
    });
    defineProperty$1._defineProperty(this, "handleKeydown", _ref => {
      let {
        key
      } = _ref;
      if (key === 'Enter') {
        this.selectElement(document.activeElement);
        this.enableFocusRing();
      }
      if (key === 'Tab') {
        this.enableFocusRing();
      }
    });
    defineProperty$1._defineProperty(this, "handleTabMouseDown", _ref2 => {
      let {
        currentTarget
      } = _ref2;
      // We would usually avoid using the DOM when possible, and prefer using a
      // separate component (`Tab`) to keep the `index` in a prop, then pass it
      // using an event prop. But since `this.selectElement()` is needed (so we
      // can pass `document.activeElement` to it for the keyboard), and we have
      // `e.currentTarget` in the event object, we might as well use it for the
      // pointer device too.
      this.selectElement(currentTarget);
    });
  }
  componentDidMount() {
    document.addEventListener('keydown', this.handleKeydown);
  }
  componentWillUnmount() {
    document.removeEventListener('keydown', this.handleKeydown);
  }
  enableFocusRing() {
    this.setState({
      displayFocusRing: true
    });
  }
  disableFocusRing() {
    this.setState({
      displayFocusRing: false
    });
  }
  selectElement(element) {
    const {
      onChange
    } = this.props;
    if (!element || !this._barRef.current) {
      return;
    }
    const index = [...this._barRef.current.childNodes].indexOf(element);
    if (index === -1) {
      return;
    }
    onChange(index);
  }
  render() {
    const {
      displayFocusRing
    } = this.state;
    const {
      items,
      selected,
      inAppBar
    } = this.props;
    return /*#__PURE__*/React__default.createElement("nav", {
      onMouseDown: this.handleMouseDown
    }, /*#__PURE__*/React__default.createElement(Bar, {
      ref: this._barRef,
      border: !inAppBar
    }, items.map((item, i) => /*#__PURE__*/React__default.createElement(Tab, {
      key: i,
      tabIndex: "0",
      selected: i === selected,
      focusRing: displayFocusRing,
      onMouseDown: this.handleTabMouseDown
    }, /*#__PURE__*/React__default.createElement(Label, {
      selected: i === selected
    }, item), displayFocusRing && /*#__PURE__*/React__default.createElement(FocusRing, null)))));
  }
}

/* eslint-disable react/prop-types */
defineProperty$1._defineProperty(TabBar, "propTypes", {
  items: index.PropTypes.arrayOf(index.PropTypes.node).isRequired,
  selected: index.PropTypes.number,
  onChange: index.PropTypes.func,
  inAppBar: index.PropTypes.bool
});
defineProperty$1._defineProperty(TabBar, "defaultProps", {
  selected: 0,
  onChange: miscellaneous.noop
});
function Bar(_ref3) {
  let {
    children,
    border
  } = _ref3;
  const theme = Theme.useTheme();
  return /*#__PURE__*/React__default.createElement(_StyledUl, {
    $_css: border ? `1px solid ${theme.border}` : '0'
  }, children);
}
function FocusRing(_ref4) {
  let {
    children
  } = _ref4;
  const theme = Theme.useTheme();
  return /*#__PURE__*/React__default.createElement(_StyledSpan, {
    className: "TabBarLegacy-FocusRing",
    $_css2: theme.accent
  }, children);
}
function Tab(_ref5) {
  let {
    children,
    selected
  } = _ref5;
  return /*#__PURE__*/React__default.createElement(_StyledLi, {
    $_css3: font.font({
      weight: selected ? 'bold' : 'normal',
      deprecationNotice: false
    }),
    $_css4: css.unselectable()
  }, children);
}
function Label(_ref6) {
  let {
    children,
    selected
  } = _ref6;
  const theme = Theme.useTheme();
  return /*#__PURE__*/React__default.createElement(_StyledSpan2, {
    $_css5: selected ? theme.accent : 'transparent'
  }, children);
}
var _StyledUl = _styled__default("ul").withConfig({
  displayName: "TabBarLegacy___StyledUl",
  componentId: "sc-nx1y4o-0"
})(["display:flex;border-bottom:", ";"], p => p.$_css);
var _StyledSpan = _styled__default("span").withConfig({
  displayName: "TabBarLegacy___StyledSpan",
  componentId: "sc-nx1y4o-1"
})(["display:none;position:absolute;top:-5px;left:-5px;right:-5px;bottom:-5px;border:2px solid ", ";border-radius:2px;"], p => p.$_css2);
var _StyledLi = _styled__default("li").withConfig({
  displayName: "TabBarLegacy___StyledLi",
  componentId: "sc-nx1y4o-2"
})(["position:relative;list-style:none;padding:0 30px;cursor:pointer;", ";", ";&:focus{outline:0;.TabBarLegacy-FocusRing{display:block;}}"], p => p.$_css3, p => p.$_css4);
var _StyledSpan2 = _styled__default("span").withConfig({
  displayName: "TabBarLegacy___StyledSpan2",
  componentId: "sc-nx1y4o-3"
})(["display:flex;margin-bottom:-1px;padding:5px 0 3px;border-bottom:4px solid ", ";"], p => p.$_css5);

exports.default = TabBar;
//# sourceMappingURL=TabBarLegacy.js.map
