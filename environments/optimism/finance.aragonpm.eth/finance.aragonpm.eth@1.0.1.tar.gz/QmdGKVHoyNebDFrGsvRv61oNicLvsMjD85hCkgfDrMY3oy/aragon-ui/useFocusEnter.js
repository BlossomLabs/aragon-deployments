'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

function _interopDefault (ex) { return (ex && (typeof ex === 'object') && 'default' in ex) ? ex['default'] : ex; }

var React = require('react');
var React__default = _interopDefault(React);

function useFocusEnter(cb, _ref) {
  const fallbackRef = React.useRef();
  const ref = _ref || fallbackRef;
  const handleFocusEnter = React.useCallback(event => {
    if (ref?.current?.contains(event.target)) {
      cb(event);
    }
  }, [cb, ref]);
  return {
    ref,
    handleFocusEnter
  };
}

exports.useFocusEnter = useFocusEnter;
//# sourceMappingURL=useFocusEnter.js.map
