'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

require('./_commonjsHelpers-72d386ba.js');
var index = require('./index-c8446775.js');

var BadgePopoverActionType = index.PropTypes.shape({
  label: index.PropTypes.node.isRequired,
  onClick: index.PropTypes.func.isRequired
});

exports.default = BadgePopoverActionType;
//# sourceMappingURL=BadgePopoverActionType.js.map
