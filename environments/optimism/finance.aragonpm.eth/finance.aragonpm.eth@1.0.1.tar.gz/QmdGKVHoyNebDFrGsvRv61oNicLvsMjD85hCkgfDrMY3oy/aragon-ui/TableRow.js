'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

function _interopDefault (ex) { return (ex && (typeof ex === 'object') && 'default' in ex) ? ex['default'] : ex; }

var _styled = require('styled-components');
var _styled__default = _interopDefault(_styled);

const StyledTableRow = _styled__default.tr.withConfig({
  displayName: "TableRow__StyledTableRow",
  componentId: "sc-1r2ve5e-0"
})([""]);

exports.default = StyledTableRow;
//# sourceMappingURL=TableRow.js.map
