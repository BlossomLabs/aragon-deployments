'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

function _interopDefault (ex) { return (ex && (typeof ex === 'object') && 'default' in ex) ? ex['default'] : ex; }

var React = require('react');
var React__default = _interopDefault(React);
require('./_commonjsHelpers-72d386ba.js');
var index = require('./index-c8446775.js');
var _styled = require('styled-components');
var _styled__default = _interopDefault(_styled);
require('./color.js');
require('./components.js');
require('./contains-component.js');
require('./css.js');
require('./dayjs.min-966150e3.js');
require('./date.js');
require('./miscellaneous.js');
require('./environment.js');
require('./font.js');
require('./math-4eaf20a0.js');
require('./characters.js');
require('./format.js');
require('./keycodes.js');
require('./url.js');
require('./web3.js');
var constants = require('./constants.js');
require('./breakpoints.js');
require('./springs.js');
require('./text-styles.js');
require('./theme-dark.js');
require('./theme-light.js');
var Theme = require('./Theme.js');
var _extends$1 = require('./extends-43472f94.js');
require('./defineProperty-7b1b81d8.js');
require('./FocusVisible.js');
var ButtonBase = require('./ButtonBase.js');

function ButtonText(_ref) {
  let {
    horizontalPadding,
    ...props
  } = _ref;
  const theme = Theme.useTheme();
  const leftPadding = Number(horizontalPadding === 'left' || horizontalPadding === 'both') * constants.GU;
  const rightPadding = Number(horizontalPadding === 'right' || horizontalPadding === 'both') * constants.GU;
  return /*#__PURE__*/React__default.createElement(_StyledButtonBase, _extends$1._extends({}, props, {
    $_css: 1 * constants.GU,
    $_css2: rightPadding,
    $_css3: 1 * constants.GU,
    $_css4: leftPadding,
    $_css5: theme.link
  }));
}
ButtonText.propTypes = {
  ...ButtonBase.default.propTypes,
  horizontalPadding: index.PropTypes.oneOf(['both', 'left', 'right', 'none'])
};
ButtonText.defaultProps = {
  horizontalPadding: 'both'
};
var _StyledButtonBase = _styled__default(ButtonBase.default).withConfig({
  displayName: "ButtonText___StyledButtonBase",
  componentId: "sc-187n6ja-0"
})(["padding:", "px ", "px ", "px ", "px;color:", ";font-size:inherit;"], p => p.$_css, p => p.$_css2, p => p.$_css3, p => p.$_css4, p => p.$_css5);

exports.default = ButtonText;
//# sourceMappingURL=ButtonText.js.map
