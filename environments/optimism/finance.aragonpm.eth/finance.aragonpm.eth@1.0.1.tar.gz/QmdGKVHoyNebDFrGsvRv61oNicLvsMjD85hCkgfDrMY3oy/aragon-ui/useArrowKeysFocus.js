'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

function _interopDefault (ex) { return (ex && (typeof ex === 'object') && 'default' in ex) ? ex['default'] : ex; }

var React = require('react');
var React__default = _interopDefault(React);
require('./_commonjsHelpers-72d386ba.js');
require('./color.js');
require('./components.js');
require('./contains-component.js');
require('./css.js');
require('./dayjs.min-966150e3.js');
require('./date.js');
require('./miscellaneous.js');
require('./environment.js');
require('./font.js');
require('./math-4eaf20a0.js');
require('./characters.js');
require('./format.js');
var keycodes = require('./keycodes.js');
require('./url.js');
require('./web3.js');

function useArrowKeysFocus(refs) {
  const [highlightedIndex, setHighlightedIndex] = React.useState(-1);
  const cycleFocus = React.useCallback((e, change) => {
    e.preventDefault();
    let next = highlightedIndex + change;
    if (next > refs.length - 1) {
      next = 0;
    }
    if (next < 0) {
      next = refs.length - 1;
    }
    setHighlightedIndex(next);
  }, [highlightedIndex, refs.length]);
  const handleKeyDown = React.useCallback(event => {
    const {
      keyCode
    } = event;
    if (keyCode === keycodes.KEY_UP || keyCode === keycodes.KEY_DOWN) {
      cycleFocus(event, keyCode === keycodes.KEY_UP ? -1 : 1);
    }
  }, [cycleFocus]);
  React.useEffect(() => {
    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [handleKeyDown]);
  React.useEffect(() => {
    if (highlightedIndex === -1) {
      return;
    }
    if (!refs[highlightedIndex]) {
      return;
    }
    refs[highlightedIndex].focus();
  }, [highlightedIndex, refs]);
  return {
    highlightedIndex,
    setHighlightedIndex
  };
}

exports.useArrowKeysFocus = useArrowKeysFocus;
//# sourceMappingURL=useArrowKeysFocus.js.map
