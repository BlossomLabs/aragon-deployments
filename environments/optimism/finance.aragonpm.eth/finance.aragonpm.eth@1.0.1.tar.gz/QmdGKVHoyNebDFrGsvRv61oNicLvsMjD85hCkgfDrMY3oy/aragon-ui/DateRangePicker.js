'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

function _interopDefault (ex) { return (ex && (typeof ex === 'object') && 'default' in ex) ? ex['default'] : ex; }

var React = require('react');
var React__default = _interopDefault(React);
require('./_commonjsHelpers-72d386ba.js');
var index = require('./index-c8446775.js');
var _styled = require('styled-components');
var _styled__default = _interopDefault(_styled);
require('./color.js');
require('./components.js');
require('./contains-component.js');
require('./css.js');
var dayjs_min = require('./dayjs.min-966150e3.js');
require('./date.js');
require('./miscellaneous.js');
require('./environment.js');
require('./font.js');
require('./math-4eaf20a0.js');
require('./characters.js');
require('./format.js');
require('./keycodes.js');
require('./url.js');
require('./web3.js');
var constants = require('./constants.js');
require('./breakpoints.js');
require('./springs.js');
require('./text-styles.js');
require('./theme-dark.js');
require('./theme-light.js');
var Theme = require('./Theme.js');
var _extends$1 = require('./extends-43472f94.js');
require('./index-766bccf9.js');
require('./defineProperty-7b1b81d8.js');
require('./isObject-b8c5dfc0.js');
var Viewport = require('./Viewport-0f56d694.js');
require('./Layout.js');
require('./FocusVisible.js');
require('./ButtonBase.js');
require('./IconPropTypes-68080ae8.js');
require('./IconAddUser.js');
require('./IconAlert.js');
require('./IconAlignCenter.js');
require('./IconAlignJustify.js');
require('./IconAlignLeft.js');
require('./IconAlignRight.js');
require('./IconAragon.js');
require('./IconArrowDown.js');
require('./IconArrowLeft.js');
require('./IconArrowRight.js');
require('./IconArrowUp.js');
require('./IconAtSign.js');
require('./IconBlock.js');
require('./IconBookmark.js');
require('./IconCalendar.js');
require('./IconCanvas.js');
require('./IconCaution.js');
require('./IconCenter.js');
require('./IconChart.js');
require('./IconChat.js');
require('./IconCheck.js');
require('./IconChip.js');
require('./IconCircleCheck.js');
require('./IconCircleMinus.js');
require('./IconCirclePlus.js');
require('./IconClock.js');
require('./IconCloudDownload.js');
require('./IconCloudUpload.js');
require('./IconCoin.js');
require('./IconConfiguration.js');
require('./IconConnect.js');
require('./IconConnection.js');
require('./IconConsole.js');
require('./IconCopy.js');
require('./IconCross.js');
require('./IconDashedSquare.js');
require('./IconDown.js');
require('./IconDownload.js');
require('./IconEdit.js');
require('./IconEllipsis.js');
require('./IconEnter.js');
require('./IconEthereum.js');
require('./IconExternal.js');
require('./IconFile.js');
require('./IconFilter.js');
require('./IconFlag.js');
require('./IconFolder.js');
require('./IconGraph2.js');
require('./IconGraph.js');
require('./IconGrid.js');
require('./IconGroup.js');
require('./IconHash.js');
require('./IconHeart.js');
require('./IconHide.js');
require('./IconHome.js');
require('./IconImage.js');
require('./IconInfo.js');
require('./IconLabel.js');
require('./IconLayers.js');
require('./IconLeft.js');
require('./IconLink.js');
require('./IconLocation.js');
require('./IconLock.js');
require('./IconMail.js');
require('./IconMaximize.js');
require('./IconMenu.js');
require('./IconMinimize.js');
require('./IconMinus.js');
require('./IconMove.js');
require('./IconNoPicture.js');
require('./IconPicture.js');
require('./IconPlus.js');
require('./IconPower.js');
require('./IconPrint.js');
require('./IconProhibited.js');
require('./IconQuestion.js');
require('./IconRefresh.js');
require('./IconRemoveUser.js');
require('./IconRight.js');
require('./IconRotateLeft.js');
require('./IconRotateRight.js');
require('./IconSearch.js');
require('./IconSettings.js');
require('./IconShare.js');
require('./IconSquareMinus.js');
require('./IconSquarePlus.js');
require('./IconSquare.js');
require('./IconStarFilled.js');
require('./IconStar.js');
require('./IconSwap.js');
require('./IconTarget.js');
require('./IconToken.js');
require('./IconTrash.js');
require('./IconUnlock.js');
require('./IconUp.js');
require('./IconUpload.js');
require('./IconUser.js');
require('./IconView.js');
require('./IconVote.js');
require('./IconWallet.js');
require('./IconWarning.js');
require('./IconWorld.js');
require('./IconWrite.js');
require('./IconZoomIn.js');
require('./IconZoomOut.js');
require('./objectWithoutPropertiesLoose-d28f0f6e.js');
require('react-dom');
require('./web-449fa78f.js');
var Button = require('./Button.js');
require('./getDisplayName-7ab6d318.js');
require('./index-70be9e8d.js');
require('./index-d200e416.js');
require('./RootPortal.js');
require('./proptypes-70c08808.js');
var Popover = require('./Popover.js');
require('./observe.js');
require('./index-aa9c1462.js');
require('./providers.js');
require('./MonthDay-c699b692.js');
var DatePicker = require('./DatePicker.js');
var consts = require('./consts.js');
var Labels = require('./Labels.js');
var utils = require('./utils.js');

function DateRangePicker(_ref) {
  let {
    format,
    endDate: endDateProp,
    onChange,
    startDate: startDateProp
  } = _ref;
  const theme = Theme.useTheme();
  const labelsRef = React.useRef();
  const [showPicker, setShowPicker] = React.useState(false);
  const [startDate, setStartDate] = React.useState(startDateProp);
  const [endDate, setEndDate] = React.useState(endDateProp);

  // on closing the picked, reset state
  React.useEffect(() => {
    if (!showPicker) {
      setStartDate(startDateProp);
      setEndDate(endDateProp);
    }
  }, [endDateProp, startDateProp, showPicker]);
  const handlePopoverClose = React.useCallback(() => setShowPicker(false), []);
  const handleLabelsClick = React.useCallback(() => {
    setShowPicker(show => !show);
  }, []);
  const handleDateClick = React.useCallback(date => {
    const result = utils.handleDateSelect({
      date,
      startDate,
      endDate
    });
    result.startDate !== undefined && setStartDate(result.startDate);
    result.endDate !== undefined && setEndDate(result.endDate);
  }, [startDate, endDate]);
  const handleApply = React.useCallback(() => {
    setShowPicker(false);
    if (startDate && endDate) {
      onChange({
        start: dayjs_min.dayjs(startDate).startOf('day').toDate(),
        end: dayjs_min.dayjs(endDate).endOf('day').toDate()
      });
    }
  }, [endDate, onChange, startDate]);
  const handleClear = React.useCallback(() => {
    setStartDate(null);
    setEndDate(null);
    setShowPicker(false);
    onChange({
      start: null,
      end: null
    });
  }, [onChange]);
  const labelProps = React.useMemo(() => {
    const _startDate = showPicker ? startDate : startDateProp;
    const _endDate = showPicker ? endDate : endDateProp;
    return {
      startText: _startDate ? dayjs_min.dayjs(_startDate).format(format) : consts.START_DATE,
      endText: _endDate ? dayjs_min.dayjs(_endDate).format(format) : consts.END_DATE
    };
  }, [endDate, endDateProp, format, showPicker, startDate, startDateProp]);
  const compactMode = Viewport.useViewport().below('medium');
  const displayMonthBeforeOnLeft = React.useMemo(() => {
    // If both dates are in the same month, use the right calendar
    // for it, and display month before on the left calendar.
    const propsDatesInSameMonth = startDateProp && endDateProp && dayjs_min.dayjs(startDateProp).isSame(dayjs_min.dayjs(endDateProp), 'month');
    return !compactMode && (propsDatesInSameMonth || !startDateProp);
  }, [compactMode, endDateProp, startDateProp]);
  return /*#__PURE__*/React__default.createElement("div", null, /*#__PURE__*/React__default.createElement(Labels.default, _extends$1._extends({
    ref: labelsRef,
    enabled: showPicker,
    hasSetDates: Boolean(startDateProp && endDateProp),
    onClick: handleLabelsClick
  }, labelProps)), /*#__PURE__*/React__default.createElement(_StyledPopover, {
    closeOnOpenerFocus: true,
    onClose: handlePopoverClose,
    opener: labelsRef.current,
    placement: "bottom-start",
    visible: showPicker,
    $_css: 37.5 * constants.GU + 2
  }, /*#__PURE__*/React__default.createElement(_StyledDiv, {
    $_css2: 2.5 * constants.GU,
    $_css3: 3 * constants.GU,
    $_css4: 3 * constants.GU,
    $_css5: theme.border,
    $_css6: theme.surface
  }, /*#__PURE__*/React__default.createElement(_StyledDiv2, null, /*#__PURE__*/React__default.createElement(DatePicker.default, {
    datesRangeEnd: endDate,
    datesRangeStart: startDate,
    initialDate: dayjs_min.dayjs(startDateProp || undefined).subtract(displayMonthBeforeOnLeft ? 1 : 0, 'month').toDate(),
    onSelect: handleDateClick
  }), !compactMode && /*#__PURE__*/React__default.createElement(_StyledDatePicker, {
    datesRangeEnd: endDate,
    datesRangeStart: startDate,
    initialDate: dayjs_min.dayjs(endDateProp || undefined).toDate(),
    onSelect: handleDateClick,
    $_css7: 1 * constants.GU
  })), /*#__PURE__*/React__default.createElement(_StyledDiv3, {
    $_css8: constants.GU * 2.25,
    $_css9: compactMode ? '' : `
                    max-width: 247px;
                    margin-left: auto;
                  `
  }, /*#__PURE__*/React__default.createElement(Button.default, {
    onClick: handleClear,
    size: "small",
    wide: true
  }, "Reset"), /*#__PURE__*/React__default.createElement(_StyledButton, {
    disabled: !startDate || !endDate,
    mode: "strong",
    onClick: handleApply,
    size: "small",
    wide: true,
    $_css10: 1.5 * constants.GU
  }, "Apply")))));
}
DateRangePicker.propTypes = {
  endDate: index.PropTypes.instanceOf(Date),
  format: index.PropTypes.string,
  onChange: index.PropTypes.func,
  startDate: index.PropTypes.instanceOf(Date)
};
DateRangePicker.defaultProps = {
  format: 'MM/DD/YYYY',
  onChange: () => {}
};
var _StyledPopover = _styled__default(Popover.default).withConfig({
  displayName: "DateRangePicker___StyledPopover",
  componentId: "sc-1y4kzbo-0"
})(["min-width:", "px;border:0;filter:none;background:none;margin:2px 0 0 0;"], p => p.$_css);
var _StyledDiv = _styled__default("div").withConfig({
  displayName: "DateRangePicker___StyledDiv",
  componentId: "sc-1y4kzbo-1"
})(["padding:", "px ", "px ", "px;border:1px solid ", ";border-radius:", "px;background:", ";"], p => p.$_css2, p => p.$_css3, p => p.$_css4, p => p.$_css5, constants.RADIUS, p => p.$_css6);
var _StyledDiv2 = _styled__default("div").withConfig({
  displayName: "DateRangePicker___StyledDiv2",
  componentId: "sc-1y4kzbo-2"
})(["display:flex;flex-direction:row;align-items:baseline;"]);
var _StyledDatePicker = _styled__default(DatePicker.default).withConfig({
  displayName: "DateRangePicker___StyledDatePicker",
  componentId: "sc-1y4kzbo-3"
})(["margin-left:", "px;"], p => p.$_css7);
var _StyledDiv3 = _styled__default("div").withConfig({
  displayName: "DateRangePicker___StyledDiv3",
  componentId: "sc-1y4kzbo-4"
})(["display:flex;align-items:center;justify-content:space-between;margin-top:", "px;", ";"], p => p.$_css8, p => p.$_css9);
var _StyledButton = _styled__default(Button.default).withConfig({
  displayName: "DateRangePicker___StyledButton",
  componentId: "sc-1y4kzbo-5"
})(["margin-left:", "px;"], p => p.$_css10);

exports.default = DateRangePicker;
//# sourceMappingURL=DateRangePicker.js.map
