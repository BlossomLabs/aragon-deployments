'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

function _interopDefault (ex) { return (ex && (typeof ex === 'object') && 'default' in ex) ? ex['default'] : ex; }

var React = require('react');
var React__default = _interopDefault(React);
require('./_commonjsHelpers-72d386ba.js');
var index = require('./index-c8446775.js');
var _styled = require('styled-components');
var _styled__default = _interopDefault(_styled);
require('./color.js');
require('./components.js');
require('./contains-component.js');
var css = require('./css.js');
require('./dayjs.min-966150e3.js');
require('./date.js');
require('./miscellaneous.js');
var environment = require('./environment.js');
require('./font.js');
require('./math-4eaf20a0.js');
require('./characters.js');
require('./format.js');
var keycodes = require('./keycodes.js');
require('./url.js');
require('./web3.js');
var constants = require('./constants.js');
require('./breakpoints.js');
var springs = require('./springs.js');
var textStyles = require('./text-styles.js');
require('./theme-dark.js');
require('./theme-light.js');
var Theme = require('./Theme.js');
var _extends$1 = require('./extends-43472f94.js');
var index$1 = require('./index-766bccf9.js');
require('./defineProperty-7b1b81d8.js');
require('./isObject-b8c5dfc0.js');
var Viewport = require('./Viewport-0f56d694.js');
require('./Layout.js');
require('./FocusVisible.js');
require('./ButtonBase.js');
require('./IconPropTypes-68080ae8.js');
require('./IconAddUser.js');
require('./IconAlert.js');
require('./IconAlignCenter.js');
require('./IconAlignJustify.js');
require('./IconAlignLeft.js');
require('./IconAlignRight.js');
require('./IconAragon.js');
require('./IconArrowDown.js');
require('./IconArrowLeft.js');
require('./IconArrowRight.js');
require('./IconArrowUp.js');
require('./IconAtSign.js');
require('./IconBlock.js');
require('./IconBookmark.js');
require('./IconCalendar.js');
require('./IconCanvas.js');
require('./IconCaution.js');
require('./IconCenter.js');
require('./IconChart.js');
require('./IconChat.js');
require('./IconCheck.js');
require('./IconChip.js');
require('./IconCircleCheck.js');
require('./IconCircleMinus.js');
require('./IconCirclePlus.js');
require('./IconClock.js');
require('./IconCloudDownload.js');
require('./IconCloudUpload.js');
require('./IconCoin.js');
require('./IconConfiguration.js');
require('./IconConnect.js');
require('./IconConnection.js');
require('./IconConsole.js');
require('./IconCopy.js');
var IconCross = require('./IconCross.js');
require('./IconDashedSquare.js');
require('./IconDown.js');
require('./IconDownload.js');
require('./IconEdit.js');
require('./IconEllipsis.js');
require('./IconEnter.js');
require('./IconEthereum.js');
require('./IconExternal.js');
require('./IconFile.js');
require('./IconFilter.js');
require('./IconFlag.js');
require('./IconFolder.js');
require('./IconGraph2.js');
require('./IconGraph.js');
require('./IconGrid.js');
require('./IconGroup.js');
require('./IconHash.js');
require('./IconHeart.js');
require('./IconHide.js');
require('./IconHome.js');
require('./IconImage.js');
require('./IconInfo.js');
require('./IconLabel.js');
require('./IconLayers.js');
require('./IconLeft.js');
require('./IconLink.js');
require('./IconLocation.js');
require('./IconLock.js');
require('./IconMail.js');
require('./IconMaximize.js');
require('./IconMenu.js');
require('./IconMinimize.js');
require('./IconMinus.js');
require('./IconMove.js');
require('./IconNoPicture.js');
require('./IconPicture.js');
require('./IconPlus.js');
require('./IconPower.js');
require('./IconPrint.js');
require('./IconProhibited.js');
require('./IconQuestion.js');
require('./IconRefresh.js');
require('./IconRemoveUser.js');
require('./IconRight.js');
require('./IconRotateLeft.js');
require('./IconRotateRight.js');
require('./IconSearch.js');
require('./IconSettings.js');
require('./IconShare.js');
require('./IconSquareMinus.js');
require('./IconSquarePlus.js');
require('./IconSquare.js');
require('./IconStarFilled.js');
require('./IconStar.js');
require('./IconSwap.js');
require('./IconTarget.js');
require('./IconToken.js');
require('./IconTrash.js');
require('./IconUnlock.js');
require('./IconUp.js');
require('./IconUpload.js');
require('./IconUser.js');
require('./IconView.js');
require('./IconVote.js');
require('./IconWallet.js');
require('./IconWarning.js');
require('./IconWorld.js');
require('./IconWrite.js');
require('./IconZoomIn.js');
require('./IconZoomOut.js');
require('./objectWithoutPropertiesLoose-d28f0f6e.js');
require('react-dom');
var web = require('./web-449fa78f.js');
require('./Button.js');
var ButtonIcon = require('./ButtonIcon.js');
require('./index-d200e416.js');
var RootPortal = require('./RootPortal.js');

const CONTENT_PADDING = 3 * constants.GU;

// The closing position of the panel, on the right side of the viewport.
// It takes into consideration the shadow of the panel.
const CLOSING_POSITION = 5 * constants.GU;
const SidePanelContext = /*#__PURE__*/React__default.createContext(null);
function SidePanel(_ref2) {
  let {
    blocking,
    children,
    opened,
    onClose,
    onTransitionEnd,
    title
  } = _ref2;
  const theme = Theme.useTheme();
  const {
    below
  } = Viewport.useViewport();
  const compact = below('medium');
  const close = React.useCallback(() => {
    if (!blocking) {
      onClose();
    }
  }, [blocking, onClose]);
  const handleEscape = React.useCallback(event => {
    if (event.keyCode === keycodes.KEY_ESC && opened) {
      close();
    }
  }, [opened, close]);
  const [status, setStatus] = React.useState(opened ? 'opened' : 'closed');
  const [readyToFocus, setReadyToFocus] = React.useState(false);
  const handleTransitionRest = React.useCallback(() => {
    onTransitionEnd(opened);
    setStatus(opened ? 'opened' : 'closed');
  }, [opened, onTransitionEnd]);
  const handleTransitionStart = React.useCallback(() => {
    setStatus(opened ? 'opening' : 'closing');
  }, [opened]);
  const handleTransitionFrame = React.useCallback((item, _, _ref3) => {
    let {
      progress
    } = _ref3;
    if (progress > 0.5 && !readyToFocus) {
      setReadyToFocus(true);
    } else if (progress < 0.5 && readyToFocus) {
      setReadyToFocus(false);
    }
  }, [readyToFocus]);
  const handleTransitionDestroyed = React.useCallback(() => {
    setReadyToFocus(false);
  }, []);
  React.useEffect(() => {
    document.addEventListener('keydown', handleEscape);
    return () => {
      document.removeEventListener('keydown', handleEscape);
    };
  }, [handleEscape]);
  return /*#__PURE__*/React__default.createElement(RootPortal.default, null, /*#__PURE__*/React__default.createElement(index$1.i, {
    name: "SidePanel"
  }, /*#__PURE__*/React__default.createElement(web.Transition, {
    items: opened,
    config: {
      ...springs.springs.lazy,
      precision: 0.001
    },
    from: {
      progress: 0
    },
    enter: {
      progress: Number(opened)
    },
    leave: {
      progress: 0
    },
    onRest: handleTransitionRest,
    onStart: handleTransitionStart,
    onFrame: handleTransitionFrame,
    onDestroyed: handleTransitionDestroyed,
    unique: true,
    native: true
  }, opened => opened && (_ref4 => {
    let {
      progress
    } = _ref4;
    return /*#__PURE__*/React__default.createElement(_StyledDiv, {
      $_css: status !== 'closing' ? 'auto' : 'none'
    }, /*#__PURE__*/React__default.createElement(_StyledAnimatedDiv, {
      onClick: close,
      style: {
        opacity: progress,
        pointerEvents: status !== 'closing' ? 'auto' : 'none'
      },
      $_css2: theme.overlay.alpha(0.9)
    }), /*#__PURE__*/React__default.createElement(Panel, {
      compact: compact,
      style: {
        transform: progress.interpolate(v => `
                          translate3d(
                            calc(
                              ${100 * (1 - v)}% +
                              ${CLOSING_POSITION * (1 - v)}px
                            ), 0, 0
                          )
                        `)
      }
    }, /*#__PURE__*/React__default.createElement(_StyledHeader, {
      $_css3: 8 * constants.GU,
      $_css4: theme.border,
      $_css5: css.unselectable()
    }, /*#__PURE__*/React__default.createElement(_StyledH, {
      $_css6: theme.surfaceContent,
      $_css7: textStyles.textStyle('body1')
    }, title), !blocking && /*#__PURE__*/React__default.createElement(_StyledButtonIcon, {
      label: "Close",
      onClick: close,
      $_css8: !compact ? `
                              top: ${2 * constants.GU}px;
                              right: ${2 * constants.GU}px;
                            ` : `
                              top: 0;
                              right: 0;
                              height: ${8 * constants.GU}px;
                              width: ${8 * constants.GU}px;
                            `
    }, /*#__PURE__*/React__default.createElement(IconCross.default, {
      color: theme.surfaceIcon
    }))), /*#__PURE__*/React__default.createElement(_StyledDiv2, null, /*#__PURE__*/React__default.createElement(_StyledDiv3, null, /*#__PURE__*/React__default.createElement(SidePanelContext.Provider, {
      value: {
        status,
        readyToFocus
      }
    }, children)))));
  }))));
}
SidePanel.propTypes = {
  blocking: index.PropTypes.bool,
  children: index.PropTypes.node.isRequired,
  opened: index.PropTypes.bool,
  onClose: index.PropTypes.func,
  onTransitionEnd: index.PropTypes.func,
  title: index.PropTypes.node.isRequired
};
SidePanel.defaultProps = {
  opened: true,
  blocking: false,
  onClose: () => {},
  onTransitionEnd: () => {}
};
const Panel = /*#__PURE__*/React__default.memo(function Panel(_ref5) {
  let {
    compact,
    ...props
  } = _ref5;
  const theme = Theme.useTheme();
  return /*#__PURE__*/React__default.createElement(_StyledAnimatedAside, _extends$1._extends({}, props, {
    $_css9: theme.surface,
    $_css10: !compact ? 'max-width: 450px;' : ''
  }));
});
Panel.propTypes = {
  compact: index.PropTypes.bool
};
function useSidePanel() {
  const value = React.useContext(SidePanelContext);
  if (value === null) {
    throw new Error('useSidePanel() was used outside of the SidePanel render tree, ' + 'which has to be declared at an upper level!');
  }
  return value;
}
function useSidePanelFocusOnReady(ref) {
  const {
    readyToFocus
  } = useSidePanel();
  const fallbackRef = React.useRef();
  const _ref = ref || fallbackRef;
  React.useEffect(() => {
    if (readyToFocus && _ref.current) {
      if (_ref.current.focus) {
        _ref.current.focus();
      } else {
        environment.warn('useSidePanelFocusOnReady(): the focus() method wasn’t available on ' + 'the passed ref.');
      }
    }
  }, [readyToFocus, _ref]);
  return _ref;
}

// Used for spacing in SidePanelSplit and SidePanelSeparator
SidePanel.HORIZONTAL_PADDING = CONTENT_PADDING;
var _StyledDiv = _styled__default("div").withConfig({
  displayName: "SidePanel___StyledDiv",
  componentId: "sc-ztht0n-0"
})(["position:absolute;z-index:1;top:0;left:0;right:0;bottom:0;pointer-events:", ";overflow:hidden;"], p => p.$_css);
var _StyledAnimatedDiv = _styled__default(web.extendedAnimated.div).withConfig({
  displayName: "SidePanel___StyledAnimatedDiv",
  componentId: "sc-ztht0n-1"
})(["position:absolute;top:0;left:0;right:0;bottom:0;background:", ";"], p => p.$_css2);
var _StyledHeader = _styled__default("header").withConfig({
  displayName: "SidePanel___StyledHeader",
  componentId: "sc-ztht0n-2"
})(["display:flex;flex-direction:column;justify-content:center;flex-shrink:0;position:relative;height:", "px;padding-left:", "px;border-bottom:1px solid ", ";", ";"], p => p.$_css3, CONTENT_PADDING, p => p.$_css4, p => p.$_css5);
var _StyledH = _styled__default("h1").withConfig({
  displayName: "SidePanel___StyledH",
  componentId: "sc-ztht0n-3"
})(["color:", ";", ";"], p => p.$_css6, p => p.$_css7);
var _StyledButtonIcon = _styled__default(ButtonIcon.default).withConfig({
  displayName: "SidePanel___StyledButtonIcon",
  componentId: "sc-ztht0n-4"
})(["position:absolute;", ""], p => p.$_css8);
var _StyledDiv2 = _styled__default("div").withConfig({
  displayName: "SidePanel___StyledDiv2",
  componentId: "sc-ztht0n-5"
})(["overflow-y:auto;height:100%;display:flex;flex-direction:column;"]);
var _StyledDiv3 = _styled__default("div").withConfig({
  displayName: "SidePanel___StyledDiv3",
  componentId: "sc-ztht0n-6"
})(["min-height:0;flex-grow:1;flex-shrink:0;display:flex;flex-direction:column;width:100%;padding-right:", "px;padding-left:", "px;padding-bottom:", "px;"], CONTENT_PADDING, CONTENT_PADDING, CONTENT_PADDING);
var _StyledAnimatedAside = _styled__default(web.extendedAnimated.aside).withConfig({
  displayName: "SidePanel___StyledAnimatedAside",
  componentId: "sc-ztht0n-7"
})(["position:absolute;top:0;right:0;display:flex;flex-direction:column;width:100%;height:100%;background:", ";box-shadow:-2px 0px 4px rgba(0,0,0,0.1);", ""], p => p.$_css9, p => p.$_css10);

exports.default = SidePanel;
exports.useSidePanel = useSidePanel;
exports.useSidePanelFocusOnReady = useSidePanelFocusOnReady;
//# sourceMappingURL=SidePanel.js.map
