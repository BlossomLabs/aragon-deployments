'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

function _interopDefault (ex) { return (ex && (typeof ex === 'object') && 'default' in ex) ? ex['default'] : ex; }

var React = require('react');
var React__default = _interopDefault(React);
require('./_commonjsHelpers-72d386ba.js');
var index = require('./index-c8446775.js');
var _styled = require('styled-components');
var _styled__default = _interopDefault(_styled);
require('./color.js');
require('./components.js');
require('./contains-component.js');
require('./css.js');
require('./dayjs.min-966150e3.js');
require('./date.js');
require('./miscellaneous.js');
require('./environment.js');
require('./font.js');
require('./math-4eaf20a0.js');
require('./characters.js');
require('./format.js');
require('./keycodes.js');
require('./url.js');
require('./web3.js');
var constants = require('./constants.js');
require('./breakpoints.js');
require('./springs.js');
require('./text-styles.js');
var _extends$1 = require('./extends-43472f94.js');
var index$1 = require('./index-766bccf9.js');
require('./defineProperty-7b1b81d8.js');
require('./isObject-b8c5dfc0.js');
require('./Viewport-0f56d694.js');
var Layout = require('./Layout.js');

function CardLayout(_ref) {
  let {
    children,
    columnWidthMin,
    rowHeight,
    ...props
  } = _ref;
  const {
    layoutName
  } = Layout.useLayout();
  const fullWidth = layoutName === 'small';
  const gridAutoRowValue = rowHeight === 'auto' ? rowHeight : `${rowHeight}px`;
  return /*#__PURE__*/React__default.createElement(index$1.i, {
    name: "CardLayout"
  }, /*#__PURE__*/React__default.createElement(_StyledDiv, _extends$1._extends({}, props, {
    $_css: 2 * constants.GU,
    $_css2: fullWidth ? 'auto-fit' : 'auto-fill',
    $_css3: columnWidthMin,
    $_css4: gridAutoRowValue,
    $_css5: fullWidth ? 2 * constants.GU : 0,
    $_css6: 3 * constants.GU
  }), children));
}
CardLayout.propTypes = {
  children: index.PropTypes.node,
  columnWidthMin: index.PropTypes.number,
  rowHeight: index.PropTypes.oneOfType([index.PropTypes.oneOf(['auto']), index.PropTypes.number])
};
CardLayout.defaultProps = {
  columnWidthMin: 21 * constants.GU,
  rowHeight: 21 * constants.GU
};
var _StyledDiv = _styled__default("div").withConfig({
  displayName: "CardLayout___StyledDiv",
  componentId: "sc-1iy1ths-0"
})(["display:grid;grid-gap:", "px;grid-auto-flow:row;grid-template-columns:repeat( ", ",minmax(", "px,1fr) );grid-auto-rows:", ";align-items:start;padding:0 ", "px ", "px;margin:0 auto;"], p => p.$_css, p => p.$_css2, p => p.$_css3, p => p.$_css4, p => p.$_css5, p => p.$_css6);

exports.CardLayout = CardLayout;
exports.default = CardLayout;
//# sourceMappingURL=CardLayout.js.map
