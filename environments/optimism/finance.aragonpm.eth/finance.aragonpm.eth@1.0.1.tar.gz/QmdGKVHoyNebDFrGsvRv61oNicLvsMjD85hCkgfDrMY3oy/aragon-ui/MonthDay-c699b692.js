'use strict';

function _interopDefault (ex) { return (ex && (typeof ex === 'object') && 'default' in ex) ? ex['default'] : ex; }

var React = require('react');
var React__default = _interopDefault(React);
require('./_commonjsHelpers-72d386ba.js');
var index = require('./index-c8446775.js');
var _styled = require('styled-components');
var _styled__default = _interopDefault(_styled);
require('./color.js');
require('./components.js');
require('./contains-component.js');
require('./css.js');
require('./dayjs.min-966150e3.js');
require('./date.js');
require('./miscellaneous.js');
require('./environment.js');
require('./font.js');
require('./math-4eaf20a0.js');
require('./characters.js');
require('./format.js');
require('./keycodes.js');
require('./url.js');
require('./web3.js');
var constants = require('./constants.js');
require('./breakpoints.js');
require('./springs.js');
var textStyles = require('./text-styles.js');
require('./theme-dark.js');
require('./theme-light.js');
var Theme = require('./Theme.js');
var _extends$1 = require('./extends-43472f94.js');
var ButtonBase = require('./ButtonBase.js');
require('./IconAddUser.js');
require('./IconAlert.js');
require('./IconAlignCenter.js');
require('./IconAlignJustify.js');
require('./IconAlignLeft.js');
require('./IconAlignRight.js');
require('./IconAragon.js');
require('./IconArrowDown.js');
require('./IconArrowLeft.js');
require('./IconArrowRight.js');
require('./IconArrowUp.js');
require('./IconAtSign.js');
require('./IconBlock.js');
require('./IconBookmark.js');
require('./IconCalendar.js');
require('./IconCanvas.js');
require('./IconCaution.js');
require('./IconCenter.js');
require('./IconChart.js');
require('./IconChat.js');
require('./IconCheck.js');
require('./IconChip.js');
require('./IconCircleCheck.js');
require('./IconCircleMinus.js');
require('./IconCirclePlus.js');
require('./IconClock.js');
require('./IconCloudDownload.js');
require('./IconCloudUpload.js');
require('./IconCoin.js');
require('./IconConfiguration.js');
require('./IconConnect.js');
require('./IconConnection.js');
require('./IconConsole.js');
require('./IconCopy.js');
require('./IconCross.js');
require('./IconDashedSquare.js');
require('./IconDown.js');
require('./IconDownload.js');
require('./IconEdit.js');
require('./IconEllipsis.js');
require('./IconEnter.js');
require('./IconEthereum.js');
require('./IconExternal.js');
require('./IconFile.js');
require('./IconFilter.js');
require('./IconFlag.js');
require('./IconFolder.js');
require('./IconGraph2.js');
require('./IconGraph.js');
require('./IconGrid.js');
require('./IconGroup.js');
require('./IconHash.js');
require('./IconHeart.js');
require('./IconHide.js');
require('./IconHome.js');
require('./IconImage.js');
require('./IconInfo.js');
require('./IconLabel.js');
require('./IconLayers.js');
var IconLeft = require('./IconLeft.js');
require('./IconLink.js');
require('./IconLocation.js');
require('./IconLock.js');
require('./IconMail.js');
require('./IconMaximize.js');
require('./IconMenu.js');
require('./IconMinimize.js');
require('./IconMinus.js');
require('./IconMove.js');
require('./IconNoPicture.js');
require('./IconPicture.js');
require('./IconPlus.js');
require('./IconPower.js');
require('./IconPrint.js');
require('./IconProhibited.js');
require('./IconQuestion.js');
require('./IconRefresh.js');
require('./IconRemoveUser.js');
var IconRight = require('./IconRight.js');
require('./IconRotateLeft.js');
require('./IconRotateRight.js');
require('./IconSearch.js');
require('./IconSettings.js');
require('./IconShare.js');
require('./IconSquareMinus.js');
require('./IconSquarePlus.js');
require('./IconSquare.js');
require('./IconStarFilled.js');
require('./IconStar.js');
require('./IconSwap.js');
require('./IconTarget.js');
require('./IconToken.js');
require('./IconTrash.js');
require('./IconUnlock.js');
require('./IconUp.js');
require('./IconUpload.js');
require('./IconUser.js');
require('./IconView.js');
require('./IconVote.js');
require('./IconWallet.js');
require('./IconWarning.js');
require('./IconWorld.js');
require('./IconWrite.js');
require('./IconZoomIn.js');
require('./IconZoomOut.js');

const HoverIndicator = _styled__default.span.withConfig({
  displayName: "components__HoverIndicator",
  componentId: "sc-a0ixn9-0"
})(["width:100%;height:100%;position:absolute;border-radius:50%;", ""], _ref => {
  let {
    theme,
    selected
  } = _ref;
  return _styled.css(["background:", ";border:2px solid ", ";"], selected ? theme.selected : theme.surface, theme.accent);
});
const ArrowButton = props => {
  const theme = Theme.useTheme();
  return /*#__PURE__*/React__default.createElement(_StyledButtonBase, _extends$1._extends({
    focusRingRadius: constants.GU * 2
  }, props, {
    $_css: theme.hint
  }));
};
const SelectorWrapper = _styled__default.div.withConfig({
  displayName: "components__SelectorWrapper",
  componentId: "sc-a0ixn9-1"
})(["display:flex;align-items:center;justify-content:space-between;margin-bottom:", "px;span{", "}"], 1 * constants.GU, _ref2 => {
  let {
    small,
    theme
  } = _ref2;
  return _styled.css(["", ";", ""], textStyles.textStyle(small ? 'label2' : 'body2'), small && _styled.css(["color:", ";font-weight:600;"], theme.hint));
});

// eslint-disable-next-line react/prop-types
function Selector(_ref3) {
  let {
    prev,
    next,
    children,
    small
  } = _ref3;
  const theme = Theme.useTheme();
  return /*#__PURE__*/React__default.createElement(SelectorWrapper, {
    small: small,
    theme: theme
  }, /*#__PURE__*/React__default.createElement(ArrowButton, {
    onClick: prev
  }, /*#__PURE__*/React__default.createElement(IconLeft.default, {
    size: "small"
  })), /*#__PURE__*/React__default.createElement("span", null, children), /*#__PURE__*/React__default.createElement(ArrowButton, {
    onClick: next
  }, /*#__PURE__*/React__default.createElement(IconRight.default, {
    size: "small"
  })));
}
var _StyledButtonBase = _styled__default(ButtonBase.default).withConfig({
  displayName: "components___StyledButtonBase",
  componentId: "sc-a0ixn9-2"
})(["font-size:9px;padding:5px 4px 0 4px;margin-top:-4px;color:", ";&:hover{color:inherit;}"], p => p.$_css);

function MonthDay(_ref) {
  let {
    children,
    disabled,
    inRange,
    rangeBoundaryBegin,
    rangeBoundaryEnd,
    selected,
    today,
    weekDay,
    ...props
  } = _ref;
  const theme = Theme.useTheme();
  const dimmedSelectedColor = theme.selected.alpha(0.09);
  const [isHovered, setIsHovered] = React.useState(false);
  return /*#__PURE__*/React__default.createElement(_StyledDiv, _extends$1._extends({
    onMouseEnter: () => setIsHovered(true),
    onMouseLeave: () => setIsHovered(false)
  }, props, {
    $_css: 4.5 * constants.GU,
    $_css2: weekDay ? 3.5 * constants.GU : 4.5 * constants.GU,
    $_css3: disabled ? `
                pointer-events: none;
                opacity: 0;
              ` : '',
    $_css4: selected && !disabled ? `
                &&& {
                  background: ${theme.selected};
                  color: ${theme.positiveContent};
                }
              ` : '',
    $_css5: inRange && !selected && !disabled ? `
                background: ${dimmedSelectedColor};
                border-radius: 0;
              ` : '',
    $_css6: (rangeBoundaryBegin || rangeBoundaryEnd) && _styled.css(["z-index:1;&:before{content:'';position:absolute;top:0;", ":0;z-index:0;background:", ";width:50%;height:100%;}"], rangeBoundaryBegin ? 'right' : 'left', dimmedSelectedColor),
    $_css7: isHovered && _styled.css(["> *{z-index:1;}"]),
    $_css8: today && _styled.css(["color:", ";font-weight:600;"], theme.selected),
    $_css9: weekDay && _styled.css(["pointer-events:none;color:", ";text-transform:uppercase;"], theme.contentSecondary)
  }), isHovered ? /*#__PURE__*/React__default.createElement(HoverIndicator, {
    theme: theme,
    selected: selected
  }) : null, /*#__PURE__*/React__default.createElement(_StyledSpan, {
    $_css10: textStyles.textStyle(weekDay ? 'body4' : 'body3')
  }, children), today ? /*#__PURE__*/React__default.createElement(_StyledDiv2, {
    $_css11: selected ? theme.surface : theme.selected
  }, "\u25CF") : null);
}
MonthDay.propTypes = {
  children: index.PropTypes.node,
  disabled: index.PropTypes.bool,
  selected: index.PropTypes.bool,
  inRange: index.PropTypes.bool,
  rangeBoundaryBegin: index.PropTypes.bool,
  rangeBoundaryEnd: index.PropTypes.bool,
  today: index.PropTypes.bool,
  weekDay: index.PropTypes.bool
};
WrappedMonthDay.propTypes = {
  ...MonthDay.propTypes,
  onClick: index.PropTypes.func
};
function WrappedMonthDay(_ref2) {
  let {
    onClick,
    ...props
  } = _ref2;
  if (onClick && !props.disabled) {
    return /*#__PURE__*/React__default.createElement(_StyledButtonBase$1, {
      onClick: onClick,
      $_css12: 4.5 * constants.GU,
      $_css13: props.weekDay ? 3.5 * constants.GU : 4.5 * constants.GU
    }, /*#__PURE__*/React__default.createElement(MonthDay, props));
  } else {
    return /*#__PURE__*/React__default.createElement(MonthDay, props);
  }
}
var _StyledDiv = _styled__default("div").withConfig({
  displayName: "MonthDay___StyledDiv",
  componentId: "sc-1j0k3qo-0"
})(["position:relative;display:flex;align-items:center;justify-content:center;width:", "px;height:", "px;border-radius:50%;cursor:pointer;user-select:none;margin-bottom:1px;", ";", " ", " ", " ", " ", " ", " &:after{display:block;content:'';margin-top:100%;}"], p => p.$_css, p => p.$_css2, p => p.$_css3, p => p.$_css4, p => p.$_css5, p => p.$_css6, p => p.$_css7, p => p.$_css8, p => p.$_css9);
var _StyledSpan = _styled__default("span").withConfig({
  displayName: "MonthDay___StyledSpan",
  componentId: "sc-1j0k3qo-1"
})(["", ";"], p => p.$_css10);
var _StyledDiv2 = _styled__default("div").withConfig({
  displayName: "MonthDay___StyledDiv2",
  componentId: "sc-1j0k3qo-2"
})(["position:absolute;bottom:1px;font-size:9px;color:", ";"], p => p.$_css11);
var _StyledButtonBase$1 = _styled__default(ButtonBase.default).withConfig({
  displayName: "MonthDay___StyledButtonBase",
  componentId: "sc-1j0k3qo-3"
})(["display:flex;width:", "px;height:", "px;margin:0;"], p => p.$_css12, p => p.$_css13);

exports.MonthDay = WrappedMonthDay;
exports.Selector = Selector;
//# sourceMappingURL=MonthDay-c699b692.js.map
