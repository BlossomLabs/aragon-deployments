'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

function _interopDefault (ex) { return (ex && (typeof ex === 'object') && 'default' in ex) ? ex['default'] : ex; }

var React = require('react');
var React__default = _interopDefault(React);
require('./_commonjsHelpers-72d386ba.js');
var index = require('./index-c8446775.js');
var _styled = require('styled-components');
var _styled__default = _interopDefault(_styled);
require('./color.js');
require('./components.js');
require('./contains-component.js');
require('./css.js');
require('./dayjs.min-966150e3.js');
require('./date.js');
require('./miscellaneous.js');
require('./environment.js');
require('./font.js');
require('./math-4eaf20a0.js');
require('./characters.js');
require('./format.js');
require('./keycodes.js');
require('./url.js');
require('./web3.js');
var constants = require('./constants.js');
require('./breakpoints.js');
require('./springs.js');
var textStyles = require('./text-styles.js');
require('./theme-dark.js');
require('./theme-light.js');
var Theme = require('./Theme.js');
require('./extends-43472f94.js');
var index$1 = require('./index-766bccf9.js');
require('./defineProperty-7b1b81d8.js');
require('./FocusVisible.js');
var ButtonBase = require('./ButtonBase.js');

function Tab(_ref) {
  let {
    index,
    item,
    selected,
    onChange
  } = _ref;
  const theme = Theme.useTheme();
  const [insideSidePanel] = index$1.o('SidePanel');
  const handleClick = React.useCallback(() => {
    onChange(index);
  }, [index, onChange]);
  return /*#__PURE__*/React__default.createElement(_StyledLi, null, /*#__PURE__*/React__default.createElement(_StyledButtonBase, {
    focusRingRadius: constants.RADIUS,
    onClick: handleClick,
    $_css: textStyles.textStyle('body2'),
    $_css2: theme.surfacePressed
  }, /*#__PURE__*/React__default.createElement(_StyledSpan, {
    $_css3: 8 * constants.GU - (insideSidePanel ? 1 : 2),
    $_css4: 3 * constants.GU,
    $_css5: selected ? theme.surfaceContent : theme.surfaceContentSecondary
  }, item, /*#__PURE__*/React__default.createElement(_StyledSpan2, {
    $_css6: theme.selected,
    $_css7: Number(selected),
    $_css8: Number(selected)
  }))));
}
Tab.propTypes = {
  index: index.PropTypes.number.isRequired,
  item: index.PropTypes.node.isRequired,
  onChange: index.PropTypes.func.isRequired,
  selected: index.PropTypes.bool.isRequired
};
var _StyledLi = _styled__default("li").withConfig({
  displayName: "Tab___StyledLi",
  componentId: "sc-lm66af-0"
})(["list-style:none"]);
var _StyledButtonBase = _styled__default(ButtonBase.default).withConfig({
  displayName: "Tab___StyledButtonBase",
  componentId: "sc-lm66af-1"
})(["", ";border-radius:0;transition:background 50ms ease-in-out;&:active{background:", ";}"], p => p.$_css, p => p.$_css2);
var _StyledSpan = _styled__default("span").withConfig({
  displayName: "Tab___StyledSpan",
  componentId: "sc-lm66af-2"
})(["display:flex;position:relative;align-items:center;height:", "px;padding:0 ", "px;white-space:nowrap;color:", ";"], p => p.$_css3, p => p.$_css4, p => p.$_css5);
var _StyledSpan2 = _styled__default("span").withConfig({
  displayName: "Tab___StyledSpan2",
  componentId: "sc-lm66af-3"
})(["position:absolute;left:0;right:0;bottom:0;background:", ";height:2px;opacity:", ";transition-property:transform,opacity;transition-duration:150ms;transition-timing-function:ease-in-out;transform:scale3d(1,", ",1);transform-origin:0 100%;"], p => p.$_css6, p => p.$_css7, p => p.$_css8);

exports.default = Tab;
//# sourceMappingURL=Tab.js.map
