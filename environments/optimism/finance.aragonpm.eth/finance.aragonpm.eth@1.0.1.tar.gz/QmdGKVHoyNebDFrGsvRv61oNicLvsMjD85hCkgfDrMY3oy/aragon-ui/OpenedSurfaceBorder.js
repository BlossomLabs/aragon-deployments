'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

function _interopDefault (ex) { return (ex && (typeof ex === 'object') && 'default' in ex) ? ex['default'] : ex; }

var React = require('react');
var React__default = _interopDefault(React);
require('./_commonjsHelpers-72d386ba.js');
var index = require('./index-c8446775.js');
var _styled = require('styled-components');
var _styled__default = _interopDefault(_styled);
require('./color.js');
require('./components.js');
require('./contains-component.js');
require('./css.js');
require('./dayjs.min-966150e3.js');
require('./date.js');
require('./miscellaneous.js');
require('./environment.js');
require('./font.js');
require('./math-4eaf20a0.js');
require('./characters.js');
require('./format.js');
require('./keycodes.js');
require('./url.js');
require('./web3.js');
require('./constants.js');
require('./breakpoints.js');
var springs = require('./springs.js');
require('./text-styles.js');
require('./theme-dark.js');
require('./theme-light.js');
var Theme = require('./Theme.js');
var _extends = require('./extends-43472f94.js');
require('./objectWithoutPropertiesLoose-d28f0f6e.js');
require('react-dom');
var web = require('./web-449fa78f.js');

function OpenedSurfaceBorder(_ref) {
  let {
    opened,
    ...props
  } = _ref;
  const theme = Theme.useTheme();
  return /*#__PURE__*/React__default.createElement(web.Spring, {
    native: true,
    from: {
      width: 0
    },
    to: {
      width: Number(opened)
    },
    config: {
      ...springs.springs.smooth
    }
  }, _ref2 => {
    let {
      width
    } = _ref2;
    return /*#__PURE__*/React__default.createElement(_StyledAnimatedDiv, _extends._extends({
      style: {
        transform: width.interpolate(v => `scale3d(${v}, 1, 1)`)
      }
    }, props, {
      $_css: theme.surfaceOpened
    }));
  });
}
OpenedSurfaceBorder.propTypes = {
  opened: index.PropTypes.bool
};
var _StyledAnimatedDiv = _styled__default(web.extendedAnimated.div).withConfig({
  displayName: "OpenedSurfaceBorder___StyledAnimatedDiv",
  componentId: "sc-1lr5ih7-0"
})(["position:absolute;top:0;left:0;height:100%;width:3px;background:", ";transform-origin:0 0;"], p => p.$_css);

exports.OpenedSurfaceBorder = OpenedSurfaceBorder;
//# sourceMappingURL=OpenedSurfaceBorder.js.map
