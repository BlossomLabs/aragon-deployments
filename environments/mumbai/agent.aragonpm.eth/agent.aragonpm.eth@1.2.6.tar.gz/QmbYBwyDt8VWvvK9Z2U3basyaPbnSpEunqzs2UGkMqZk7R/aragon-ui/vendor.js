'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

var index = require('./index-c33eeeef.js');
require('react');
require('./index-37353731.js');
require('./_commonjsHelpers-1b94f6bc.js');



exports.Inside = index.i;
exports.useInside = index.o;
//# sourceMappingURL=vendor.js.map
