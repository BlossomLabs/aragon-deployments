'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

require('react');
require('./_commonjsHelpers-72d386ba.js');
require('./index-b0606964.js');
var index$1 = require('./index-ecc57c9f.js');



exports.Inside = index$1.i;
exports.useInside = index$1.o;
//# sourceMappingURL=vendor.js.map
