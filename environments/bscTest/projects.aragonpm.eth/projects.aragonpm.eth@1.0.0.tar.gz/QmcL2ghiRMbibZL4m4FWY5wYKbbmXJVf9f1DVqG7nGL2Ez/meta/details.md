The Projects app is a project management app that synchronizes GitHub repositories to your organization, enabling bounties to be allocated to issues and issue curation to determine priorities.

## Features
- Synchronize any of your GitHub repositories with your organization.
- Fund issues by placing bounties, either following hourly or fixed pricing models.
- Coordinate application and work reviews on bounties.
- Curate a set of issues, forwarded to Dot Voting.
